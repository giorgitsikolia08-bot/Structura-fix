# Structura 1.21.5: auditoria de compatibilidade (base: fork 1.21.4)

Alvo: Minecraft Bedrock 1.26.52.03 RC2 (arm64, build-id 56de9eed…), LeviLauncher, preloader-android 5d108da.

## Origem dos dois arquivos analisados

- **`structura_mod.zip` (MediaFire):** código-fonte da 1.0.3 (commit 4d89a73) com 3 arquivos editados: `EasyPlace.cpp`, `State.hpp` e `main.cpp`.
  - As configurações novas foram inseridas depois do `};` de `Settings`, e o `};` extra fecha o namespace `lm` antes da hora. Resultado: **não compila** (verificado com o clang do NDK).
  - As 3 opções novas também não têm UI.
  - Não traz nenhum `.so`. Os 162 MB são o `bedrock-samples` que ficou dentro de `build/`.
- **`Structura_源码_1.21.4` (TXT):** fork de terceiros feito a partir da mesma 1.0.3 (4d89a73).
  - Os 105 arquivos foram reconstruídos byte a byte e conferidos pelo SHA-256 de cada um.
  - É a linha que está no aparelho: o print "1.2.2" vem dela.
  - Traz todas as funcionalidades novas (picker próprio, X-ray experimental, auto-rebuild do watchdog, UI, preview a 1°).
  - **Foi a base desta versão.**

Nenhum dos dois contém as correções C1–C4 (2.0.1) nem as regras do resolver da 2.0.2: as duas existem só na linha 2.x (225b87a e 3bd8ca8). Aqui elas foram **portadas**; nada foi "preservado" porque não existia. Os patches aplicaram sem conflito, exceto a linha de versão.

## Defeitos confirmados e correções

| # | Arquivo | Defeito (evidência) | Correção |
|---|---|---|---|
| C1 | main.cpp | `retireOldMods()` chamava `unregisterModule`/`unregisterButton` com ids de **outros** mods (`easyplace.*`, `schem.*`), na init e a cada 2 s. O preloader apaga por id sem conferir o dono. | Removido. Ficam a detecção e o aviso. |
| C2 | Hologram.cpp | `sGetBlock` guardava uma **cópia** do slot de `getBlock`. `rebuildChain` reescreve o slot a cada hook/unhook de outro mod. | `getBlockViaChain` relê o slot a cada chamada. |
| C3 | EasyPlace.cpp | 4 detours chamavam o slot direto. O slot fica nulo na janela entre `GlossHook` e `rebuildChain`, o que dá salto para 0. | `chainNext` nos detours e `chainPeek` + teste de nulo em `placeNow`. |
| C4 | main.cpp | `disable()` zerava `mWatcherStarted`, um flag que pertence à thread do watcher. Isso permitia um segundo watcher. | Linha removida. |
| R202 | Resolver.cpp (+ ResolverRules.hpp, TestedBodies.inc, HookPatch.hpp) | Com outro mod fazendo hook em funções de assinatura curta, a entrada era recusada mesmo com build-id e offset comprovados. Bytes reais do RC2: 84 de 198 combinações recusadas; `TessellatorColor` em 6 de 6 formas de patch. | Backport da 2.0.2: prova por arquivo ou por fingerprint do corpo, só na build testada. As fingerprints foram regeneradas da biblioteca de referência e são idênticas às da 2.0.2. |
| D1 | App.cpp | `PLRequestDocument` é **assíncrono**: o preloader guarda callback e userData e chama depois (`InputBridge.cpp`). O fork passava `&cb`, um `std::function` local, e o resultado chegava com o frame já morto. ASan: stack-use-after-return. | Callback sem userData, chamando `importOne` direto. |
| D2 | Ui.cpp | Cada novo ângulo (passo de 1°) de cada estrutura carregada registra uma imagem no registro **global** do preloader. O registro não tem unregister, é compartilhado por todos os mods e é varrido linearmente sob o mutex global do ModMenu. Crescimento sem limite. | Orçamento de 32 MiB de pixels de preview. Acima dele, mostra o ângulo já renderizado mais próximo e registra uma linha de log. |
| D3 | Hologram.cpp | O X-ray (desligado por padrão) religava `GL_DEPTH_TEST` incondicionalmente, mesmo que estivesse desligado antes. Também mexia em GL sem verificar se havia contexto atual. | Consulta `glIsEnabled` antes, só restaura o que mudou e exige `eglGetCurrentContext`. |
| D4 | CMakeLists.txt | O build oficial não linkava, por falta de `src/Picker.cpp` (`ld.lld: undefined symbol lm::picker::*`). | Fonte adicionado. |
| D5 | CMakeLists.txt | O `.so` exportava símbolos da libc++ para os outros mods (dlopen `RTLD_GLOBAL`). Também importava 3 internos de `std::string` de quem os exportasse em runtime, já que o linker os resolvia contra a libc++ exportada pelo `libpreloader.so`. | `c++_static`/`c++abi` antes do preloader e `--exclude-libs,ALL`. Agora o único export de código é `PLGetModRegistration` e não sobra nenhum `std::` indefinido. |
| D6 | CMakeLists.txt | O build oficial mostrava a versão "dev" (`AR_VERSION` ausente). | A versão é lida do `manifest.json`. |
| R5 | RecentPlaced.hpp | `static thread_local` violava a regra R5 do projeto. Só é chamado pela thread de render. | `static` simples. É regra do projeto, não falha observada. |

## Riscos que continuam (sem evidência de falha)

- O símbolo `pl::modmenu::getHudSurfaceSize` e o layout de `ModuleInfo` exigem um preloader recente. Com um launcher mais antigo, o dlopen falha ou o `registerModule` quebra.
- No `Picker.cpp`, o `NewDirectByteBuffer` aponta para um vetor local. Funciona porque o ART copia o dex no construtor. Também há chamadas JNI sem `ExceptionCheck` em alguns caminhos.
- O watchdog `BuildStalled` foi mantido com o auto-rebuild do fork. A causa original não foi provada.
- Com o `libEasyPlace.so`/`libSchematica.so` antigos carregados, o comportamento é NÃO TESTADO.

## Testes (`scripts/host_test.sh`)

| Teste | 1.21.5 | 1.21.4 original |
|---|---|---|
| `compat_check.py` (R1–R8) | OK | 20 falhas |
| `hookchain_test` | 20/0 | n/a (modelo) |
| `resolver_rules_test` (bytes reais do RC2) | 1099/0 | regra antiga recusa 84/198 |
| `document_cb_test` | 7/0 | `--old`: stack-use-after-return |
| `host_test` (transformações, parser, progresso, camadas) | 7569/0 | arquivos não alterados |

**NÃO TESTADO:** jogo real, LeviLauncher com outros mods, desempenho.
