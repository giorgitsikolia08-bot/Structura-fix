# Structura 1.21.9 — Fidelidade visual do Ciano e desempenho do Easy Place

Alvo: MC Bedrock 1.26.52.03 RC2 (build-id 56de9eed), Android ARM64, LeviLauncher (preloader 5d108da).
Base: 1.21.8. **Nada disto foi testado no jogo** (ver §6). Nenhuma API, assinatura ou offset novo.

## 1. Ciano — causa raiz

Caminho da cor: `texFrameSetup` (alpha = `cyan::alphaFor(opacidade)`, material `particles_blend` porque
alpha < 0.99) → `BlockTessellator` gera a malha → `texBlock` reescreve as cores de vértice
(`tess+0x70`, uint32) com `cyan::tint` → `drawMesh` com o material do jogo. A ordem dos bytes foi
verificada no binário de referência: `Tessellator::color` (0xa76edac) grava `a<<24 | b<<16 | g<<8 | r`
(r = byte baixo), que é exatamente o que `CyanStyle.hpp` decodifica. **A ordem não era o problema.**

Problemas reais (1.21.8):
1. **Tint errado na origem.** A cor de vértice do BlockTessellator não é a cor da textura: é o fator de
   luz/AO/bioma (quase branco numa face iluminada). O shader faz `textura × corDeVértice`. A 1.21.8
   misturava 75% de ciano saturado (0x38D4FF) nesse fator, ou seja multiplicava toda textura por
   ≈ (0.42, 0.87, 1.0): pedra cinza virava verde-azulado escuro, texturas ficavam ilegíveis.
2. **Transparente demais.** alpha 0.185–0.50 (padrão 0.50): o mundo atrás dominava ("lavado").
3. **Contornos só na silhueta.** A referência desenha uma linha fina em toda junta visível entre blocos.
4. **Linhas cortadas perto do jogador.** As arestas eram copiadas na ordem longe→perto para o limite
   compartilhado de 60000 linhas; quando enchia, eram as linhas próximas que sumiam.
5. **Fallback sem textura** usava 0x38D4FF saturado e opaco.

Referência (`Screenshot_2026-10-19-00-01-43-95_…jpg`, de outro mod): faces ≈ (107,124,131) ⇒ fator
≈ (0.82, 0.95, 1.0) sobre textura neutra; texturas legíveis; quase opaco; linhas ciano-claras de ~1 px.

## 2. Ciano — correção (só `CyanStyle.hpp` + o uso em `Hologram.cpp`)

- `tint()`: multiplicação por canal do fator de luz por (209, 242, 255)/255 = (0.82, 0.95, 1.0), medido
  na referência. Nunca clareia (sem brilho estourado), preserva a ordem de brilho e o detalhe da textura,
  azul intocado. Limitação física: pela cor de vértice só dá para **multiplicar** a textura; não dá para
  dessaturá-la. Um bloco muito colorido (lã vermelha) continua avermelhado com um tom azul.
- `alphaFor()`: 0.50 + 0.38·opacidade → 0.538…0.88 (padrão 0.88). Continua < 0.99, então o material
  continua o translúcido `particles_blend` (mesmo caminho, sem GL cru).
- Arestas de **grade** (`gridEdgesFor`): uma aresta unitária é desenhada quando 1–3 das 4 células em
  volta são do holograma (4 = interior). Cada aresta tem **um dono** (a primeira célula ocupada numa ordem
  fixa), então sai exatamente uma vez, também entre chunks (a janela ±2 dá a mesma ocupação aos dois).
  Afastamento de 0.006 bloco para o lado vazio: sem z-fighting com as faces do holograma (encolhidas
  0.99) nem com blocos do mundo encostados.
- Cache por chunk compacto: 4 bytes por aresta (antes 40), limite 16384 por chunk (64 KB), aviso único
  no log se estourar. Expansão por frame **perto→longe**, depois das marcações de erro, dentro do limite
  existente de 60000 linhas e do mesmo `flushLines`/`selection_box`.
- Cor da linha (0.42, 0.88, 1.0, 0.95). Fallback sem textura: 0x8FC6DA.
- Clássico e sólido: inalterados (outros ramos de `tint`, outro alpha, sem arestas).
- Estado do renderizador: o estilo não mexe em GL. Profundidade/blend são os do material do jogo.
  `particles_blend` provavelmente grava profundidade (documentação da Microsoft, não verificado no
  aparelho); com 0.88 de opacidade isso pesa pouco, mas faces internas podem se esconder umas atrás das
  outras dentro de um chunk.

## 3. Easy Place — análise dos caminhos quentes (estática + contadores)

| Caso | O que roda | Custo antes |
|---|---|---|
| Jogo normal, EP desligado | `onTick` (2 detours de tick): `isGameModeOf` (2 leituras), `refreshGeneration` (atômicos), `processRechecks` (**32 locks de mutex por tick**), `runFix` (try_lock). Detour de getBlock: 1 load relaxado. | pequeno |
| Segurando EP (auto/mira) | por tick, quando a mira muda: raio ≤ 96 passos; cada célula = `expectedAt` (snapshot: relógio + mutex do modelo + cópia de shared_ptr + mutex gApiMu) + `worldBlock` (relógio + **2 process_vm_readv** + getBlock) + mutex do cache de nomes; `solidNeighbor` refaz 6 células; `choosePlan` refaz as 6 faces | médio |
| Modo "run" (camada/visível) | `runTarget` varre até 13³ células com o custo acima por célula **e repete a varredura inteira para cada bloco do lote** (epBatch até 4), até 20 passos/s | **alto (principal)** |
| Cada colocação | `choosePlan`: até ~300 simulações; cada resultado único → `compareWorld` → `stateValue` nos 2 lados por chave ≈ **15 process_vm_readv por chamada**, sem cache | alto |
| Cada colocação | `trace()`: `::write` síncrono em `easyplace-trace.txt` **na thread do jogo**, várias linhas | médio |
| A cada 2 s (UI) | `flushLog` reescrevia o log **segurando `gLogMu`**; `logf` na thread do jogo esperava | picos |

Duplicação com Holograma/Error Vision: não há varredura de EP no render; o holograma já memoiza a
classificação (8192 slots). O que se repetia era dentro do próprio EP (mesmas células várias vezes por
passo, mesmos (Block*, chave) a cada colocação).

## 4. Easy Place — correções (sem mudar frequência, sem atrasos, sem tirar verificação)

- **P1 trace/log** (`LineRing.hpp`): a thread do jogo só formata numa fila limitada (512 linhas, sem
  alocação); a UI grava a cada 2 s, mesmo arquivo, mesma rotação de 256 KB; linhas perdidas são contadas
  no arquivo. `flushLog` copia sob o lock e grava fora dele.
- **P2 visão por passo** (`EpWorld.hpp` + `lm::holo::FastWorld`): snapshot da estrutura e região
  resolvidos **uma vez por passo**; memo limitado (256 posições, 64 blocos, sem alocação) para
  esperado/mundo/substituível. **`W.forget()` após cada `placeNow`**: tudo que vem depois de uma colocação
  lê o mundo de novo. As verificações frescas por definição (`changed()`, `verifyPlaced`, rechecks,
  correções) continuam chamando a API direto. Bloco esperado ainda não resolvido nunca é memoizado. A ABI
  C `StructuraApiV1` não mudou (outros mods veem o mesmo).
- **P3 varredura k-melhores** (`EpScan.hpp`): uma passada devolve os k alvos do lote na mesma ordem que
  as varreduras repetidas escolheriam (empate: primeira célula na ordem y,x,z; bottom-up: camada mais
  baixa primeiro). Cada candidato depois do primeiro é reverificado no mundo atual; candidato pulado não
  consome vaga do lote; se uma colocação pôs um bloco de suporte em vez do alvo, o mesmo alvo é tentado
  de novo (como a nova varredura faria).
- **P4 cache de estados** (`SvCache.hpp`): (Block*, hash da chave) → valor, 2048 slots, mutex curto,
  esvaziado quando `worldEpoch` muda (mesmo momento em que o cache de nomes cai). Só respostas
  definitivas; falha de leitura nunca é guardada. O percurso da árvore é o mesmo de antes.
- **P5 ocioso**: `processRechecks` sai na hora quando não há recheck pendente (contador atômico
  atualizado sob o mesmo mutex) — mesmo resultado, sem os 32 locks por tick.
- **Contadores novos** (`perfLog`): `ep_cpu_ms_per_s`, `ep_steps_per_s`, `ep_expected_per_s`,
  `ep_world_reads_per_s`, `ep_sims_per_s`, `ep_file_writes_per_s`, `safe_reads_per_s`, `sv_calls_per_s`,
  `sv_hit_pct` (por segundo, na mesma linha `[perf]`).

## 5. Testes, benchmark e build

`bash scripts/host_test.sh` (ASan+UBSan): compat OK; hookchain 20; resolver 1099; document_cb 7;
beproxy 3307; error_vision 568; **cyan 326** (grade vs. referência força-bruta em 300 formas, divisão em
chunks/empacotamento exato, calibração na referência); **ep 28** (3000 casos aleatórios: sequência
k-melhores == varreduras antigas; memo nunca velho após forget; cache exato + flush por época + 2
threads; fila: ordem/perdas/truncamento/produtor-consumidor); paste 1365; host 7569; roundtrip 115.
Mutações detectadas: cyan dono, cyan tint 1.21.8, desempate da varredura, memo sem forget, cache sem
época (+ as anteriores). Regras estáticas: headers puros sem GL/hook/alocação; `trace()` sem E/S;
`flushLog` não grava segurando o lock; `forget()` após cada `placeNow`.

Benchmark **HOST** (`tests/ep_bench.cpp`, x86-64 do sandbox, 2 núcleos — não é Android). Código novo real;
custo antigo reproduzido com as mesmas primitivas (process_vm_readv, mutex, shared_ptr, relógio,
unordered_map, write). Mesma carga dos dois lados, mesma contagem de blocos colocados:

| Carga (por passo/colocação) | tempo 1.21.8 → 1.21.9 | syscalls | esperado | leituras mundo | mutex |
|---|---|---|---|---|---|
| run 95% construído, lote 1 | 193.5 → 13.5 µs | 294.7 → 2.0 | 210.8 → 209.9 | 147.4 → 147.4 | 498.8 → 167.4 |
| run 95% construído, lote 4 | 1482.5 → 27.6 µs | 2296.0 → 2.0 | 1643.7 → 742.8 | 1148.0 → 521.2 | 3929.4 → 453.2 |
| run lote 1 bottom-up | 52.7 → 3.9 µs | 81.8 → 2.0 | 57.6 → 56.6 | 40.9 → 40.9 | 136.9 → 58.7 |
| run lote 4 bottom-up | 1105.9 → 21.0 µs | 1728.7 → 2.0 | 1237.8 → 593.7 | 864.4 → 417.6 | 2963.6 → 373.5 |
| run, nada faltando (lote 4) | 869.3 → 32.2 µs | 1363.3 → 2.0 | 980.9 → 980.9 | 681.6 → 681.6 | 2342.1 → 583.4 |
| mira/toque (raio + vizinhos) | 8.68 → 1.43 µs | 14.3 → 2.0 | 1.8 → 1.8 | 7.2 → 5.6 | 4.7 → 3.5 |
| comparações do choosePlan | 1228.5 → 182.0 µs | 2160 → 308 | — | — | — |
| trace, 6 linhas (thread do jogo) | 7.02 → 0.66 µs | 6 writes → 0 | — | — | — |

Build ARM64 (NDK r28c, `scripts/build.sh`): 0 erros; único aviso pré-existente (Picker.cpp:155).
Importações e exportações dinâmicas idênticas às da 1.21.8 (só `PLGetModRegistration` exportado).

## 6. NÃO TESTADO (sem aparelho)

1. Ciano vs. referência; 2. opacidade em fundos diferentes; 3. EP desligado vs. ligado; 4. ocioso vs.
ativo; 5. esquemas pequenos vs. grandes; 6. aproximar de um holograma com EP ligado; 7. com outros mods.
Nenhum ganho de FPS no Android foi medido. Para medir: ativar o log de desempenho e comparar as linhas
`[perf]` (fps, frame_time_ms, ep_cpu_ms_per_s, safe_reads_per_s, sv_hit_pct) da 1.21.8 e da 1.21.9 na
mesma cena.

## 7. Limitações

- Tint por vértice só multiplica a textura (não dessatura); blocos muito coloridos mantêm a cor própria.
- Profundidade do `particles_blend` não verificada no aparelho.
- Uma passada k-melhores pode, num caso isolado, fazer mais consultas que as varreduras antigas (4 de 3000
  casos aleatórios, pior ×1.18); nunca mais de uma por célula.
- Se o jogo mudar um bloco no meio de um lote (fora do alvo), a escolha seguinte só considera isso no
  próximo passo (cada candidato ainda é reverificado antes de colocar).
- Trace: até 2 s de linhas ficam em memória; um crash pode perdê-las.

## 8. 1.21.10 — crash ao aparecer o holograma (relato do usuário)

Relato: com a 1.21.9 o jogo fechou quando o holograma apareceu; a mesma estrutura carregava na 1.21.8.
Sem log do crash. Revisão do que mudou no caminho de renderização: a grade do ciano podia encher o limite
inteiro de 60000 linhas **em todo frame** (até 60 malhas imediatas de linhas por frame). Medição no host
(função de contorno da 1.21.8 recuperada do patch vs. grade da 1.21.9):

| Forma | 1.21.8 (silhueta) | 1.21.9 (grade) |
|---|---|---|
| caixa maciça 32×16×32 | 320 linhas (1 malha) | 8192 (8 malhas) |
| casa oca 40×20×40 com pilares | 6782 (7) | 27598 (27) |
| cidade 96×40×96 | 36852 (36) | 296736 → teto 60000 (59) |

Correção: orçamento fixo de **4096 linhas de grade por frame** (≤ 4 malhas), gasto perto→longe, nos dois
caminhos (grade cacheada por chunk e células sem textura). As linhas cortadas são as distantes. Regra
estática nova no `host_test.sh` impede remover o limite. **Causa provável, não confirmada** (sem log);
se ainda crashar, o log é necessário.
