# Structura 1.21.8 — Holograma Ciano, Visão de Erros e Colar Esquemático (Criativo)

Alvo: MC Bedrock 1.26.52.03 RC2 (build-id 56de9eed), Android ARM64, LeviLauncher (preloader 5d108da).
Base: 1.21.7. **Nada disto foi testado no jogo** (ver "Validação").

## 1. Holograma ciano (`holoStyle` = 2, "Cyan hologram")

Pipeline inspecionado (Hologram.cpp): o modo texturizado gera malhas por chunk com o `Tessellator` do jogo
(`texBlock` → cores de vértice), desenhadas com o material RenderDragon escolhido em `texFrameSetup`
(`particles_blend` se alpha < 0.99, senão `particles_alpha`). Linhas e quads coloridos (`gLines`/`gQuads`)
usam o mesmo caminho já existente. **Não há GL cru no estilo ciano**: blending, teste/escrita de profundidade e
restauração de estado continuam sendo os do material do jogo e do caminho já usado pelo estilo 0. O único GL
cru do arquivo continua sendo o `XrayLineScope` experimental (inalterado; o teste estático 6d garante que o código
ciano não o usa).

- Translucidez: `cyan::alphaFor(alpha do usuário)` fica em [0.15, 0.50] → sempre < 0.99 → sempre o material
  translúcido `particles_blend` (o mundo aparece através do holograma).
- Cor: `cyan::tint` (modo de tint 3) mistura a textura com ciano-azulado `0x38D4FF`, mantém o byte de alpha,
  luminância ≤ 200 (sem brilho excessivo). O tint entra na assinatura da malha do chunk → trocar de estilo
  reconstrói as malhas (mecanismo já existente).
- Bordas finas: só as **arestas de silhueta** (convexas e côncavas, sem grade nas faces), calculadas uma vez por
  chunk na construção (`cm.edges`, limite 6144/chunk) a partir da janela de ocupação já existente (sem leitura do
  mundo) e inseridas em `gLines` por frame dentro do limite global `kMaxLines` (sem alocação por frame além da
  capacidade já reservada). No modo sem textura, as arestas vêm de `emitColored` (mesma regra, via `kindAt`).
- Fallback: estilos 0 (clássico) e 1 (sólido) inalterados; o padrão salvo continua 0.
- Não verificável sem o APK: se `particles_blend`/`selection_box` escrevem profundidade. **Não tenho certeza.**

Limitação cosmética conhecida: na fronteira entre um bloco texturizado e um bloco do holograma sem textura
(lookup de textura falhou), a ocupação das duas fontes difere e pode aparecer um segmento a mais.

## 2. Visão de Erros

Reutilizada da 1.21.7 sem mudanças (vermelho só para blocos existentes confirmados como errados; faltando,
vazio, correto e desconhecido nunca ficam vermelhos; independente do holograma e do raio-X experimental).
Suíte `error_vision` 568/0 e mutação detectada. Com o estilo ciano, o holograma normal é ciano e o erro vermelho.

## 3. Colar Esquemático (Criativo) — bloqueio primeiro

**Bloqueio (com evidência):** não existe forma suportada de escrever blocos diretamente a partir do mod:
- o SDK do preloader (5d108da) não tem API de comando, chat ou escrita de blocos;
- o `.so` do jogo é stripped (sem símbolos); `BlockSource::setBlock`/emissor de comandos não estão resolvidos e
  **não foram inventados**; escrita no cliente seria bloco-fantasma (o servidor/host é a autoridade);
- o EasyPlace (clique de construção) não serve: não substitui, não coloca ar, tem alcance e exige itens.
- **Nunca** há fallback silencioso para EasyPlace em massa.

**Alternativa suportada implementada:** o próprio comando do jogo `/structure load`.
1. O mod gera, num job de trabalho (nunca no render/jogo), um `.mcstructure` já com rotação, espelho, offset e
   estados transformados (mesma tabela `xf` do holograma/EasyPlace), em passos de 65536 células, com progresso,
   cancelamento e detecção de dados obsoletos (esquemático/posição trocado → nada é gravado).
2. Grava de forma atômica (tmp + rename, nunca sobrescreve) em
   `games/com.mojang/development_behavior_packs/StructuraPaste/structures/structura/<id>.mcstructure`
   (manifest criado só uma vez, nunca reescrito; pasta da instância com mundo aberto detectada via `/proc/self/fd`).
3. Copia o comando para a área de transferência:
   `/structure load structura:<id> X Y Z 0_degrees none false true`
4. O usuário cola no chat. **O jogo** aplica cheats, nível de operador e proteção; o mod não contorna nada.
   O comando é atômico: se a região não estiver carregada ou sair do mundo, nada é colocado.

Modos: **Replace All** (ar do esquemático limpa o bloco) e **Place Non-Air Only** (ar vira "structure void"
= o bloco do mundo fica). Structure void do esquemático sempre preserva o mundo. Água de blocos waterlogged vai
na camada 2 (só onde há bloco). Estados: nome + estados transformados + `version` original da paleta (o
upgrader do jogo converte estados antigos). Estados não-planos (raros) são omitidos e contados; variantes sem
regra de rotação/espelho são contadas como "inexatas" e avisadas na UI.

Requisitos/validação (`paste::check`): esquemático carregado, posicionado, jogador no mundo, Criativo
confirmado (getter `isCreative` 0xf58e894 já verificado, lido no thread do jogo; desconhecido = bloqueado),
sem outro paste em andamento, ≤ 4.194.304 posições, Y em −64..319 e dentro da borda ±29.999.984.
Criativo **não** é permissão: o jogo ainda exige cheats/operador.

Limitações:
- **Precisa sair e entrar no mundo** depois de gravar (o jogo só lê estruturas de pacotes ao carregar o mundo) e,
  na primeira vez, ativar o pacote "Structura Paste" no mundo. Não tenho certeza se o jogo enxerga um arquivo novo
  sem recarregar — por isso cada paste usa um id novo e a UI explica.
- Sem desfazer (o jogo não tem rollback e o mod não cria um).
- Conteúdo de baús, texto de placas e entidades não são incluídos.
- Arquivos legados sem `version` na paleta recebem 18168865; estados antigos podem não ser convertidos.
- Servidores/Realms: o pacote local não existe lá; o comando falha (honesto, nada é colocado).

## 4. UI e configurações

- Configurações → Estilo do holograma: Clássico / Sólido / **Ciano** (salvo em `holoStyle`, 0..2).
- Painel Mover → seção "World modification (Creative)": descrição (separada de holograma/realce), botão
  "Paste Schematic" desabilitado com motivo, confirmação com resumo, modo (salvo em `pasteMode`), aviso de
  substituição irreversível, "Prepare paste" (DangerArmed) / Cancelar; progresso com Cancelar (desabilitado
  ≥ 95%, quando o arquivo está sendo gravado); resultado (id, comando, passos, avisos, copiar).
- Traduções: en, pt_BR, zh_CN; demais idiomas usam inglês (fallback já existente).

## 5. Testes (host, ASan+UBSan) e build

`bash scripts/host_test.sh`:
- compat_check OK; hookchain 20/0; resolver_rules 1099/0; document_cb 7/0; beproxy 3307/0 (+83 samples);
  error_vision 568/0 (+mutação); **cyan 316/0** (+mutação: dedupe côncavo); **paste 1365/0** (+mutações:
  Non-Air escrevendo ar; sem checagem de Criativo); **regras estáticas cyan/paste OK**; host runtime 7569/0;
  **paste roundtrip 115/0** (loader real + tabela `xf` real, 4 rotações × espelho × 2 modos).
- `tests/cyan_test.cpp`: alpha, tint, 1 bloco = 12 arestas, 2×1×1 = 16, parede 8×8 = 68, cubo 3³ = 36,
  300 formas aleatórias vs. referência força-bruta.
- `tests/paste_test.cpp`: todas as células × 8 transformações × 2 modos decodificadas pelo parser NBT do projeto;
  void/ar/água; estados/versão; inexatos; todos os motivos de `check`; bordas do mundo; cancel/stale/progresso;
  arquivos (raiz ausente, manifest não reescrito, 2 uuids v4, sem sobrescrita, sem .tmp); id; comando exato.
- Build ARM64 (NDK r28c): 0 erros; único aviso pré-existente (Picker.cpp). Importações dinâmicas e exports
  idênticos à 1.21.7; nenhum hook, assinatura ou offset novo.

## 6. Validação no aparelho

**NÃO TESTADO**: aparência do ciano, translucidez/profundidade, bordas, desempenho, Visão de Erros com ciano,
detecção de Criativo no jogo, gravação na pasta do jogo, ativação do pacote, `/structure load` real, cópia para a
área de transferência, multi-mod. Nenhum resultado no jogo é afirmado.
