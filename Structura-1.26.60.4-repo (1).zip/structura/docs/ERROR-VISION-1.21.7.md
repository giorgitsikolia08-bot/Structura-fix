# Structura 1.21.7 — Visão de Erros (raio-X de blocos errados)

Base: 1.21.6. C1–C4, o resolver 2.0.2 (R202), D1–D6, R5 e BlockActorProxy foram mantidos.
Estado: compilado para ARM64 e testado no host. **NÃO TESTADO no jogo.**

## O que faz

Quando a opção **Visão de Erros** está ligada, os blocos do mundo que existem fisicamente e são diferentes
do bloco esperado na schematic ganham um contorno vermelho com preenchimento translúcido. Esse
destaque aparece através das paredes.

**Nunca são destacados:**
- blocos faltando;
- ar, ou posições vazias na schematic;
- blocos corretos;
- líquidos, luz, structure_void e bubble_column que estejam no mundo;
- qualquer bloco que não deu para ler ou resolver.

Nesses casos o resultado é "desconhecido", e desconhecido não conta como erro. O mod só lê o mundo, nunca altera nenhum bloco.

## Como decide (`src/ErrorVision.hpp`, `ev::judge`)

A decisão reaproveita o resultado da comparação que já existia (`compareAt` / `Cmp`). Por isso
rotação, espelho, offset e a verificação continuam iguais. As regras são:

| Resultado da comparação | Visão de Erros |
|---|---|
| Correct, AirOk, Missing, Extra, posição esperada vazia | nada |
| Wrong, com nome do bloco do mundo resolvido e físico | **errado** |
| WrongState, com variante esperada resolvida exatamente | **errado** |
| WrongState, com estados não confiáveis | desconhecido (sem destaque) |
| blockAt = 0, nomes ainda não carregados, nome desconhecido | desconhecido |

## Desempenho

- Não existe varredura própria. A Visão de Erros é alimentada pela comparação limitada que já existia
  (até 3000 por ciclo, mais o raio de 6 perto do jogador), usando `ev::Sweep`.
- O cache tem tamanho fixo: 8192 slots, no máximo 4096 blocos guardados e local-index como chave. Ele é
  invalidado quando muda a estrutura, a posição ou a geração da comparação.
- No desenho, cada bloco é reconferido com `stillIncorrect`. Um bloco consertado some na mesma hora.
- Por quadro, o desenho vai até 2048 caixas. Os buffers são reservados uma vez quando a opção é ligada e
  liberados quando é desligada, então não há alocação por quadro.

## Render

- Não há hook novo nem renderer novo: tudo usa o flush do holograma, dentro do RenderLevel que já existia, e o
  original continua sendo chamado uma vez só.
- As caixas são desenhadas relativas à câmera e projetadas a 0,2 bloco do olho, por isso aparecem através das
  paredes.
- Cor vermelha (1, 0.12, 0.12). A opacidade do preenchimento é configurável.
- Funciona com o holograma desligado (modo só comparação). Sem schematic carregada, não desenha nada.

## Interface e configuração

- **Visão de Erros (blocos errados através das paredes)** é um interruptor separado de "Mostrar holograma" e
  do "Contornos X-ray (experimental)", que agora tem "experimental" no nome.
- **Preenchimento da Visão de Erros**: 0–100%, de 5 em 5, padrão 25%. Só aparece com a opção ligada.
- Fica salvo no config como `errorVision` (padrão 0) e `errorVisionOpacity`.
- O Diag mostra "error vision X shown / Y confirmed (capped)".

## Testes (host)

- `tests/error_vision_test.cpp`: 568 passaram, 0 falharam (ASan/UBSan). Cobre:
  - todos os vereditos;
  - cache comparado com std::set, limite e invalidação;
  - sweep limitado;
  - estrutura 5x3x4 nas 4 rotações × espelho, com blocos certos, errados, faltando, líquido,
    ilegível, estado errado e estado não confiável;
  - geometria.
- Teste de mutação: um `judge` que confia em nomes não resolvidos é pego (26 falhas).
- `scripts/host_test.sh`: HOST_EXIT=0. Resultados:
  - compat_check OK;
  - hookchain 20/0;
  - resolver 1099/0;
  - document_cb 7/0;
  - beproxy 3307/0;
  - samples 83/0;
  - error_vision 568/0;
  - runtime 7569/0.
- Build ARM64 (`scripts/build.sh`, NDK r28c): exit 0. O único aviso é o `clsApp` sem uso em Picker.cpp, que já existia antes.

## Limitações conhecidas (não tenho certeza no jogo)

- A projeção a 0,2 bloco pode desalinhar com o balanço da câmera ou em terceira pessoa. Também pode sumir quando
  há um teto a menos de 0,2 bloco do olho.
- Não sei se o RenderDragon respeita o teste de profundidade desse passe.
- WrongState só aparece para variantes resolvidas exatamente.
- Nada aparece enquanto o TexCache não resolveu os nomes, nem enquanto as texturas estão pendentes no modo
  texturizado.
- Só aparecem blocos dentro da área comparada. O limite é 4096 guardados / 2048 desenhados.
- O preenchimento pode ficar com o dobro de alfa em faces dupla-face.
- Bug que já existia e não foi alterado: `radius` é limitado a 6..48 ao ler o config, então 0 (ilimitado) não é salvo.

## Testes pendentes no aparelho

1. Ligar a Visão de Erros com uma schematic posicionada. Trocar um bloco por outro e conferir se aparece em vermelho através de uma parede.
2. Conferir que blocos faltando, ar e blocos corretos nunca ficam vermelhos.
3. Colocar o bloco certo e ver se o vermelho some.
4. Testar com o holograma desligado; em terceira pessoa; perto de um teto.
5. Testar junto com outros mods de render, para confirmar que os hooks continuam encadeados.
6. Conferir o FPS ao chegar perto de uma estrutura grande.
