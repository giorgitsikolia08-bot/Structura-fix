# Structura 1.21.6 — baús/placas texturizados e otimizações do holograma

Base: 1.21.5-compat (todas as correções C1–C4, resolver 2.0.2, D1–D6 e R5 preservadas).
Estado: compilado (ARM64) e testado no host. **NÃO TESTADO no jogo.**

## 1. Caixa azul em baús, placas etc.

**Causa (confirmada no código):** baús, placas, camas, banners, cabeças, shulker boxes e potes decorados
são desenhados pelo BlockActorRenderer do jogo, não pelo BlockTessellator. Quando o holograma tessela
esses blocos, recebe 0 vértices. O bloco então ia para `special` e era desenhado como a caixa colorida
"faltando" (azul).

**Correção:** `src/BlockActorProxy.hpp` (só dados, sem chamadas ao jogo) associa cada bloco desses a:

- um **substituto** de cubo inteiro do mesmo material, que o BlockTessellator desenha com textura do jogo:
  - placa → tábuas da mesma madeira;
  - baú → tábuas de carvalho; baú do ender → obsidiana; baú de cobre → cobre do mesmo estágio;
  - cama → lã; banner → lã;
  - shulker → concreto da mesma cor; shulker sem cor → purpur;
  - cabeça → bloco de osso, carvão etc.; pote decorado → terracota;
- **1 ou 2 caixas** com o formato real:
  - baú 14/16;
  - placa de parede encostada na parede, conforme `facing_direction`;
  - placa em pé com tábua + poste, eixo dado por `ground_sign_direction`;
  - placa pendurada; cama 9/16; banner; cabeça no chão ou na parede.

`texBlock` tessela o substituto e espreme os vértices dentro da caixa. Isso só acontece para blocos que
deram 0 vértices (ou geometria inválida), então um bloco normal nunca perde o modelo real. Se o
substituto não existir na versão do jogo, a caixa azul continua (isso fica registrado no log).

Primitivas usadas, todas já existentes: `lookupLegacy` + `legacy+0x200` (as mesmas de
`resolveTransformed`) e `sTessInWorld`. Nenhum offset ou assinatura novo.

Limitações:
- a textura é a do material, não o modelo exato (sem fechadura do baú, sem texto da placa);
- a cor de camas e banners do Bedrock fica no block entity, por isso usamos vermelho e branco por padrão;
- uma face encostada num bloco sólido pode ser omitida pelo tessellator.

## 2. Otimizações

Todas removem trabalho redundante. Nenhuma mexe em hooks, VSync ou ritmo de FPS.

- **`recent::hit`**: lia o relógio (`steady_clock::now`) a cada bloco consultado, ou seja, milhares de
  vezes por reconstrução de chunk e 7 vezes por marcador por frame. Agora é um snapshot por frame
  (`recent::beginFrame`).
- **Comparação com o mundo**:
  - Antes eram 4000 `getBlock` fixos por frame. Uma estrutura com menos de 4000 blocos era verificada
    várias vezes no mesmo frame (a de 26×2×24 = 1248, cerca de 3×).
  - Agora:
    - o orçamento é limitado ao volume (máx. 3000);
    - mais uma janela de raio 6 em volta do jogador, verificada a cada ~4 frames, para que colocar ou
      quebrar blocos à mão apareça logo.
  - Troca: em estruturas grandes, a área longe do jogador leva ~33% mais tempo para ser reverificada.
- **Reconstrução de chunk**:
  - Era 1 `worldToLocal` por posição, em vez de 3 no preenchimento da janela e 2 no laço principal.
  - Os vetores temporários agora são reaproveitados, sem alocar a cada reconstrução.
- **Menos desenho imediato por frame**: baús e placas agora entram no mesh do chunk, em vez de serem
  re-tesselados todo frame como caixas coloridas.
- **Medição**: o log de desempenho (perf) ganhou os campos `holo_cpu_ms`, `holo_compares`,
  `holo_chunk_builds` e `holo_imm_quads`. O diagnóstico de Texturas mostra
  "block entities textured X/Y".

## Testes (host)

- compat_check OK;
- hookchain 20/0;
- resolver 1099/0;
- document_cb 7/0;
- beproxy 3307/0;
- conferência com os samples 1.26.50.4: 83 blocos com block entity, todos com substituto existente;
- host_test 7569/0.
