# Structura vs Minecraft 1.26.60.4 RC3 (libminecraftpe.so, arm64-v8a)

build-id: eb291b883dfdfaff70c4999c2eabd61885ae3e15 (not in the tested table -> signature scan mode)

## Found in the new library (offsets from the library base)
Old signatures still match as they are: TessellatorBegin 0xac2a408, TessellatorColor 0xac2a9bc,
RenderMeshImmediately2 0xb769d24, RenderMeshImmediately 0xb76a204, RenderMaterialGroupCommon 0x9cf8f98,
BlockSourceGetBlock 0x10371248, TessellateInWorld 0xaa62a0c, BTResetCache 0xaab2b90, BTSetBlockInCache 0xaab794c,
BlockRenderFlag 0xb8479d8, FindBlockState 0x10922530, Byte/Int/StringTagVtable, TessellatorClear 0xac2a360,
MatrixStackPush 0x11a191b8, BuildBlock 0x1009e2a0, GameModeTick 0x100a0ad8, SurvivalModeTick 0x100a14b8,
HandItem 0xfd9c620, BaseUseItem 0x100a0060.

Match only after the TLS register in the prologue is wildcarded (`5A D0 3B D5` became `5B D0 3B D5`):
TessellatorVertex 0xac2ac58.

Proven through RTTI (LocalPlayer vtable slot 25): LocalPlayer::normalTick 0xaf5e460
(old signature no longer matches; the runtime check "is in the LocalPlayer vtable" still works).

## NOT found yet (old signature no longer matches)
RenderLevel (REQUIRED for the hologram), ClientInstanceUpdate (optional), GetBlockTessellator,
BlockRegistryGetter, BlockLookupByName, TessellatorEndMesh, MeshDestroy, ItemBlockType, SelectSlot;
MeshRender and MatrixRefPop match twice (ambiguous).
Checked and rejected as RenderLevel: 0xb7c9790 (args this,int,ptr,int), 0xb7a4204 (this + 5 args).

## Адреса и сигнатуры для build-id eb291b88… (статический анализ, в игре не проверено)
Найдены сравнением со старой сборкой 56de9eed…: RenderLevel 0xb7a35d8, GetBlockTessellator 0xb79b088,
TessellatorEndMesh 0xac2c964, MeshRender 0x117ae714, MatrixRefPop 0x11a197d4, LocalPlayer::normalTick 0xaf5e460,
TessellatorVertex 0xac2ac58. Сигнатуры в Game.hpp теперь могут содержать варианты через `|`
(старая сборка | новая), Resolver.cpp (`find`) перебирает их по порядку.
Не найдены: BlockRegistryGetter, BlockLookupByName, MeshDestroy, ItemBlockType, SelectSlot.
ClientInstanceUpdate: кандидат 0x9b7b278 имеет лишний аргумент, не использовать (есть запасной путь через GameModeTick).
