#!/usr/bin/env python3
"""Static compatibility checks over structura/src (run by scripts/host_test.sh).

Each rule encodes a defect found in the 2.0 compatibility audit, so it cannot come back:
  R1  ModMenu unregister* only with Structura's own ids (2.0 removed other mods' modules every 2 s).
  R2  A preloader hook slot is never copied into another variable (rebuildChain rewrites it).
  R3  A preloader hook slot is never called directly (null during the install window); use
      lm::hookchain::chainNext inside the detour or chainPeek + null check outside it, or an explicit
      __atomic_load_n loop.
  R4  disable() does not clear mWatcherStarted (owned by the watcher thread).
  R5  no thread_local (banned for mods loaded by the preloader).
  Added in 1.21.5 (audit of the 1.21.4 fork):
  R6  PLRequestDocument is asynchronous (preloader InputBridge.cpp stores callback + userData and calls
      them from the activity result): its userData must be nullptr, never the address of a local.
  R7  GL_DEPTH_TEST is only toggled after glIsEnabled() and with a current EGL context (exact restore).
  R8  per-angle preview images (preloader image registry: shared by all mods, no unregister) are
      registered only under the kPreviewBudgetBytes budget.
"""
import pathlib
import re
import sys

SRC = pathlib.Path(__file__).resolve().parent.parent / "src"
files = {p: p.read_text() for p in sorted(SRC.glob("*.cpp")) + sorted(SRC.glob("*.hpp"))}
errors = []


def strip_comments(s):
    s = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), s, flags=re.S)
    return re.sub(r"//[^\n]*", "", s)


code = {p: strip_comments(s) for p, s in files.items()}

# R1 ----------------------------------------------------------------------------------------------
own_consts = {}
for p, s in code.items():
    for name, lit in re.findall(r'constexpr\s+const\s+char\s*\*\s*(k\w+)\s*=\s*"([^"]*)"', s):
        own_consts[name] = lit
n_unreg = 0
for p, s in code.items():
    for m in re.finditer(r"pl::modmenu::unregister(?:Module|Button)\s*\(\s*([^)]*?)\s*\)", s):
        n_unreg += 1
        arg = m.group(1)
        line = s.count("\n", 0, m.start()) + 1
        lit = arg[1:-1] if arg.startswith('"') else own_consts.get(arg)
        if lit is None or not lit.startswith("structura."):
            errors.append(f"R1 {p.name}:{line}: unregister with a non-Structura id: {arg}")

# R2/R3 -------------------------------------------------------------------------------------------
slots = set()
for p, s in code.items():
    for m in re.finditer(r"pl::memory::hook\s*\((.*?)\)\s*(?:==|!=|;|\))", s, flags=re.S):
        for sm in re.finditer(r"&\s*(\w+)\s*\)?\s*(?:,|$)", m.group(1)):
            name = sm.group(1)
            if re.fullmatch(r"[go][A-Z]\w*", name):
                slots.add(name)
for p, s in code.items():
    for name in slots:
        for m in re.finditer(r"\b" + name + r"\b", s):
            line = s.count("\n", 0, m.start()) + 1
            before = s[max(0, m.start() - 48):m.start()]
            after = s[m.end():m.end() + 2]
            if re.search(r"(chainNext|chainPeek)\s*\(\s*$", before) or re.search(r"__atomic_load_n\s*\(\s*&\s*$", before):
                continue
            if re.search(r"&\s*$", before):  # passed to hook() / address taken
                continue
            if re.search(r"\(\s*$", before) and after.startswith(")"):
                # inside a cast / call argument: only allowed as a hook() argument or a null test
                stmt = s[s.rfind(";", 0, m.start()) + 1:m.start()]
                if "pl::memory::hook" in stmt or "markHook" in stmt:
                    continue
                errors.append(f"R2 {p.name}:{line}: hook slot {name} used as a value")
                continue
            if after.lstrip().startswith("("):
                errors.append(f"R3 {p.name}:{line}: hook slot {name} called directly")
                continue
            stmt = s[max(s.rfind(";", 0, m.start()), s.rfind("{", 0, m.start()), s.rfind("}", 0, m.start())) + 1:m.end() + 40]
            if re.search(r"\b\w+\s*=\s*(?:reinterpret_cast<[^>]*>\s*\(\s*)?" + name + r"\b", stmt) and \
                    not re.search(r"\b" + name + r"\s*=", stmt):
                errors.append(f"R2 {p.name}:{line}: hook slot {name} copied")

# R4 ----------------------------------------------------------------------------------------------
main = code.get(SRC / "main.cpp", "")
m = re.search(r"bool\s+disable\s*\(\s*\)\s*\{(.*?)\n  \}", main, flags=re.S)
if not m:
    errors.append("R4 main.cpp: disable() not found")
elif "mWatcherStarted" in m.group(1):
    errors.append("R4 main.cpp: disable() touches mWatcherStarted")

# R5 ----------------------------------------------------------------------------------------------
for p, s in code.items():
    if re.search(r"\bthread_local\b", s):
        errors.append(f"R5 {p.name}: thread_local")

# R6 ----------------------------------------------------------------------------------------------
# raw text: strip_comments() would treat the "*/*" MIME literal as a comment delimiter
for p, s_ in files.items():
    ptrs = set(re.findall(r"(\w+)\s*=\s*reinterpret_cast<\w+>\(\s*dlsym\([^;]*\"PLRequestDocument\"", s_))
    for name in ptrs:
        for m in re.finditer(r"\b" + name + r"\s*\(", s_):
            depth, i = 1, m.end()
            while i < len(s_) and depth:
                depth += {"(": 1, ")": -1}.get(s_[i], 0)
                i += 1
            last = s_[m.end():i - 1].rsplit(",", 1)[-1].strip()
            line = s_.count("\n", 0, m.start()) + 1
            if last != "nullptr":
                errors.append(f"R6 {p.name}:{line}: PLRequestDocument userData must be nullptr (got {last})")

# R7 ----------------------------------------------------------------------------------------------
for p, s_ in code.items():
    if re.search(r'"glDisable"', s_) and not (re.search(r'"glIsEnabled"', s_) and "eglGetCurrentContext" in s_):
        errors.append(f"R7 {p.name}: glDisable without glIsEnabled/eglGetCurrentContext guard")

# R8 ----------------------------------------------------------------------------------------------
ui = code.get(SRC / "Ui.cpp", "")
for m in re.finditer(r"pl::modmenu::registerImage\s*\(\s*nid\b", ui):
    lam = ui[max(0, ui.rfind("auto ensurePrev", 0, m.start())):m.start()]
    if "kPreviewBudgetBytes" not in lam:
        errors.append(f"R8 Ui.cpp:{ui.count(chr(10), 0, m.start()) + 1}: preview registerImage without budget check")

print(f"compat_check: {len(slots)} hook slots, {n_unreg} unregister calls checked")
for e in errors:
    print("FAIL", e)
print(f"compat_check: {'OK' if not errors else str(len(errors)) + ' failure(s)'}")
sys.exit(1 if errors else 0)
