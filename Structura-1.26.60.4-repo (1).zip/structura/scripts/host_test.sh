#!/usr/bin/env bash
# Host tests (ASan+UBSan), no game. Run from anywhere: bash scripts/host_test.sh
# Needs build/block_pack.zip and build/java_map.bin (scripts/build.sh) for the runtime suite, and
# optionally the reference library (REF_SO, default ~/ref/game/libminecraftpe.so, build-id 56de9eed...)
# for the resolver fixture and the TestedBodies.inc regeneration check.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
SAN="-fsanitize=address,undefined"

# 1) static compatibility rules R1-R8 (R1-R5 from the 2.0.1 audit, R6-R8 from the 1.21.5 audit)
python3 scripts/compat_check.py

# 2) hook-slot semantics against a model of preloader-android rebuildChain (C2/C3)
g++ -std=c++20 -O1 -g -Wall -Wextra $SAN -pthread -o build/hookchain_test tests/compat/hookchain_test.cpp
build/hookchain_test

# 3) resolver: hooked-entry identity rules (2.0.2 backport)
g++ -std=c++20 -O1 -g -Wall -Wextra $SAN -Isrc -o build/resolver_rules_test tests/compat/resolver_rules_test.cpp
REF_SO="${REF_SO:-$HOME/ref/game/libminecraftpe.so}"
if [ -s "$REF_SO" ]; then
  cp src/TestedBodies.inc build/TestedBodies.committed
  python3 scripts/gen_tested_bodies.py "$REF_SO" --fixture build/ref_heads.tsv
  if ! cmp -s build/TestedBodies.committed src/TestedBodies.inc; then
    cp build/TestedBodies.committed src/TestedBodies.inc
    echo "FAIL src/TestedBodies.inc differs from the fingerprints generated from $REF_SO"; exit 1
  fi
  build/resolver_rules_test build/ref_heads.tsv
else
  build/resolver_rules_test
fi

# 4) launcher document picker callback lifetime (PLRequestDocument is asynchronous)
g++ -std=c++20 -O1 -g -Wall -Wextra $SAN -o build/document_cb_test tests/compat/document_cb_test.cpp
build/document_cb_test
# mutation: the 1.21.4 client must be caught by ASan (stack-use-after-return)
if ASAN_OPTIONS=detect_stack_use_after_return=1 build/document_cb_test --old >build/document_cb_old.txt 2>&1; then
  echo "FAIL document_cb --old: the 1.21.4 defect was not detected"; exit 1
fi
grep -q "stack-use-after-return" build/document_cb_old.txt && echo "document_cb --old: defect reproduced (stack-use-after-return)"

# 5) block-actor textured stand-ins (chests, signs, beds...): unit checks + every stand-in block must exist
#    in the reference samples (BEDROCK_SAMPLES, default ~/ref/game/bedrock-samples-v1.26.50.4-full.zip)
g++ -std=c++20 -O1 -g -Wall -Wextra $SAN -Isrc -o build/beproxy_test tests/beproxy_test.cpp
SAMPLES="${BEDROCK_SAMPLES:-$HOME/ref/game/bedrock-samples-v1.26.50.4-full.zip}"
if [ -s "$SAMPLES" ]; then
  unzip -p "$SAMPLES" metadata/vanilladata_modules/mojang-blocks.json >build/mojang-blocks.json
  python3 -c "import json;d=json.load(open('build/mojang-blocks.json'));open('build/block_names.txt','w').write(chr(10).join(e['name'] for e in d['data_items']))"
  build/beproxy_test build/block_names.txt >build/beproxy_out.tsv
  python3 - <<'PY'
import json
names = {l.strip() for l in open('build/block_names.txt') if l.strip()}
rows = [l.rstrip('\n').split('\t') for l in open('build/beproxy_out.tsv') if l.strip()]
bad = [r for r in rows if 'minecraft:' + r[1] not in names and not (r[2] and 'minecraft:' + r[2] in names)]
want = ['chest', 'trapped_chest', 'ender_chest', 'standing_sign', 'wall_sign', 'oak_hanging_sign', 'bed',
        'standing_banner', 'wall_banner', 'skeleton_skull', 'decorated_pot', 'white_shulker_box', 'copper_chest']
got = {r[0] for r in rows}
miss = [w for w in want if 'minecraft:' + w not in got]
print('beproxy samples: %d block-actor blocks with a stand-in, %d unknown stand-ins, %d expected missing' % (len(rows), len(bad), len(miss)))
if bad or miss:
    print('FAIL', bad, miss); raise SystemExit(1)
PY
else
  build/beproxy_test
  echo "beproxy samples cross-check skipped: $SAMPLES not found"
fi

# 6) Error Vision: verdict rules, bounded store, sweep, transformed coordinates, projection
g++ -std=c++20 -O1 -g -Wall -Wextra $SAN -Isrc -o build/error_vision_test tests/error_vision_test.cpp
build/error_vision_test
# mutation: if unnamed world blocks were trusted as "incorrect", the suite must fail
mkdir -p build/evmut
sed 's/if (!f.worldRead || !f.namesReady || !f.nameKnown) return Verdict::Unknown;/if (!f.worldRead) return Verdict::Unknown;/' \
  src/ErrorVision.hpp >build/evmut/ErrorVision.hpp
cmp -s src/ErrorVision.hpp build/evmut/ErrorVision.hpp && { echo "FAIL error_vision mutation did not apply"; exit 1; }
cp src/Structure.hpp build/evmut/
g++ -std=c++20 -O1 -Ibuild/evmut -o build/evmut/t tests/error_vision_test.cpp
if build/evmut/t >build/evmut/out.txt 2>&1; then echo "FAIL error_vision mutation not detected"; exit 1; fi
echo "error_vision mutation: detected ($(tail -1 build/evmut/out.txt))"

# mutate SRC FROM TO DIR: copies src/*.hpp to DIR with one literal replacement (must apply)
mutate() {
  rm -rf "$4"; mkdir -p "$4"; cp src/*.hpp "$4"/
  python3 - "$4/$1" "$2" "$3" <<'PY'
import sys
p, a, b = sys.argv[1:]
s = open(p).read()
if a not in s:
    sys.exit("FAIL mutation did not apply: " + p)
open(p, "w").write(s.replace(a, b, 1))
PY
}

# 6b) cyan hologram style: alpha range, tint, block-grid edges vs a brute-force reference, chunk packing
g++ -std=c++20 -O1 -g -Wall -Wextra $SAN -Isrc -o build/cyan_test tests/cyan_test.cpp
build/cyan_test
# mutation: without the single-owner rule, shared edges are drawn twice; the suite must fail
mutate CyanStyle.hpp 'if (!owner) continue;' '' build/cymut
g++ -std=c++20 -O1 -Ibuild/cymut -o build/cymut/t tests/cyan_test.cpp
if build/cymut/t >build/cymut/out.txt 2>&1; then echo "FAIL cyan mutation not detected"; exit 1; fi
echo "cyan mutation: detected ($(tail -1 build/cymut/out.txt))"
# mutation: the 1.21.8 tint (75% saturated cyan mixed into the light factor) must be rejected
mutate CyanStyle.hpp 'const uint32_t orr = (r * kMulR + 127) / 255, og = (g * kMulG + 127) / 255, ob = (b * kMulB + 127) / 255;' \
  'const uint32_t orr = (r * 25 + 0x38 * 75) / 100, og = (g * 25 + 0xD4 * 75) / 100, ob = (b * 25 + 0xFF * 75) / 100;' build/cymut2
g++ -std=c++20 -O1 -Ibuild/cymut2 -o build/cymut2/t tests/cyan_test.cpp
if build/cymut2/t >build/cymut2/out.txt 2>&1; then echo "FAIL cyan tint mutation not detected"; exit 1; fi
echo "cyan tint mutation: detected ($(tail -1 build/cymut2/out.txt))"

# 6e) Easy Place performance helpers (1.21.9): k-best run scan == old per-block rescans, per-step memo
#     never stale after forget(), state cache exact + epoch flush, trace ring accounting
g++ -std=c++20 -O1 -g -Wall -Wextra $SAN -pthread -Isrc -o build/ep_test tests/ep_test.cpp
build/ep_test
# mutation: ties resolved by the LAST cell instead of the first (old scan order) must be caught
mutate EpScan.hpp ': d2 < c.d2; };' ': d2 <= c.d2; };' build/epmut1
g++ -std=c++20 -O1 -pthread -Ibuild/epmut1 -o build/epmut1/t tests/ep_test.cpp
if build/epmut1/t >build/epmut1/out.txt 2>&1; then echo "FAIL ep scan tie mutation not detected"; exit 1; fi
echo "ep scan tie mutation: detected ($(tail -1 build/epmut1/out.txt))"
# mutation: a memo that ignores forget() (stale world after a placement) must be caught
mutate EpWorld.hpp 'if (w.stamp == stamp_ && w.x == x' 'if (w.stamp != 0 && w.x == x' build/epmut2
g++ -std=c++20 -O1 -pthread -Ibuild/epmut2 -o build/epmut2/t tests/ep_test.cpp
if build/epmut2/t >build/epmut2/out.txt 2>&1; then echo "FAIL ep memo forget mutation not detected"; exit 1; fi
echo "ep memo forget mutation: detected ($(tail -1 build/epmut2/out.txt))"
# mutation: a state cache that survives a world change must be caught
mutate SvCache.hpp 'if (epoch == epoch_) return;' 'return;' build/epmut3
g++ -std=c++20 -O1 -pthread -Ibuild/epmut3 -o build/epmut3/t tests/ep_test.cpp
if build/epmut3/t >build/epmut3/out.txt 2>&1; then echo "FAIL ep state cache epoch mutation not detected"; exit 1; fi
echo "ep state cache epoch mutation: detected ($(tail -1 build/epmut3/out.txt))"
python3 - <<'PY2'
import re, sys
bad = []
for f in ("src/EpScan.hpp", "src/EpWorld.hpp", "src/SvCache.hpp", "src/LineRing.hpp"):
    s = re.sub(r"//[^\n]*", "", open(f).read())  # code only, not comments
    for pat in (r"\bgl[A-Z]\w*\s*\(", r"\bdlopen\b", r"\bdlsym\b", r"memory::Hook", r"pl::hook", r"\bnew\s", r"malloc\("):
        if re.search(pat, s):
            bad.append(f + ": " + pat)
e = open("src/EasyPlace.cpp").read()
m = re.search(r"\nvoid trace\(const char \*fmt, \.\.\.\) \{(.*?)\n\}", e, re.S)
if not m:
    bad.append("EasyPlace.cpp: trace() not found")
elif re.search(r"::write|::open|ofstream|fopen", m.group(1)):
    bad.append("EasyPlace.cpp: trace() does file I/O on the calling (game) thread")
m = re.search(r"\nvoid flushLog\(\) \{(.*?)\n\}", e, re.S)
if not m or "lock_guard" not in m.group(1) or re.search(r"lock_guard[^}]*ofstream", m.group(1), re.S):
    bad.append("EasyPlace.cpp: flushLog() must not write the file while holding gLogMu")
h = open("src/Hologram.cpp").read()
m = re.search(r"constexpr size_t kCyanLinesPerFrame = (\d+);", h)
if not m or int(m.group(1)) > 8192 or h.count("kCyanLinesPerFrame") < 4:
    bad.append("Hologram.cpp: cyan grid lines must stay under a per-frame budget (<= 8192, both paths)")
if len(re.findall(r"W\.forget\(\);", e)) < 2:
    bad.append("EasyPlace.cpp: placeTarget must forget the step memo after each placeNow")
if bad:
    print("FAIL static rules (ep):\n  " + "\n  ".join(bad)); sys.exit(1)
print("static rules (ep): OK")
PY2

# 6c) Paste Schematic export: transforms, modes, validation, incremental/cancel/stale, pack files
g++ -std=c++20 -O1 -g -Wall -Wextra $SAN -Isrc -o build/paste_test tests/paste_test.cpp src/Nbt.cpp
build/paste_test
# mutation: "Place Non-Air Only" writing air would replace world blocks; the suite must fail
mutate Paste.hpp 'if (mode_ == Mode::NonAirOnly) { ++stats.kept; return -1; }' '' build/pamut
g++ -std=c++20 -O1 -Ibuild/pamut -o build/pamut/t tests/paste_test.cpp src/Nbt.cpp
if build/pamut/t >build/pamut/out.txt 2>&1; then echo "FAIL paste mutation not detected"; exit 1; fi
echo "paste mutation: detected ($(tail -1 build/pamut/out.txt))"
# mutation: pasting without the Creative check; the suite must fail
mutate Paste.hpp 'if (creative == 0) return Block::NotCreative;' '' build/pamut2
g++ -std=c++20 -O1 -Ibuild/pamut2 -o build/pamut2/t tests/paste_test.cpp src/Nbt.cpp
if build/pamut2/t >build/pamut2/out.txt 2>&1; then echo "FAIL paste creative mutation not detected"; exit 1; fi
echo "paste creative mutation: detected ($(tail -1 build/pamut2/out.txt))"

# 6d) static rules for the new code: pure headers (no GL/EGL/dlopen/hooks), the cyan style adds no raw GL
# state (it only reuses the existing material path), paste never runs on the render path
python3 - <<'PY'
import re, sys
bad = []
for f in ("src/CyanStyle.hpp", "src/Paste.hpp"):
    s = open(f).read()
    for pat in (r"\bgl[A-Z]\w*\s*\(", r"\begl\w*\s*\(", r"\bdlopen\b", r"\bdlsym\b", r"GLES", r"memory::Hook", r"pl::hook"):
        if re.search(pat, s):
            bad.append(f + ": " + pat)
h = open("src/Hologram.cpp").read()
m = re.search(r"struct XrayLineScope.*?\n};", h, re.S)
if not m:
    bad.append("Hologram.cpp: XrayLineScope not found")
for line in h.splitlines():
    if "cyan" in line.lower() and ("XrayLineScope" in line or re.search(r"\bgl[A-Z]\w*\s*\(", line)):
        bad.append("Hologram.cpp cyan line uses raw GL: " + line.strip())
a = open("src/App.cpp").read()
calls = re.findall(r"\brunPaste\(", a)
if len(calls) != 2 or not re.search(r"postJob\(\[[^\]]*\]\s*\{\s*runPaste\(", a) or "paste::runEncode" not in a:
    bad.append("App.cpp: runPaste must be defined once and only called from a worker job")
if "Paste.hpp" in h or "paste::" in h:
    bad.append("Hologram.cpp (render path) references paste")
if bad:
    print("FAIL static rules:\n  " + "\n  ".join(bad)); sys.exit(1)
print("static rules (cyan/paste): OK")
PY

# 7) existing runtime suite (transforms, parser states, progress model, layers)
if [ -s build/block_pack.zip ] && [ -s build/java_map.bin ]; then
  gcc -c -Wa,-Ibuild src/BlockPack.S -o build/bp_host.o
  g++ -std=c++20 -O1 -g $SAN -Isrc tests/host_test.cpp src/BlockStates.cpp src/Structure.cpp src/Nbt.cpp \
    src/JavaFormats.cpp src/Transformed.cpp src/Progress.cpp build/bp_host.o -lz -o build/host_test
  ASAN_OPTIONS=max_allocation_size_mb=1024 build/host_test
  # paste round trip with the real loader and transformed-state table
  g++ -std=c++20 -O1 -g $SAN -Isrc tests/paste_roundtrip_test.cpp src/BlockStates.cpp src/Structure.cpp src/Nbt.cpp \
    src/JavaFormats.cpp src/Transformed.cpp build/bp_host.o -lz -o build/paste_roundtrip_test
  build/paste_roundtrip_test
else
  echo "runtime suite skipped: run scripts/build.sh first"
fi
