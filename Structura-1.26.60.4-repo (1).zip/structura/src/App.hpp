#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include <pl/Logger.hpp>

#include "Library.hpp"

namespace lm::app {

void init(const std::string &myDir, pl::log::Logger *log);
void shutdown();
bool postJob(std::function<void()> job);  // false: queue full, job dropped


void rescan(const std::string &selectPath = {});
std::vector<lib::Entry> library();
uint64_t libraryRevision();
std::string myDir();
std::string lastImport();

// 导入记录（最近若干条，新的在前）：用于界面上显示"导入完成了什么"
struct ImportRecord {
  std::string name;
  bool ok = false;
  int64_t at = 0;
  std::string detail;
};
std::vector<ImportRecord> importRecords();
// 扫描候选（不直接导入）：import/ 与 Download/ 下符合扩展名的文件
struct ScanCandidate {
  std::string name;
  std::string path;
};
std::vector<ScanCandidate> scanCandidates();
void importPaths(const std::vector<std::string> &paths);   // 用户勾选后导入  
std::string rootsInfo();
void importFile();  


void select(const std::string &path);
void removeSelected();  
void removeFile(const std::string &path);
void removeFiles(const std::vector<std::string> &paths);   // 批量删除（逐个走 removeFile）  
void renameFile(const std::string &path, const std::string &newTitle);
void exportFile(const std::string &path);  
void setExportDir(const std::string &dir);  
bool canModify(const lib::Entry &e);       
std::string selectedPath();
void closeProjection();   // 关掉本次投影：取消放置 + 关 Easy Place（结构仍保持选中）
bool projectionActive();  // 当前是否有投影在挂着
void placeHere();
void placeInFront();                         
void moveRel(int fwd, int right, int up);   
void facing(int &fx, int &fz);               
void nudge(int dx, int dy, int dz);
void rotate();
void mirror();
void rotateLeft();
void layerDelta(int d);
void layer2Delta(int d);
void cycleLayerMode();
void cycleLayerAxis();
int layerSize();       
void setLayerToFeet();
void setLayer(int index);     // select a layer (overlay); never places blocks
void setLayerMode(int mode);  // LayerMode 0..4
int currentLayer();  


void cornerHere(int which);
void cornersY(int d);
void clearCorners();
void capture();
void poll();  

// ---- Paste Schematic (Creative). Structura never writes blocks itself: it exports the placed
// schematic (rotation/mirror/offset baked in) to the "Structura Paste" development behavior pack and
// produces the /structure load command; the game executes it under its own permissions (Paste.hpp).
struct PasteInfo {
  int state = 0;  // 0 idle, 1 queued, 2 encoding, 3 done, 4 failed, 5 cancelled
  int pct = 0;
  std::string id, command, where, error;
  bool copied = false;
  int roots = 0, rootsOk = 0;
  size_t cells = 0, placed = 0, kept = 0, air = 0, water = 0, inexact = 0, noStates = 0, rawDropped = 0;
};
int pasteBlock();            // paste::Block why the action is unavailable (0 = available)
bool pasteStart(int mode);   // paste::Mode; false = refused (pasteBlock() says why) or queue full
void pasteCancel();          // before the files are written; nothing is written then
void pasteDismiss();         // done/failed/cancelled -> idle
bool pasteCopyCommand();     // copy the last command again
PasteInfo pasteInfo();

}  
