#pragma once
// Block-actor blocks (chests, signs, beds, banners, skulls, shulker boxes, decorated pots...) are drawn by
// the game's BlockActorRenderer, not by the BlockTessellator, so tessellating them for the hologram yields
// no geometry and they used to fall back to the flat blue "missing" box.
//
// This maps such a block to a textured stand-in: an ordinary full-cube block of the same material (planks of
// the same wood, wool, concrete, obsidian...) that the BlockTessellator does draw, plus one or two boxes
// (in block units, 0..1) its cube is squeezed into, so the hologram shows the real silhouette with a
// matching game texture. Pure data: no game calls, unit tested on the host (tests/host_test.cpp).
//
// Only used for blocks that already produced zero vertices, so a misclassified ordinary block can never
// lose its real model.

#include <cstdint>
#include <cstring>
#include <string>
#include <string_view>
#include <vector>

#include "Structure.hpp"

namespace lm::beproxy {

struct Box {
  float x0, y0, z0, x1, y1, z1;
};

struct Proxy {
  bool ok = false;
  const char *what = "";      // "chest", "wall sign"... (diagnostics)
  std::string block;          // stand-in block, short name ("oak_planks")
  std::string fallback;       // tried when `block` is unknown to this game version ("" = none)
  int n = 0;                  // boxes used (1..2)
  Box box[2]{};
};

namespace detail {

inline bool ends(std::string_view s, std::string_view suf) {
  return s.size() >= suf.size() && s.compare(s.size() - suf.size(), suf.size(), suf) == 0;
}
inline bool has(std::string_view s, std::string_view part) { return s.find(part) != std::string_view::npos; }
inline std::string_view shortOf(std::string_view n) {
  const size_t c = n.find(':');
  return c == std::string_view::npos ? n : n.substr(c + 1);
}

// Integer state by key (with or without the "minecraft:" prefix); -1 when absent.
inline int intState(const std::vector<BlockStateValue> &st, std::string_view key) {
  for (const auto &sv : st) {
    if (sv.type == 8) continue;  // nbt::String
    if (shortOf(sv.key) == key) return sv.i;
  }
  return -1;
}
// Facing 0..5 (down, up, north, south, west, east) from the int or string form of facing_direction
// (or Java's "facing"); -1 when absent.
inline int facing6(const std::vector<BlockStateValue> &st) {
  const int i = intState(st, "facing_direction");
  if (i >= 0 && i <= 5) return i;
  static const char *k[6] = {"down", "up", "north", "south", "west", "east"};
  for (const auto &sv : st) {
    if (sv.type != 8) continue;
    const std::string_view key = shortOf(sv.key);
    if (key != "facing_direction" && key != "facing" && key != "cardinal_direction") continue;
    for (int f = 0; f < 6; ++f)
      if (sv.s == k[f]) return f;
  }
  return -1;
}
// Sign/banner rotation 0..15 (Bedrock ground_sign_direction, Java rotation); -1 when absent.
inline int rot16(const std::vector<BlockStateValue> &st) {
  int r = intState(st, "ground_sign_direction");
  if (r < 0) r = intState(st, "rotation");
  return (r >= 0 && r <= 15) ? r : -1;
}

constexpr float px(float v) { return v / 16.f; }

// A thin panel standing in the block centre; spans X when the rotation faces south/north (0, 8),
// spans Z when it faces west/east (4, 12). Diagonal rotations pick the nearer axis.
inline Box centrePanel(int r16, float y0, float y1, float half, float inset) {
  const bool spansX = r16 < 0 || (((r16 + 2) / 4) & 1) == 0;
  if (spansX) return {inset, y0, 0.5f - half, 1.f - inset, y1, 0.5f + half};
  return {0.5f - half, y0, inset, 0.5f + half, y1, 1.f - inset};
}
// A panel of `thick` against the wall the block hangs on. facing = direction the front looks at
// (2 north, 3 south, 4 west, 5 east); the supporting block is on the opposite side.
inline Box wallPanel(int facing, float y0, float y1, float thick, float inset) {
  switch (facing) {
    case 2: return {inset, y0, 1.f - thick, 1.f - inset, y1, 1.f};
    case 3: return {inset, y0, 0.f, 1.f - inset, y1, thick};
    case 4: return {1.f - thick, y0, inset, 1.f, y1, 1.f - inset};
    case 5: return {0.f, y0, inset, thick, y1, 1.f - inset};
    default: return {inset, y0, 0.5f - thick * 0.5f, 1.f - inset, y1, 0.5f + thick * 0.5f};
  }
}

// Wood type of a sign name -> planks block. "standing_sign"/"wall_sign" are oak; "darkoak_" is dark oak.
inline std::string planksFor(std::string_view n) {
  static const char *kWoods[] = {"pale_oak", "dark_oak", "darkoak", "spruce", "birch", "jungle", "acacia",
                                 "mangrove", "cherry", "bamboo", "crimson", "warped", "poplar"};
  for (const char *w : kWoods) {
    if (n.compare(0, std::strlen(w), w) != 0) continue;
    if (std::strcmp(w, "darkoak") == 0) return "dark_oak_planks";
    return std::string(w) + "_planks";
  }
  return "oak_planks";
}

inline std::string colourPrefix(std::string_view n, std::string_view suffix) {
  if (!ends(n, suffix) || n.size() == suffix.size()) return "";
  return std::string(n.substr(0, n.size() - suffix.size()));
}

}  // namespace detail

// `name`: palette name (short or "minecraft:..."); `st`: the transformed (rotated/mirrored) states.
inline Proxy classify(std::string_view name, const std::vector<BlockStateValue> &st) {
  using namespace detail;
  const std::string_view n = shortOf(name);
  Proxy p;
  auto one = [&](const char *what, std::string block, Box b, std::string fb = "") {
    p.ok = true;
    p.what = what;
    p.block = std::move(block);
    p.fallback = std::move(fb);
    p.n = 1;
    p.box[0] = b;
  };
  const Box full{0.f, 0.f, 0.f, 1.f, 1.f, 1.f};

  // ---- shulker boxes: full cube, same colour
  if (ends(n, "shulker_box")) {
    const std::string c = colourPrefix(n, "_shulker_box");
    if (c.empty() || c == "undyed") one("shulker box", "purpur_block", full);
    else one("shulker box", c + "_concrete", full, "purpur_block");
    return p;
  }
  // ---- chests (chest, trapped_chest, ender_chest, [waxed_][exposed_|weathered_|oxidized_]copper_chest)
  if (n == "chest" || n == "trapped_chest" || n == "ender_chest" || ends(n, "copper_chest")) {
    const Box b{px(1), 0.f, px(1), px(15), px(14), px(15)};
    if (n == "ender_chest") {
      one("ender chest", "obsidian", b);
    } else if (ends(n, "copper_chest")) {
      std::string_view m = n.substr(0, n.size() - std::strlen("copper_chest"));
      if (m.compare(0, 6, "waxed_") == 0) m.remove_prefix(6);
      one("copper chest", m.empty() ? "copper_block" : std::string(m) + "copper", b, "copper_block");
    } else {
      one(n == "chest" ? "chest" : "trapped chest", "oak_planks", b);
    }
    return p;
  }
  // ---- signs
  if (ends(n, "_sign") || n == "sign") {
    const std::string planks = planksFor(n);
    if (has(n, "hanging_sign")) {
      // Hanging sign: board under the supporting block; attached (chains in a V) uses the 16-way rotation,
      // otherwise the 4-way facing decides the axis.
      const int f = facing6(st);
      int r = intState(st, "attached_bit") > 0 ? rot16(st) : -1;
      if (r < 0) r = (f == 4 || f == 5) ? 4 : 0;
      one("hanging sign", planks, centrePanel(r, 0.f, px(10), px(1), px(1)), "oak_planks");
    } else if (has(n, "wall_sign")) {
      one("wall sign", planks, wallPanel(facing6(st), px(4.5f), px(12.5f), px(2), 0.f), "oak_planks");
    } else {
      const int r = rot16(st);
      one("standing sign", planks, centrePanel(r, px(8), 1.f, px(1), 0.f), "oak_planks");
      p.n = 2;
      p.box[1] = {px(7), 0.f, px(7), px(9), px(8), px(9)};  // post
    }
    return p;
  }
  // ---- beds (Bedrock "bed" keeps the colour in the block entity; Java "<colour>_bed")
  if (n == "bed" || (ends(n, "_bed") && !has(n, "flower") && !has(n, "straw"))) {
    const std::string c = colourPrefix(n, "_bed");
    one("bed", c.empty() ? "red_wool" : c + "_wool", {0.f, 0.f, 0.f, 1.f, px(9), 1.f}, "red_wool");
    return p;
  }
  // ---- banners (Bedrock keeps the colour in the block entity; Java "<colour>_[wall_]banner")
  if (ends(n, "banner")) {
    std::string c = colourPrefix(n, has(n, "wall_banner") ? "_wall_banner" : "_banner");
    if (c == "standing") c.clear();
    const std::string wool = c.empty() ? "white_wool" : c + "_wool";
    if (has(n, "wall_banner")) {
      one("wall banner", wool, wallPanel(facing6(st), 0.f, 1.f, px(1), px(1)), "white_wool");
    } else {
      one("banner", wool, centrePanel(rot16(st), px(2), 1.f, px(0.5f), px(1)), "white_wool");
      p.n = 2;
      p.box[1] = {px(7.5f), 0.f, px(7.5f), px(8.5f), px(2), px(8.5f)};  // pole
    }
    return p;
  }
  // ---- heads and skulls (floor: centred 8x8x8; wall: against the supporting block)
  if (ends(n, "_skull") || ends(n, "_head") || n == "skull") {
    if (has(n, "vines")) return p;  // cave_vines_head_with_berries is an ordinary plant
    std::string block = "bone_block";
    if (has(n, "wither")) block = "coal_block";
    else if (has(n, "zombie")) block = "green_terracotta";
    else if (has(n, "creeper")) block = "lime_concrete";
    else if (has(n, "dragon")) block = "black_concrete";
    else if (has(n, "piglin")) block = "pink_terracotta";
    else if (has(n, "player")) block = "brown_terracotta";
    const int f = facing6(st);
    const bool wall = has(n, "wall_") || (f >= 2 && f <= 5);
    Box b{px(4), 0.f, px(4), px(12), px(8), px(12)};
    if (wall) {
      switch (f) {
        case 2: b = {px(4), px(4), px(8), px(12), px(12), 1.f}; break;
        case 3: b = {px(4), px(4), 0.f, px(12), px(12), px(8)}; break;
        case 4: b = {px(8), px(4), px(4), 1.f, px(12), px(12)}; break;
        case 5: b = {0.f, px(4), px(4), px(8), px(12), px(12)}; break;
        default: break;
      }
    }
    one("head", block, b, "bone_block");
    return p;
  }
  // ---- other block-actor shapes
  if (n == "decorated_pot") { one("decorated pot", "hardened_clay", {px(1), 0.f, px(1), px(15), 1.f, px(15)}, "terracotta"); return p; }
  if (n == "flower_pot") { one("flower pot", "hardened_clay", {px(5), 0.f, px(5), px(11), px(6), px(11)}, "terracotta"); return p; }
  if (n == "bell") { one("bell", "gold_block", {px(4), px(3), px(4), px(12), px(13), px(12)}); return p; }
  if (n == "conduit") { one("conduit", "prismarine", {px(5), px(5), px(5), px(11), px(11), px(11)}); return p; }
  if (n == "frame" || n == "glow_frame" || ends(n, "item_frame")) {
    const int f = facing6(st);
    Box b = wallPanel(f, px(2), px(14), px(1), px(2));
    if (f == 0) b = {px(2), 1.f - px(1), px(2), px(14), 1.f, px(14)};
    if (f == 1) b = {px(2), 0.f, px(2), px(14), px(1), px(14)};
    one("item frame", "oak_planks", b);
    return p;
  }
  return p;
}

}  // namespace lm::beproxy
