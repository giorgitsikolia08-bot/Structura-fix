

    .section .rodata.structura_block_pack, "a"
    .balign 16
    .global structura_block_pack
    .hidden structura_block_pack
structura_block_pack:
    .incbin "block_pack.zip"
    .global structura_block_pack_end
    .hidden structura_block_pack_end
structura_block_pack_end:
    .byte 0
    .section .rodata.structura_java_map, "a"
    .balign 16
    .global structura_java_map
    .hidden structura_java_map
structura_java_map:
    .incbin "java_map.bin"
    .global structura_java_map_end
    .hidden structura_java_map_end
structura_java_map_end:
    .byte 0
#if defined(__ELF__)
    .section .note.GNU-stack, "", %progbits
#endif
