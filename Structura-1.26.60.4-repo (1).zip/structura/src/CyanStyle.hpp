#pragma once
// Cyan hologram style (holoStyle == 2): pure helpers, no game calls, no GL calls.
//
// The style only changes data the existing hologram pipeline already produces:
//   * vertex colours of the textured block meshes (tint)  -> same Tessellator path as the native style
//   * the per-vertex alpha (always translucent)           -> same "particles_blend" material
//   * thin block-grid edges added to the existing line list -> same flushLines/selection_box material
// Blending, depth test and depth writes are whatever those game materials define; this style never
// touches GL state (the only GL-level code in Structura stays the experimental XrayLineScope).
//
// 1.21.9 colour model (why 1.21.8 looked dark teal / washed out):
//   The Tessellator vertex colour is NOT the texture colour. In the block shader the final colour is
//   texture * vertexColour, and the vertex colour the block tessellator writes is the light/AO/biome
//   factor (near white for a lit face). 1.21.8 mixed 75% of a saturated cyan (0x38D4FF) into that
//   factor, i.e. multiplied every texture by ~(0.42, 0.87, 1.0) -> grey stone became dark teal, and at
//   alpha 0.185..0.50 the world showed through strongly. 1.21.9 multiplies the light factor by a mild
//   cyan-blue cast measured on the reference screenshot (faces ~ (0.82, 0.95, 1.0) of a neutral
//   texture) so textures stay readable, and raises the alpha range so the surfaces read as a hologram.
//   Packing verified on the reference binary: Tessellator::color (0xa76edac) stores
//   a<<24 | b<<16 | g<<8 | r (r = low byte), the order decoded below.

#include <algorithm>
#include <cstdint>

namespace lm::cyan {

inline constexpr int kStyle = 2;            // Settings::holoStyle value
inline constexpr int kTintMode = 3;         // TexFrame::tint value used by texBlock
// Cyan-blue cast applied to the light factor (x/255): red 0.82, green 0.95, blue 1.0.
inline constexpr uint32_t kMulR = 209, kMulG = 242, kMulB = 255;
// Flat colour of untextured cyan cells (fallback when block textures are not available): the average
// face colour measured on the reference (~ (107,124,131)) brightened to a lit face.
inline constexpr uint32_t kRgb = 0x8FC6DA;  // 0xRRGGBB
// Grid lines: light cyan, nearly opaque, 1 px (selection_box line material).
inline constexpr float kEdgeR = 0.42f, kEdgeG = 0.88f, kEdgeB = 1.0f, kEdgeA = 0.95f;
inline constexpr float kAlphaMin = 0.50f, kAlphaSpan = 0.38f;
// Lines are pushed this far (blocks) off the faces they lie on, toward the empty side, so they are not
// coplanar with the (inset) hologram faces nor with world blocks touching the hologram (no z-fighting).
inline constexpr float kEdgeLift = 0.006f;

// Opacity slider (0.1..1) -> hologram alpha 0.538..0.88 (always < 0.99: translucent material).
inline float alphaFor(float opacity) {
  const float o = std::clamp(opacity, 0.f, 1.f);
  return kAlphaMin + kAlphaSpan * o;
}

// Light-factor vertex colour (ABGR as stored by the Tessellator: r = low byte) -> cyan cast, same
// alpha byte. A pure per-channel multiply: brightness order and texture detail are preserved, white
// stays the brightest, nothing is clipped, and the blue channel is untouched.
inline uint32_t tint(uint32_t abgr, uint8_t alpha) {
  const uint32_t r = abgr & 0xFF, g = (abgr >> 8) & 0xFF, b = (abgr >> 16) & 0xFF;
  const uint32_t orr = (r * kMulR + 127) / 255, og = (g * kMulG + 127) / 255, ob = (b * kMulB + 127) / 255;
  return (uint32_t(alpha) << 24) | (ob << 16) | (og << 8) | orr;
}

// Face directions, same order as Hologram.cpp (d[] / faceQuad): +y -y -z +z -x +x; opposite = f ^ 1.
inline constexpr int kDir[6][3] = {{0, 1, 0}, {0, -1, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, 0}, {1, 0, 0}};

// ---- block-grid edges -------------------------------------------------------------------------------
// The reference draws a thin line on every visible block seam, not only on the silhouette. A unit edge
// of the block grid is drawn when 1..3 of the 4 cells around it are hologram cells (n == 4: inside the
// volume, invisible). Every such edge is emitted exactly once, by its OWNER: the first occupied cell in
// the order (u,v) = (0,0) (0,1) (1,0) (1,1), where cell(u,v) = point - (1-u) on axis b - (1-v) on axis c.
// Axis ids: 0 = x, 1 = y, 2 = z; for an edge along axis a the perpendicular axes are b = (a+1)%3,
// c = (a+2)%3. lift b/c in {-1,0,1}: the side the line is pushed to (toward the empty cells).
// emit(a, px, py, pz, liftB, liftC): edge from point (px,py,pz) one unit along axis a (world coords).
template <class Occ, class Emit>
int gridEdgesFor(int x, int y, int z, Occ &&occ, Emit &&emit) {
  int n = 0;
  const int cell[3] = {x, y, z};
  for (int a = 0; a < 3; ++a) {
    const int b = (a + 1) % 3, c = (a + 2) % 3;
    for (int db = 0; db < 2; ++db)
      for (int dc = 0; dc < 2; ++dc) {
        // edge point: this cell's corner on axis b/c
        int p[3] = {cell[0], cell[1], cell[2]};
        p[b] += db;
        p[c] += dc;
        bool o[2][2];
        int cnt = 0;
        for (int u = 0; u < 2; ++u)
          for (int v = 0; v < 2; ++v) {
            int q[3] = {p[0], p[1], p[2]};
            q[b] += u - 1;
            q[c] += v - 1;
            o[u][v] = (u == 1 - db && v == 1 - dc) ? true : bool(occ(q[0], q[1], q[2]));
            cnt += o[u][v];
          }
        if (cnt == 4) continue;  // interior edge
        const int me = (1 - db) * 2 + (1 - dc);  // this cell's index in the owner order
        bool owner = true;
        for (int k = 0; k < me && owner; ++k)
          if (o[k >> 1][k & 1]) owner = false;
        if (!owner) continue;
        int sb = 0, sc = 0;  // empty cells pull the line toward them
        for (int u = 0; u < 2; ++u)
          for (int v = 0; v < 2; ++v)
            if (!o[u][v]) {
              sb += u ? 1 : -1;
              sc += v ? 1 : -1;
            }
        emit(a, p[0], p[1], p[2], (sb > 0) - (sb < 0), (sc > 0) - (sc < 0));
        ++n;
      }
  }
  return n;
}

// Compact edge record cached per hologram chunk (4 bytes instead of a 40-byte line): point relative to
// the chunk origin (0..16 per axis, 5 bits each), axis (2 bits), lifts (2 bits each).
inline uint32_t packEdge(int a, int lx, int ly, int lz, int liftB, int liftC) {
  auto l2 = [](int s) { return uint32_t(s > 0 ? 1 : s < 0 ? 2 : 0); };
  return uint32_t(a) | uint32_t(lx) << 2 | uint32_t(ly) << 7 | uint32_t(lz) << 12 | l2(liftB) << 17 | l2(liftC) << 19;
}
inline bool packable(int lx, int ly, int lz) {
  return lx >= 0 && lx <= 16 && ly >= 0 && ly <= 16 && lz >= 0 && lz <= 16;
}
// Segment endpoints in world coordinates (lift applied) for a packed edge of a chunk at (ox, oy, oz).
inline void unpackEdge(uint32_t e, int ox, int oy, int oz, float A[3], float B[3]) {
  const int a = int(e & 3), b = (a + 1) % 3, c = (a + 2) % 3;
  auto s2 = [](uint32_t v) { return v == 1 ? 1.f : v == 2 ? -1.f : 0.f; };
  A[0] = float(ox + int((e >> 2) & 31));
  A[1] = float(oy + int((e >> 7) & 31));
  A[2] = float(oz + int((e >> 12) & 31));
  A[b] += kEdgeLift * s2((e >> 17) & 3);
  A[c] += kEdgeLift * s2((e >> 19) & 3);
  B[0] = A[0]; B[1] = A[1]; B[2] = A[2];
  B[a] += 1.f;
}

}  // namespace lm::cyan
