#pragma once
// Easy Place run-mode scan (pure, no game calls): the k next targets of one step in ONE pass.
//
// Before 1.21.9, runTarget scanned the whole reach box (up to 13^3 cells, a world read + structure lookup
// per candidate cell) for every block of a batch (epBatch 1..4), i.e. up to 4 full scans per step. This
// scan visits the box once and keeps the k best cells, in exactly the order the repeated single scans
// would have picked them as long as each placement only fills its own cell:
//   * not bottom-up: smallest distance, ties -> the first cell in scan order (y, x, z ascending);
//   * bottom-up:     lowest y layer first, then smallest distance inside the layer, same tie rule.
// The caller still re-verifies every candidate after the previous placement (fresh world read, discard
// list), so a cell filled by a support placement or changed by the game is skipped, never placed twice.
// `missing(x, y, z)` is the caller's full predicate (expected block, replaceable world cell, not
// discarded); it is only called for cells that can still enter the list (the old `d2 >= best` pruning,
// against the k-th best). Every cell in reach is asked at most once per step (old: up to k times). On a
// random mix this is ~43% fewer predicate calls (tests/ep_test.cpp); a single case can need more than
// the old k pruned scans (the list must fill before it prunes), never more than one call per cell.

#include <cstdint>

namespace lm::epscan {

struct Cell {
  int x = 0, y = 0, z = 0;
  float d2 = 0.f;
};

inline constexpr int kMaxK = 8;

// Box b = {x0, x1, y0, y1, z0, z1} (inclusive, already clipped to the reach cube), eye position, squared
// reach limit. Returns the number of cells written to out (<= k).
template <class Missing>
int nearest(const int b[6], float ex, float ey, float ez, float lim, bool bottomUp, int k, Missing &&missing,
            Cell *out) {
  if (k < 1) return 0;
  if (k > kMaxK) k = kMaxK;
  int n = 0;
  // strict "better than" in the pick order; equal keys keep scan order (first found wins)
  auto better = [bottomUp](int y, float d2, const Cell &c) { return bottomUp ? (y < c.y || (y == c.y && d2 < c.d2)) : d2 < c.d2; };
  for (int y = b[2]; y <= b[3]; ++y) {
    // bottom-up: once the list is full, a higher layer can never enter it
    if (bottomUp && n == k && y > out[k - 1].y) break;
    for (int x = b[0]; x <= b[1]; ++x)
      for (int z = b[4]; z <= b[5]; ++z) {
        const float dx = x + 0.5f - ex, dy = y + 0.5f - ey, dz = z + 0.5f - ez;
        const float d2 = dx * dx + dy * dy + dz * dz;
        if (d2 > lim) continue;
        if (n == k && !better(y, d2, out[k - 1])) continue;  // cannot enter the list: no query
        if (!missing(x, y, z)) continue;
        // insert after every entry that is not worse (stable: equal keys stay in scan order)
        int i = n < k ? n : k - 1;
        while (i > 0 && better(y, d2, out[i - 1])) {
          out[i] = out[i - 1];
          --i;
        }
        out[i] = Cell{x, y, z, d2};
        if (n < k) ++n;
      }
  }
  return n;
}

}  // namespace lm::epscan
