#pragma once
// Per-step memo of the world/structure queries of ONE Easy Place step (pure; game thread only).
//
// One step (a tap, an auto-place tick or a run batch) asks for the same cells many times: the crosshair
// ray tests a cell and then its 6 neighbours (solidNeighbor), choosePlan tests the 6 faces again, the run
// scan and its support search overlap. Before 1.21.9 every one of those questions went to the API
// (structure snapshot under the model mutex + shared_ptr copy, region pointer chase = 2 syscalls, a
// getBlock call, a name-cache mutex).
//
// Rules (correctness first):
//   * Bounded: fixed direct-mapped tables, no allocation, nothing survives the step (the object lives on
//     the step's stack).
//   * World answers are invalidated explicitly with forget() after anything that can change the world
//     (every placement attempt), so post-placement checks always read the world again. The checks that
//     must be fresh by design (changed(), verifyPlaced, rechecks) keep calling the API directly.
//   * Structure answers (expected block of a cell) do not depend on the world and stay valid for the step;
//     an unresolved expected block (0, the game block is still being resolved) is never memoised, so the
//     resolver keeps its own retry rules.
//   * Block -> replaceable answers depend only on the Block* (the per-world cache behind it is the same
//     one the API uses), memoised per step.
// Backend: int expected(x, y, z, uintptr_t *out); uintptr_t world(x, y, z); int replaceableOf(uintptr_t b).

#include <cstdint>
#include <cstring>

namespace lm::epw {

struct Stats {
  uint32_t expectedCalls = 0, expectedHits = 0, worldCalls = 0, worldHits = 0, repCalls = 0, repHits = 0;
};

template <class Backend>
class StepWorld {
 public:
  static constexpr int kPos = 256, kRep = 64;

  explicit StepWorld(Backend &b) : B_(b) {
    std::memset(static_cast<void *>(w_), 0, sizeof(w_));
    std::memset(static_cast<void *>(e_), 0, sizeof(e_));
    std::memset(static_cast<void *>(r_), 0, sizeof(r_));
  }
  StepWorld(const StepWorld &) = delete;
  StepWorld &operator=(const StepWorld &) = delete;

  // 1 = the cell belongs to the (visible) structure, *out = expected game block (0 = unresolved / air).
  int expected(int x, int y, int z, uintptr_t *out) const {
    ++st_.expectedCalls;
    E &e = e_[slot(x, y, z)];
    if (e.used && e.x == x && e.y == y && e.z == z) {
      ++st_.expectedHits;
      if (out) *out = e.block;
      return e.r;
    }
    uintptr_t b = 0;
    const int r = B_.expected(x, y, z, &b);
    if (out) *out = b;
    if (r == 0 || b != 0) e = E{x, y, z, b, int8_t(r), 1};  // never memoise "in structure, not resolved"
    return r;
  }

  // Current world block (0 = not loaded / no world).
  uintptr_t world(int x, int y, int z) const {
    ++st_.worldCalls;
    W &w = w_[slot(x, y, z)];
    if (w.stamp == stamp_ && w.x == x && w.y == y && w.z == z) {
      ++st_.worldHits;
      return w.block;
    }
    const uintptr_t b = B_.world(x, y, z);
    w = W{x, y, z, b, stamp_};
    return b;
  }

  // 1 replaceable, 0 occupied, -1 unknown (not loaded / name unknown).
  int replaceableBlock(uintptr_t b) const {
    if (!b) return -1;
    ++st_.repCalls;
    R &r = r_[(b >> 4) & (kRep - 1)];
    if (r.block == b) {
      ++st_.repHits;
      return r.rep;
    }
    const int v = B_.replaceableOf(b);
    r = R{b, int8_t(v)};
    return v;
  }

  int replaceable(int x, int y, int z, uintptr_t *out = nullptr) const {
    const uintptr_t b = world(x, y, z);
    if (out) *out = b;
    if (!b) return -1;
    return replaceableBlock(b);
  }

  // The world may have changed (a placement was attempted): drop every memoised world answer.
  void forget() {
    if (++stamp_ == 0) {  // wrapped: clear for real (never happens in one step, kept for safety)
      std::memset(static_cast<void *>(w_), 0, sizeof(w_));
      stamp_ = 1;
    }
  }

  const Stats &stats() const { return st_; }

 private:
  struct W {
    int x, y, z;
    uintptr_t block;
    uint32_t stamp;
  };
  struct E {
    int x, y, z;
    uintptr_t block;
    int8_t r;
    uint8_t used;
  };
  struct R {
    uintptr_t block;
    int8_t rep;
  };
  static size_t slot(int x, int y, int z) {
    const uint32_t h = uint32_t(x) * 73856093u ^ uint32_t(y) * 19349663u ^ uint32_t(z) * 83492791u;
    return (h ^ (h >> 13)) & (kPos - 1);
  }
  Backend &B_;
  uint32_t stamp_ = 1;
  mutable W w_[kPos];
  mutable E e_[kPos];
  mutable R r_[kRep];
  mutable Stats st_;
};

}  // namespace lm::epw
