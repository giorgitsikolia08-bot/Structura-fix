#pragma once
// Error Vision: red outlines of the blocks that are physically present in the world but do NOT match the
// loaded structure, visible through walls.
//
// It owns no scan of its own: the hologram's existing incremental comparison (drawStructure, bounded per
// frame) reports every block it checks to note(); Error Vision keeps a bounded set of the CONFIRMED
// incorrect positions and draws them. Everything here is pure (no game calls) and unit tested on the host
// (tests/error_vision_test.cpp).
//
// "Through walls" without touching GPU state the engine owns: every outline vertex is moved along its own
// view ray to a small distance from the eye (projectToward). A point and its projection fall on the same
// pixel, so the outline keeps its exact on-screen shape, but it now lies in front of any wall, so the depth
// test the material already does passes. Edges and faces are subdivided for blocks close to the eye so the
// projected chords stay on the original lines.

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <string_view>
#include <vector>

namespace lm::ev {

// ---- verdict --------------------------------------------------------------------------------------------
// Cmp values (State.hpp) used here, repeated so this header stays independent of the game-side state.
constexpr uint8_t kCmpUnknown = 0, kCmpCorrect = 1, kCmpWrong = 2, kCmpMissing = 3, kCmpExtra = 4, kCmpAirOk = 5,
                  kCmpWrongState = 6;

enum class Verdict : uint8_t { None, Incorrect, Unknown };

// Blocks that are not something the player can see or bump into: highlighting them would look like a red
// box around nothing (or around water). Treated like a missing block (never highlighted).
inline bool nonPhysical(std::string_view shortName) {
  if (shortName.size() > 10 && shortName.compare(0, 10, "minecraft:") == 0) shortName.remove_prefix(10);
  static constexpr std::string_view k[] = {"air", "cave_air", "void_air", "structure_void", "water", "flowing_water",
                                           "lava", "flowing_lava", "bubble_column"};
  for (auto n : k)
    if (shortName == n) return true;
  return shortName.compare(0, 11, "light_block") == 0;  // light_block, light_block_0..15
}

struct Facts {
  uint8_t cmp = kCmpUnknown;     // result of the existing comparison (compareOne), unchanged semantics
  bool expectedVoid = false;     // structure has no block here (structure_void / outside)
  bool expectedAir = false;      // structure expects air here
  bool expectedKnown = false;    // the expected block resolved to a game block (its name is a real block)
  bool worldRead = false;        // the world lookup returned a block pointer
  bool namesReady = false;       // block-name table is ready (names::ready)
  bool nameKnown = false;        // the world block's name could be read
  std::string_view worldName;    // short name of the world block (valid when nameKnown)
  bool statesExact = false;      // every expected state was applied to the game block and has a rule
};

// Only a positively confirmed mismatch is Incorrect. Missing blocks, air / empty expected positions,
// fluids and anything that could not be read reliably are never highlighted.
inline Verdict judge(const Facts &f) {
  if (f.expectedVoid || f.expectedAir) return Verdict::None;
  if (f.cmp != kCmpWrong && f.cmp != kCmpWrongState) return Verdict::None;
  if (!f.expectedKnown) return Verdict::Unknown;  // unmapped / unknown expected name: can't be sure
  if (!f.worldRead || !f.namesReady || !f.nameKnown) return Verdict::Unknown;  // unreadable: not "wrong"
  if (nonPhysical(f.worldName)) return Verdict::None;                        // water, air-like: missing
  if (f.cmp == kCmpWrongState && !f.statesExact) return Verdict::Unknown;     // states not reliable
  return Verdict::Incorrect;
}

// The render pass re-reads the live comparison byte: an entry whose position was re-verified elsewhere
// (e.g. Easy Place's own verification on the game thread) is skipped until the next check removes it.
inline bool stillIncorrect(uint8_t cmp) { return cmp == kCmpWrong || cmp == kCmpWrongState; }

// Local structure index -> local coordinates (inverse of Structure::index: (x * sy + y) * sz + z).
inline void localOf(size_t li, int sy, int sz, int &x, int &y, int &z) {
  z = int(li % size_t(sz));
  y = int((li / size_t(sz)) % size_t(sy));
  x = int(li / (size_t(sy) * size_t(sz)));
}

// ---- bounded set of confirmed positions (render thread only) --------------------------------------------
// Open addressing, linear probing, backward-shift deletion: no tombstones, no allocation after init().
// Keys are local structure indices (li). The set belongs to one comparison model (owner + generation);
// bind() clears it when that changes (structure / move / rotation / mirror / world change).
class Store {
 public:
  static constexpr size_t kSlots = 8192;     // power of two
  static constexpr size_t kMax = kSlots / 2;  // max entries (load <= 0.5)

  void init() {
    if (slots_.size() != kSlots) slots_.assign(kSlots, 0);
  }
  // Returns true when it had to clear (new owner/generation).
  bool bind(const void *owner, uint64_t gen) {
    init();
    if (owner == owner_ && gen == gen_) return false;
    owner_ = owner;
    gen_ = gen;
    clear();
    return true;
  }
  void clear() {
    std::fill(slots_.begin(), slots_.end(), 0u);
    size_ = 0;
    full_ = false;
  }
  void release() {  // feature switched off: forget the owner too
    clear();
    owner_ = nullptr;
    gen_ = 0;
  }
  // Records the verdict of one position: Incorrect -> present, None -> absent, Unknown -> unchanged
  // (an unreadable lookup neither adds nor removes: the previous confirmed result stays).
  void note(uint32_t li, Verdict v) {
    if (v == Verdict::Incorrect) add(li);
    else if (v == Verdict::None) erase(li);
  }
  bool add(uint32_t li) {
    if (slots_.empty()) return false;
    const uint32_t key = li + 1;
    size_t i = hash(key);
    while (slots_[i]) {
      if (slots_[i] == key) return true;
      i = (i + 1) & (kSlots - 1);
    }
    if (size_ >= kMax) {
      full_ = true;
      return false;
    }
    slots_[i] = key;
    ++size_;
    return true;
  }
  bool erase(uint32_t li) {
    if (slots_.empty() || !size_) return false;
    const uint32_t key = li + 1;
    size_t i = hash(key);
    while (slots_[i] && slots_[i] != key) i = (i + 1) & (kSlots - 1);
    if (!slots_[i]) return false;
    // backward-shift deletion
    size_t hole = i, j = i;
    for (;;) {
      j = (j + 1) & (kSlots - 1);
      if (!slots_[j]) break;
      const size_t home = hash(slots_[j]);
      // move slots_[j] into the hole when its home is not cyclically in (hole, j]
      const bool between = hole <= j ? (home > hole && home <= j) : (home > hole || home <= j);
      if (!between) {
        slots_[hole] = slots_[j];
        hole = j;
      }
    }
    slots_[hole] = 0;
    --size_;
    if (size_ < kMax) full_ = false;
    return true;
  }
  bool contains(uint32_t li) const {
    if (slots_.empty()) return false;
    const uint32_t key = li + 1;
    size_t i = hash(key);
    while (slots_[i]) {
      if (slots_[i] == key) return true;
      i = (i + 1) & (kSlots - 1);
    }
    return false;
  }
  template <class F> void forEach(F &&f) const {
    for (uint32_t k : slots_)
      if (k) f(k - 1);
  }
  size_t size() const { return size_; }
  bool full() const { return full_; }  // an Incorrect position could not be stored (it is retried on recheck)

 private:
  static size_t hash(uint32_t key) { return size_t((key * 0x9E3779B1u) >> 19) & (kSlots - 1); }
  std::vector<uint32_t> slots_;
  size_t size_ = 0;
  bool full_ = false;
  const void *owner_ = nullptr;
  uint64_t gen_ = 0;
};

// ---- incremental sweep (the comparison's round-robin cursor) --------------------------------------------
// Visits `min(budget, vol)` consecutive positions of a box of `vol` positions per call: bounded work per
// frame, never the same position twice in one call, and every position within ceil(vol / budget) calls.
struct Sweep {
  size_t pos = 0;
  template <class F> size_t step(size_t vol, size_t budget, F &&visit) {
    if (!vol) return 0;
    const size_t n = std::min(budget, vol);
    for (size_t i = 0; i < n; ++i) visit((pos++) % vol);
    return n;
  }
};

// ---- geometry ------------------------------------------------------------------------------------------
struct V3 {
  float x, y, z;
};
constexpr float kEyeRadius = 0.2f;   // projected distance from the eye (player's eye is >= 0.3 from walls)
constexpr float kNearSubdiv = 3.f;   // blocks closer than this get subdivided edges/faces

// Moves a camera-relative point along its view ray to distance r (points nearer than r stay).
inline V3 projectToward(V3 q, float r = kEyeRadius) {
  const float d = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z);
  if (!(d > r)) return q;
  const float s = r / d;
  return {q.x * s, q.y * s, q.z * s};
}

struct Line {
  V3 a, b;
};
struct Quad {
  V3 v[4];
};

// Camera-relative box [lo, hi]; emits its 12 edges and the (at most 3) faces that look at the eye,
// projected toward the eye, through line(const Line&) / quad(const Quad&). Returns false (emits nothing)
// when the eye is inside the box.
template <class LineSink, class QuadSink>
inline bool emitBox(V3 lo, V3 hi, bool faces, LineSink &&line, QuadSink &&quad) {
  if (lo.x <= 0 && hi.x >= 0 && lo.y <= 0 && hi.y >= 0 && lo.z <= 0 && hi.z >= 0) return false;
  const float cx = (lo.x + hi.x) * 0.5f, cy = (lo.y + hi.y) * 0.5f, cz = (lo.z + hi.z) * 0.5f;
  const bool near = cx * cx + cy * cy + cz * cz < kNearSubdiv * kNearSubdiv;
  const int ne = near ? 8 : 1, nf = near ? 4 : 1;
  const V3 c[8] = {{lo.x, lo.y, lo.z}, {hi.x, lo.y, lo.z}, {hi.x, lo.y, hi.z}, {lo.x, lo.y, hi.z},
                   {lo.x, hi.y, lo.z}, {hi.x, hi.y, lo.z}, {hi.x, hi.y, hi.z}, {lo.x, hi.y, hi.z}};
  static constexpr int e[12][2] = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6},
                                   {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
  auto lerp = [](V3 a, V3 b, float t) { return V3{a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t}; };
  for (const auto &ed : e) {
    V3 prev = projectToward(c[ed[0]]);
    for (int k = 1; k <= ne; ++k) {
      const V3 cur = projectToward(lerp(c[ed[0]], c[ed[1]], float(k) / float(ne)));
      line(Line{prev, cur});
      prev = cur;
    }
  }
  if (!faces) return true;
  // a face is visible when the eye (origin) is on its outer side
  struct F {
    bool vis;
    V3 o, u, v;  // origin corner and the two edge vectors
  };
  const V3 dx{hi.x - lo.x, 0, 0}, dy{0, hi.y - lo.y, 0}, dz{0, 0, hi.z - lo.z};
  const F fs[6] = {{hi.y < 0, {lo.x, hi.y, lo.z}, dx, dz}, {lo.y > 0, {lo.x, lo.y, lo.z}, dx, dz},
                   {lo.z > 0, {lo.x, lo.y, lo.z}, dx, dy}, {hi.z < 0, {lo.x, lo.y, hi.z}, dx, dy},
                   {lo.x > 0, {lo.x, lo.y, lo.z}, dz, dy}, {hi.x < 0, {hi.x, lo.y, lo.z}, dz, dy}};
  for (const F &f : fs) {
    if (!f.vis) continue;
    for (int a = 0; a < nf; ++a)
      for (int b = 0; b < nf; ++b) {
        auto at = [&](float s, float t) {
          return projectToward(V3{f.o.x + f.u.x * s + f.v.x * t, f.o.y + f.u.y * s + f.v.y * t, f.o.z + f.u.z * s + f.v.z * t});
        };
        const float s0 = float(a) / nf, s1 = float(a + 1) / nf, t0 = float(b) / nf, t1 = float(b + 1) / nf;
        quad(Quad{{at(s0, t0), at(s1, t0), at(s1, t1), at(s0, t1)}});
      }
  }
  return true;
}

}  // namespace lm::ev
