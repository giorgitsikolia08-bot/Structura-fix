#pragma once
// Reading the "original" slot of a preloader-android hook (pure, host-testable).
//
// Proven from preloader-android 5d108da src/pl/memory/Hook.cpp:
//   * GlossHook patches the target to jump to the detour chain BEFORE rebuildChain() stores the slot,
//     so a detour can run while its slot is still nullptr (the slot is written microseconds later).
//   * rebuildChain() rewrites EVERY slot of a target each time any mod hooks or unhooks that target:
//     a slot holds "the next detour in the chain" (or the trampoline), not a fixed address.
// Therefore:
//   * a detour must load its slot on every call (never cache a copy), and
//   * when it is running, the hook exists, so a null slot is only that install window: wait it out.
// chainNext() is only for code running inside the detour of that slot. Code that may run when the hook
// failed must use chainPeek() and handle nullptr.
namespace lm::hookchain {

template <class Fn>
inline Fn chainPeek(Fn const &slot) {
  return __atomic_load_n(&slot, __ATOMIC_ACQUIRE);
}

template <class Fn>
inline Fn chainNext(Fn const &slot) {
  Fn f;
  while (!(f = __atomic_load_n(&slot, __ATOMIC_ACQUIRE))) {
  }
  return f;
}

}  // namespace lm::hookchain
