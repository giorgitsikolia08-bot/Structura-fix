#pragma once
#include <string>
#include <vector>

namespace lm::lib {

struct Entry {
  std::string title;   
  std::string path;
  std::string source;  
};


std::vector<Entry> scan(const std::string &myDir, bool includeDownloads, bool includePacks,
                        std::vector<std::string> *rootsFound);


std::string importFile(const std::string &src, const std::string &displayName, const std::string &myDir,
                       std::string &err);


std::string scanNotes();
// com.mojang folders found on this device (same search as scan with packs on).
std::vector<std::string> mojangRoots(const std::string &myDir);
// com.mojang folder of the currently open world (from the game's open LevelDB files), "" if unknown.
std::string activeMojangRoot();

std::string uniquePath(const std::string &dir, const std::string &base, const std::string &ext);

}  
