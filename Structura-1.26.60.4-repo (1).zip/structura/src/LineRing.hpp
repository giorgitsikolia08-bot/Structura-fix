#pragma once
// Bounded in-memory line buffer for the Easy Place trace (pure; thread-safe).
//
// Before 1.21.9, ep::trace() did a synchronous ::write() to easyplace-trace.txt for every line, on the game
// thread (several lines per placement; the game thread also drives the frame on Android). Now the game
// thread only formats into a fixed slot (no allocation, a short mutex), and the UI thread drains the ring
// to the file every 2 s (ep::flushLog). Oldest lines are dropped when the ring is full; the number of
// dropped lines is reported in the file so nothing is lost silently.

#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>

namespace lm::ring {

template <size_t N = 512, size_t L = 304>
class LineRing {
 public:
  // Copies one line (without trailing newline; truncated to L-1 bytes).
  void push(const char *s, size_t n) {
    if (n >= L) n = L - 1;
    std::lock_guard<std::mutex> lk(mu_);
    size_t at;
    if (count_ == N) {  // full: overwrite the oldest
      at = head_;
      head_ = (head_ + 1) % N;
      ++dropped_;
    } else {
      at = (head_ + count_) % N;
      ++count_;
    }
    std::memcpy(buf_[at], s, n);
    len_[at] = uint16_t(n);
    ++pushed_;
  }
  // Appends every buffered line (+ '\n') to out and empties the ring; returns lines dropped since the
  // last drain. Called from one consumer thread; `out` grows on that thread only.
  uint64_t drain(std::string &out) {
    std::lock_guard<std::mutex> lk(mu_);
    for (size_t i = 0; i < count_; ++i) {
      const size_t at = (head_ + i) % N;
      out.append(buf_[at], len_[at]);
      out.push_back('\n');
    }
    head_ = 0;
    count_ = 0;
    const uint64_t d = dropped_;
    dropped_ = 0;
    return d;
  }
  uint64_t pushed() {
    std::lock_guard<std::mutex> lk(mu_);
    return pushed_;
  }
  size_t size() {
    std::lock_guard<std::mutex> lk(mu_);
    return count_;
  }

 private:
  std::mutex mu_;
  char buf_[N][L];
  uint16_t len_[N] = {};
  size_t head_ = 0, count_ = 0;
  uint64_t dropped_ = 0, pushed_ = 0;
};

}  // namespace lm::ring
