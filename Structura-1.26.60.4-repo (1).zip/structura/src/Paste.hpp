#pragma once
// Creative "Paste Schematic" - export side only. Pure data + files: no game calls, no GL, no hooks.
//
// Why not direct placement: neither the preloader SDK (5d108da: Config, Logger, Mod, Platform, Input,
// ModMenu, memory/*) nor the verified functions of this build offer a block-write or command API. The
// only verified write path is GameMode::buildBlock (Easy Place), which places one held item like a
// player click: it cannot replace or clear blocks, needs reach and the item, and a bulk sequence of
// it is explicitly not allowed as a paste fallback.
//
// What this does instead: the schematic, with its current rotation/mirror/offset baked in, is
// encoded as a Bedrock .mcstructure into the "Structura Paste" development behavior pack, and the
// matching `/structure load` command is produced. The GAME then performs the paste: its own command
// permission (cheats, operator level 1) and world rules apply; a region that is unloaded or out of
// the world makes the command fail as a whole (nothing placed).
//
// Modes: ReplaceAll writes schematic air as air; NonAirOnly writes schematic air as "no block" (-1,
// the structure-void index), so the world block stays. Schematic structure_void cells are always -1.

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <ctime>
#include <fstream>
#include <memory>
#include <random>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <unistd.h>

#include "Nbt.hpp"
#include "Structure.hpp"

namespace lm::paste {

enum class Mode : uint8_t { ReplaceAll = 0, NonAirOnly = 1 };

// Why the action can't start (UI shows it; None = allowed).
enum class Block : uint8_t {
  None = 0,
  NoStructure,      // nothing loaded
  NotPlaced,        // loaded but not positioned in the world
  NotInWorld,       // no local player
  CreativeUnknown,  // creative state not known (function unavailable or no recent game tick)
  NotCreative,      // survival/adventure/spectator
  Busy,             // a paste job is queued or running
  TooLarge,         // volume above the cell limit
  OutOfWorld,       // Y range or horizontal coordinates outside the world limits
};

struct Limits {
  size_t maxCells = size_t(0x7FFFFFFF);  // no practical cell limit (memory is guarded by the callers)
  int minY = -64, maxY = 319;         // overworld build limits (the widest of the three dimensions)
  int maxXZ = 29999984;               // world border of Bedrock
};

// Pure decision used by the UI and by start (same function, same answer).
inline Block check(const Structure *S, const Placement &P, bool placed, bool inWorld, int creative, bool busy,
                   const Limits &L = Limits{}) {
  if (!S || S->sx <= 0 || S->sy <= 0 || S->sz <= 0) return Block::NoStructure;
  if (!placed) return Block::NotPlaced;
  if (busy) return Block::Busy;
  if (!inWorld) return Block::NotInWorld;
  if (creative < 0) return Block::CreativeUnknown;
  if (creative == 0) return Block::NotCreative;
  if (S->volume() > L.maxCells || S->idx.size() != S->volume()) return Block::TooLarge;
  int dx, dz;
  rotatedSize(*S, P.rot, dx, dz);
  const long long y0 = P.oy, y1 = (long long)P.oy + S->sy - 1;
  const long long x0 = P.ox, x1 = (long long)P.ox + dx - 1, z0 = P.oz, z1 = (long long)P.oz + dz - 1;
  if (y0 < L.minY || y1 > L.maxY) return Block::OutOfWorld;
  if (x0 < -L.maxXZ || x1 > L.maxXZ || z0 < -L.maxXZ || z1 > L.maxXZ) return Block::OutOfWorld;
  return Block::None;
}

inline constexpr int32_t kDefaultVersion = 18168865;  // same value as the existing capture writer

struct Stats {
  size_t cells = 0;        // output cells (= schematic volume)
  size_t placed = 0;       // cells that write a block (incl. air in ReplaceAll)
  size_t air = 0;          // of them: air
  size_t kept = 0;         // cells that keep the world block (-1)
  size_t water = 0;        // waterlogged cells (layer 2)
  size_t noStates = 0;     // cells written by name only (variant data missing)
  size_t inexact = 0;      // cells whose state can't be reproduced exactly after rotation/mirror
  size_t rawDropped = 0;   // state values of a non byte/int/string NBT type (not writable, left out)
  size_t paletteSize = 0;  // output palette entries
};

// Incremental encoder: begin() once, then step(budget) until it returns true. Bounded work per call,
// nothing shared: it reads one immutable Structure (kept alive by the caller) and writes its own buffer.
class Encoder {
 public:
  using States = std::vector<std::vector<BlockStateValue>>;

  // states/unsupported: transformed states per variant for P.rot/P.mirror (xf::Table) - may be null,
  // then the variants' own states are used (only correct for rot 0 without mirror; counted as inexact
  // otherwise).
  bool begin(std::shared_ptr<const Structure> S, const Placement &P, Mode mode, const States *states,
             const std::vector<std::string> *unsupported, std::string &err) {
    *this = Encoder{};
    if (!S || S->idx.size() != S->volume() || S->volume() == 0) { err = "no structure data"; return false; }
    S_ = std::move(S);
    P_ = P;
    mode_ = mode;
    states_ = states && states->size() == S_->variants.size() ? states : nullptr;
    unsupported_ = unsupported && unsupported->size() == S_->variants.size() ? unsupported : nullptr;
    rotatedSize(*S_, P_.rot, dx_, dz_);
    total_ = S_->volume();
    vidxOk_ = S_->vidx.size() == total_ && !S_->variants.empty();
    vmap_.assign(vidxOk_ ? S_->variants.size() : 0, -2);
    pmap_.assign(S_->palette.size(), -2);
    layer1_.reserve(total_);
    w_.out.reserve(256 + total_ * 8);
    stats.cells = total_;
    w_.beginCompound("");
    w_.putInt("format_version", 1);
    w_.beginList("size", nbt::Int, 3);
    w_.listInt(dx_); w_.listInt(S_->sy); w_.listInt(dz_);
    w_.beginCompound("structure");
    w_.beginList("block_indices", nbt::List, 2);
    w_.listListBegin(nbt::Int, int32_t(total_));
    return true;
  }

  // Encodes up to `budget` cells. Returns true when the whole file is complete (bytes() is valid).
  bool step(size_t budget) {
    if (done_ || !S_) return done_;
    const Structure &S = *S_;
    while (budget > 0 && phase_ < 2) {
      if (phase_ == 0) {
        const size_t start = pos_, end = std::min(total_, pos_ + budget);
        for (; pos_ < end; ++pos_) {
          const int32_t v = cellIndex(S, sourceIndex(pos_));
          layer1_.push_back(v);
          w_.listInt(v);
        }
        budget -= end - start;
        if (pos_ == total_) {
          phase_ = 1;
          pos_ = 0;
          w_.listListBegin(nbt::Int, int32_t(total_));
        }
      } else {
        const size_t end = std::min(total_, pos_ + budget);
        for (; pos_ < end; ++pos_) {
          int32_t v = -1;
          if (layer1_[pos_] >= 0 && !S.water.empty() && S.waterAt(sourceIndex(pos_))) {
            if (water_ < 0) water_ = addEntry("minecraft:water", nullptr, kDefaultVersion, true);
            v = water_;
            ++stats.water;
          }
          w_.listInt(v);
        }
        budget = 0;
        if (pos_ == total_) phase_ = 2;
      }
    }
    if (phase_ == 2 && !done_) finish();
    return done_;
  }

  float progress() const {
    if (done_) return 1.f;
    if (!total_) return 0.f;
    return phase_ == 0 ? 0.9f * float(pos_) / float(total_) : 0.9f + 0.1f * float(pos_) / float(total_);
  }
  bool done() const { return done_; }
  const std::vector<uint8_t> &bytes() const { return w_.out; }
  std::vector<uint8_t> take() { return std::move(w_.out); }
  int sizeX() const { return dx_; }
  int sizeZ() const { return dz_; }

  Stats stats;

 private:
  struct Entry {
    std::string name;
    const std::vector<BlockStateValue> *states = nullptr;
    int32_t version = kDefaultVersion;
    bool water = false;
  };

  // Output cell (x outer, y, z inner - the .mcstructure order) -> schematic linear index.
  size_t sourceIndex(size_t o) const {
    const int X = int(o / (size_t(S_->sy) * dz_)), Y = int((o / dz_) % S_->sy), Z = int(o % dz_);
    int lx = 0, ly = 0, lz = 0;
    worldToLocal(*S_, P_, P_.ox + X, P_.oy + Y, P_.oz + Z, lx, ly, lz);  // always inside by construction
    return S_->index(lx, ly, lz);
  }

  int32_t addEntry(std::string name, const std::vector<BlockStateValue> *st, int32_t version, bool water = false) {
    entries_.push_back(Entry{std::move(name), st, version ? version : kDefaultVersion, water});
    return int32_t(entries_.size() - 1);
  }

  int32_t cellIndex(const Structure &S, size_t li) {
    const uint16_t p = S.idx[li];
    if (p == kVoid || p >= S.palette.size()) { ++stats.kept; return -1; }
    if (S.palette[p].air) {
      if (mode_ == Mode::NonAirOnly) { ++stats.kept; return -1; }
      if (air_ < 0) air_ = addEntry("minecraft:air", nullptr, kDefaultVersion);
      ++stats.placed;
      ++stats.air;
      return air_;
    }
    ++stats.placed;
    const uint16_t v = vidxOk_ ? S.vidx[li] : kVoid;
    if (v == kVoid || v >= S.variants.size()) {
      ++stats.noStates;
      int32_t &e = pmap_[p];
      if (e == -2) e = addEntry(fullName(S.palette[p].name), nullptr, kDefaultVersion);
      return e;
    }
    const bool turned = (P_.rot & 3) != 0 || P_.mirror;
    if ((unsupported_ && !(*unsupported_)[v].empty()) || (turned && !states_)) ++stats.inexact;
    int32_t &e = vmap_[v];
    if (e == -2) {
      const BlockVariant &bv = S.variants[v];
      // The variant's original name + its (transformed) states + its original version: the game's own
      // block upgrader handles legacy names/states exactly as for any other structure file.
      e = addEntry(bv.fullName.empty() ? fullName(S.palette[p].name) : bv.fullName,
                   states_ ? &(*states_)[v] : &bv.states, bv.version);
    }
    return e;
  }

  static std::string fullName(const std::string &n) {
    return n.find(':') == std::string::npos ? "minecraft:" + n : n;
  }

  void finish() {
    w_.beginList("entities", nbt::Compound, 0);
    w_.beginCompound("palette");
    w_.beginCompound("default");
    w_.beginList("block_palette", nbt::Compound, int32_t(entries_.size()));
    for (const Entry &e : entries_) {
      w_.putString("name", e.name);
      w_.beginCompound("states");
      if (e.water) w_.putInt("liquid_depth", 0);
      if (e.states) {
        for (const BlockStateValue &sv : *e.states) {
          if (sv.type == nbt::Byte) w_.putByte(sv.key, int8_t(sv.i));
          else if (sv.type == nbt::Int) w_.putInt(sv.key, sv.i);
          else if (sv.type == nbt::String) w_.putString(sv.key, sv.s);
          else ++stats.rawDropped;
        }
      }
      w_.endCompound();
      w_.putInt("version", e.version);
      w_.listCompoundEnd();
    }
    w_.beginCompound("block_position_data");
    w_.endCompound();
    w_.endCompound();  // default
    w_.endCompound();  // palette
    w_.endCompound();  // structure
    w_.beginList("structure_world_origin", nbt::Int, 3);
    w_.listInt(P_.ox); w_.listInt(P_.oy); w_.listInt(P_.oz);
    w_.endCompound();  // root
    stats.paletteSize = entries_.size();
    std::vector<int32_t>().swap(layer1_);
    done_ = true;
  }

  std::shared_ptr<const Structure> S_;
  Placement P_;
  Mode mode_ = Mode::ReplaceAll;
  const States *states_ = nullptr;
  const std::vector<std::string> *unsupported_ = nullptr;
  int dx_ = 0, dz_ = 0;
  size_t total_ = 0, pos_ = 0;
  int phase_ = 0;
  bool done_ = false, vidxOk_ = false;
  std::vector<int32_t> vmap_, pmap_, layer1_;
  std::vector<Entry> entries_;
  int32_t air_ = -1, water_ = -1;
  nbt::Writer w_;
};

// The job loop shared by the app and the tests: bounded steps, cancel/staleness checked between steps
// and once more at the end, before anything is written. Nothing here writes files.
enum class Outcome : uint8_t { Done, Cancelled, Stale };
template <class Cancel, class Stale, class Progress>
Outcome runEncode(Encoder &enc, size_t stepCells, Cancel &&cancelled, Stale &&stale, Progress &&progress) {
  if (stepCells == 0) stepCells = 1;
  while (!enc.step(stepCells)) {
    progress(enc.progress());
    if (cancelled()) return Outcome::Cancelled;
    if (stale()) return Outcome::Stale;
  }
  if (cancelled()) return Outcome::Cancelled;
  if (stale()) return Outcome::Stale;
  progress(1.f);
  return Outcome::Done;
}

// ---- files: the "Structura Paste" development behavior pack ----

inline constexpr const char *kPackFolder = "StructuraPaste";
inline constexpr const char *kNamespace = "structura";

inline std::string uuid4() {
  uint8_t b[16];
  bool ok = false;
  if (FILE *f = std::fopen("/dev/urandom", "rb")) {
    ok = std::fread(b, 1, 16, f) == 16;
    std::fclose(f);
  }
  if (!ok) {
    std::random_device rd;
    for (auto &x : b) x = uint8_t(rd());
  }
  b[6] = uint8_t((b[6] & 0x0F) | 0x40);
  b[8] = uint8_t((b[8] & 0x3F) | 0x80);
  char s[37];
  std::snprintf(s, sizeof s, "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x", b[0], b[1], b[2],
                b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15]);
  return s;
}

inline bool isDir(const std::string &p) {
  struct stat st {};
  return stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}
inline bool mkdirOk(const std::string &p) { return mkdir(p.c_str(), 0775) == 0 || isDir(p); }

// Creates <root>/development_behavior_packs/StructuraPaste/{manifest.json, structures/structura/}.
// An existing manifest is never rewritten (its UUIDs stay, so the pack stays activated in worlds).
inline bool ensurePack(const std::string &root, std::string &packDir, std::string &err) {
  if (!isDir(root)) { err = "game folder not found"; return false; }
  const std::string dev = root + "/development_behavior_packs";
  packDir = dev + "/" + kPackFolder;
  if (!mkdirOk(dev) || !mkdirOk(packDir) || !mkdirOk(packDir + "/structures") ||
      !mkdirOk(packDir + "/structures/" + kNamespace)) {
    err = "can't create the pack folder";
    return false;
  }
  const std::string man = packDir + "/manifest.json";
  if (access(man.c_str(), F_OK) == 0) return true;
  const std::string tmp = man + ".tmp";
  {
    std::ofstream f(tmp, std::ios::trunc);
    f << "{\n  \"format_version\": 2,\n  \"header\": {\n    \"name\": \"Structura Paste\",\n"
         "    \"description\": \"Structures exported by Structura for /structure load\",\n"
         "    \"uuid\": \"" << uuid4() << "\",\n    \"version\": [1, 0, 0],\n    \"min_engine_version\": [1, 20, 0]\n  },\n"
         "  \"modules\": [\n    {\n      \"type\": \"data\",\n      \"uuid\": \"" << uuid4()
      << "\",\n      \"version\": [1, 0, 0]\n    }\n  ]\n}\n";
    if (!f) { std::remove(tmp.c_str()); err = "can't write the pack manifest"; return false; }
  }
  if (std::rename(tmp.c_str(), man.c_str()) != 0) { std::remove(tmp.c_str()); err = "can't write the pack manifest"; return false; }
  return true;
}

// Lower-case [a-z0-9_] id, unique per export (a cached structure of the same name is never reused).
inline std::string makeId(const std::string &title, std::time_t t) {
  std::tm tm{};
  localtime_r(&t, &tm);
  char ts[32];
  std::strftime(ts, sizeof ts, "p%Y%m%d_%H%M%S", &tm);
  std::string clean;
  for (char c : title) {
    if (clean.size() >= 24) break;
    const unsigned char u = static_cast<unsigned char>(c);
    if (u >= 'A' && u <= 'Z') clean.push_back(char(u - 'A' + 'a'));
    else if ((u >= 'a' && u <= 'z') || (u >= '0' && u <= '9') || u == '_') clean.push_back(char(u));
    else if (!clean.empty() && clean.back() != '_') clean.push_back('_');
  }
  while (!clean.empty() && clean.back() == '_') clean.pop_back();
  return clean.empty() ? std::string(ts) : std::string(ts) + "_" + clean;
}

// Atomic write (tmp + rename); never overwrites an existing structure file.
inline bool writeStructure(const std::string &packDir, const std::string &id, const std::vector<uint8_t> &bytes,
                           std::string &file, std::string &err) {
  file = packDir + "/structures/" + kNamespace + "/" + id + ".mcstructure";
  if (access(file.c_str(), F_OK) == 0) { err = "a structure with this name already exists"; return false; }
  const std::string tmp = file + ".tmp";
  {
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) { err = "can't create the structure file"; return false; }
    f.write(reinterpret_cast<const char *>(bytes.data()), std::streamsize(bytes.size()));
    f.flush();
    if (!f) { f.close(); std::remove(tmp.c_str()); err = "write failed (storage full?)"; return false; }
  }
  if (std::rename(tmp.c_str(), file.c_str()) != 0) { std::remove(tmp.c_str()); err = "rename failed"; return false; }
  return true;
}

// Rotation and mirror are already in the file: the game must load it unturned at the min corner.
inline std::string command(const std::string &id, const Placement &P) {
  return "/structure load " + std::string(kNamespace) + ":" + id + " " + std::to_string(P.ox) + " " +
         std::to_string(P.oy) + " " + std::to_string(P.oz) + " 0_degrees none false true";
}

}  // namespace lm::paste
