#pragma once



#include <atomic>
#include <cstdint>

namespace lm::perf {

enum Counter : int {
  RenderHook,     
  PlayerUpdate,   
  GuiSubmit,      
  GuiCommands,    
  LayoutRebuild,  
  TextureRebuild, 
  MeshRebuild,    
  WorldQuery,     
  BlockingWait,   
  Alloc,          
  HoloCpuUs,      // drawStructure CPU time (microseconds)
  HoloCompares,   // world blocks compared with the structure (getBlock calls)
  HoloBuilds,     // hologram chunk (re)builds
  HoloImmQuads,   // coloured quads drawn in immediate mode (markers / fallback boxes)
  // 1.21.9 Easy Place counters (reported per second: Easy Place runs per tick, not per frame)
  EpCpuUs,        // autoTick + onTick + tap placement CPU time on the game thread (microseconds)
  EpSteps,        // Easy Place steps that searched for a target (tap / auto / run)
  EpExpected,     // structure "expected block" questions answered for Easy Place (memo misses only)
  EpWorldReads,   // world getBlock reads issued by Easy Place (memo misses only)
  EpSims,         // getPlacementBlock simulations (choosePlan)
  EpFileWrites,   // file writes issued on the game thread by Easy Place (trace) - 0 since 1.21.9
  SafeReads,      // guarded memory reads (process_vm_readv syscalls), all threads
  SvCalls,        // block state lookups (stateValue)
  SvHits,         // ... answered from the bounded state cache
  CounterCount
};

extern std::atomic_bool gOn;
extern std::atomic<uint64_t> gCnt[CounterCount];

inline bool on() { return gOn.load(std::memory_order_relaxed); }
inline void count(Counter c, uint64_t n = 1) {
  if (gOn.load(std::memory_order_relaxed)) gCnt[c].fetch_add(n, std::memory_order_relaxed);
}



void setEnabled(bool on);
bool takeLine(char *out, unsigned outSize);

}  
