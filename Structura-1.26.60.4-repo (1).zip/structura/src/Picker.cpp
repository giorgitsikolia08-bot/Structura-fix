#include "Picker.hpp"

#include <jni.h>

#include <cstring>
#include <vector>

#include "PickerDex.inc"
#include <dlfcn.h>

#include "pl/Logger.hpp"
#include "pl/Mod.hpp"

namespace lm::picker {
namespace {

pl::log::Logger &log() { return pl::log::Logger::getOrCreate("Structura"); }

// JavaVM：优先 NativeMod，其次从 libart 的 JNI_GetCreatedJavaVMs 拿（防止 current() 为空的场景）
JavaVM *findVm() {
  if (auto *mod = ll::mod::NativeMod::current())
    if (auto *vm = mod->getJavaVM()) return vm;
  static JavaVM *cached = nullptr;
  static bool tried = false;
  if (!tried) {
    tried = true;
    using Fn = jint (*)(JavaVM **, jsize, jsize *);
    for (const char *lib : {"libart.so", "libnativehelper.so"}) {
      if (void *h = dlopen(lib, RTLD_NOW | RTLD_NOLOAD)) {
        if (auto f = reinterpret_cast<Fn>(dlsym(h, "JNI_GetCreatedJavaVMs"))) {
          JavaVM *vm = nullptr;
          jsize n = 0;
          if (f(&vm, 1, &n) == JNI_OK && n > 0 && vm) { cached = vm; break; }
        }
      }
    }
  }
  return cached;
}

JavaVM *sVm = nullptr;
jobject sLoader = nullptr;      // InMemoryDexClassLoader 全局引用
jclass sClass = nullptr;        // structura.Picker
bool sTried = false, sOk = false;
Handler sHandler;

std::string jstr(JNIEnv *env, jstring s) {
  if (!s) return {};
  const char *c = env->GetStringUTFChars(s, nullptr);
  std::string out = c ? c : "";
  if (c) env->ReleaseStringUTFChars(s, c);
  return out;
}

std::vector<unsigned char> b64decode(const char *in) {
  static signed char tbl[256];
  static bool init = false;
  if (!init) {
    init = true;
    for (int i = 0; i < 256; ++i) tbl[i] = -1;
    const char *al = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (int i = 0; i < 64; ++i) tbl[(unsigned char)al[i]] = (signed char)i;
  }
  std::vector<unsigned char> out;
  int val = 0, bits = 0;
  for (const char *p = in; *p; ++p) {
    if (tbl[(unsigned char)*p] < 0) continue;
    val = (val << 6) | tbl[(unsigned char)*p];
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out.push_back((unsigned char)((val >> bits) & 0xFF));
    }
  }
  return out;
}

// onPicked(path, name, error, mime) —— Java UI 线程回调
void JNICALL onPicked(JNIEnv *env, jclass, jstring path, jstring name, jstring error, jstring mime) {
  const std::string p = jstr(env, path), n = jstr(env, name), e = jstr(env, error), m = jstr(env, mime);
  if (sHandler) sHandler(p, n, e, m);
}

JNIEnv *envForUse(bool &detach) {
  detach = false;
  if (!sVm) return nullptr;
  JNIEnv *env = nullptr;
  const jint st = sVm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
  if (st == JNI_OK) return env;
  if (sVm->AttachCurrentThreadAsDaemon(reinterpret_cast<JNIEnv **>(&env), nullptr) == JNI_OK) {
    detach = true;
    return env;
  }
  return nullptr;
}

}  // namespace

void setHandler(Handler h) { sHandler = std::move(h); }

bool init() {
  if (sTried) return sOk;
  sTried = true;
  sVm = findVm();
  log().info("picker: init vm={}", sVm != nullptr);
  if (!sVm) return sOk = false;
  bool detach = false;
  JNIEnv *env = envForUse(detach);
  if (!env) return sOk = false;

  const std::vector<unsigned char> dex = b64decode(kPickerDexB64);
  jobject buf = env->NewDirectByteBuffer(const_cast<unsigned char *>(dex.data()), jlong(dex.size()));
  log().info("picker: dex={} bytes, buf={}", dex.size(), buf != nullptr);
  if (!buf) { if (detach) sVm->DetachCurrentThread(); return sOk = false; }

  jclass clsLoader = env->FindClass("java/lang/ClassLoader");
  jmethodID sysLoader = env->GetStaticMethodID(clsLoader, "getSystemClassLoader", "()Ljava/lang/ClassLoader;");
  jobject parent = env->CallStaticObjectMethod(clsLoader, sysLoader);

  jclass clsInMem = env->FindClass("dalvik/system/InMemoryDexClassLoader");
  log().info("picker: InMemoryDexClassLoader={}", clsInMem != nullptr);
  if (!clsInMem) { if (detach) sVm->DetachCurrentThread(); return sOk = false; }
  jmethodID ctor = env->GetMethodID(clsInMem, "<init>", "(Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V");
  jobject loader = env->NewObject(clsInMem, ctor, buf, parent);
  log().info("picker: loader={}", loader != nullptr);
  if (!loader) { if (detach) sVm->DetachCurrentThread(); return sOk = false; }

  jclass clsPick = env->FindClass("structura/Picker");  // 走 parent（系统）找不到 → 用 loader 再找
  if (!clsPick || env->ExceptionCheck()) {
    env->ExceptionClear();
    jmethodID loadClass = env->GetMethodID(clsLoader, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    jstring nm = env->NewStringUTF("structura.Picker");
    clsPick = static_cast<jclass>(env->CallObjectMethod(loader, loadClass, nm));
    env->DeleteLocalRef(nm);
  }
  log().info("picker: class={}", clsPick != nullptr);
  if (!clsPick || env->ExceptionCheck()) {
    env->ExceptionClear();
    if (detach) sVm->DetachCurrentThread();
    return sOk = false;
  }

  const JNINativeMethod kOnPicked = {const_cast<char *>("onPicked"), const_cast<char *>("(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"),
                                     reinterpret_cast<void *>(&onPicked)};
  const jint reg = env->RegisterNatives(clsPick, &kOnPicked, 1);
  log().info("picker: register natives={}", int(reg));
  if (reg != JNI_OK) {
    if (detach) sVm->DetachCurrentThread();
    return sOk = false;
  }
  sClass = static_cast<jclass>(env->NewGlobalRef(clsPick));
  sLoader = env->NewGlobalRef(loader);

  // 注册生命周期回调（拿 Activity 需要它）
  jclass clsApp = env->FindClass("android/app/Application");
  jmethodID appOf = env->GetStaticMethodID(clsPick, "app", "()Landroid/app/Application;");
  jobject app = env->CallStaticObjectMethod(clsPick, appOf);
  log().info("picker: application={}", app != nullptr);
  if (app) {
    jmethodID install = env->GetStaticMethodID(clsPick, "install", "(Landroid/app/Application;)V");
    env->CallStaticVoidMethod(clsPick, install, app);
    env->DeleteLocalRef(app);
  }
  if (env->ExceptionCheck()) env->ExceptionClear();
  if (detach) sVm->DetachCurrentThread();
  sOk = true;
  log().info("picker: dex loaded ({})", dex.size());
  return sOk;
}

bool request(const std::string &mime) {
  if (!init()) return false;
  bool detach = false;
  JNIEnv *env = envForUse(detach);
  if (!env) return false;
  bool ok = false;
  jmethodID req = env->GetStaticMethodID(sClass, "request", "(Ljava/lang/String;)Z");
  if (req) {
    jstring m = env->NewStringUTF(mime.empty() ? "*/*" : mime.c_str());
    ok = env->CallStaticBooleanMethod(sClass, req, m) == JNI_TRUE;
    env->DeleteLocalRef(m);
    log().info("picker: request -> {}", ok);
  } else {
    log().info("picker: request method missing");
  }
  if (env->ExceptionCheck()) {
    env->ExceptionDescribe();
    env->ExceptionClear();
    ok = false;
  }
  if (detach) sVm->DetachCurrentThread();
  return ok;
}

}  // namespace lm::picker
