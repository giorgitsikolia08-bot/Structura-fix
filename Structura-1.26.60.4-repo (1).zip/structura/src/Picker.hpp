#pragma once
// 系统文件选择器（不依赖启动器）：运行时加载自带 dex，用 Fragment 收 onActivityResult。
#include <functional>
#include <string>

namespace lm::picker {

// 导入结果回调：path 为空表示失败，error 说明原因
using Handler = std::function<void(const std::string &path, const std::string &name, const std::string &error,
                                   const std::string &mime)>;
void setHandler(Handler h);

// 初始化：加载 dex / 注册 native。可在任意线程调用，重复调用无副作用。
bool init();

// 请求打开选择器（异步）。返回 false 表示链路不可用（调用方应回退到目录扫描）。
bool request(const std::string &mime);

}  // namespace lm::picker
