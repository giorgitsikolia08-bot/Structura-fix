#pragma once
// 记录"刚被 Easy Place 放下的方块"，供全息渲染在比较数据刷新之前临时跳过这些格，
// 避免投影面与真实方块的纹理面共面闪烁（z-fighting）。
// 无锁写入（游戏线程）+ 每帧快照读取（渲染线程），不会给逐方块循环带来原子开销。
#include <atomic>
#include <chrono>
#include <cstdint>

namespace lm::recent {

inline int64_t nowMs() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(
             std::chrono::steady_clock::now().time_since_epoch()).count();
}

struct Slot {
  std::atomic<int32_t> x{0}, y{0}, z{0};
  std::atomic<int64_t> ms{0};
};

inline Slot gSlots[64];
inline std::atomic<uint32_t> gCursor{0};

inline void mark(int x, int y, int z) {
  const uint32_t i = gCursor.fetch_add(1, std::memory_order_relaxed) & 63u;
  gSlots[i].x.store(x, std::memory_order_relaxed);
  gSlots[i].y.store(y, std::memory_order_relaxed);
  gSlots[i].z.store(z, std::memory_order_relaxed);
  gSlots[i].ms.store(nowMs(), std::memory_order_relaxed);
}

// 每帧刷新一次的快照（bbox + 少量坐标）
struct Snapshot {
  int n = 0;
  int x[64], y[64], z[64];
  int minx = 0, miny = 0, minz = 0, maxx = -1, maxy = -1, maxz = -1;
  int64_t refreshed = 0;
};

inline void refresh(Snapshot &s) {
  const int64_t now = nowMs();
  s.n = 0;
  for (auto &sl : gSlots) {
    if (now - sl.ms.load(std::memory_order_relaxed) > 4000) continue;
    const int x = sl.x.load(std::memory_order_relaxed);
    const int y = sl.y.load(std::memory_order_relaxed);
    const int z = sl.z.load(std::memory_order_relaxed);
    if (s.n == 0) {
      s.minx = s.maxx = x; s.miny = s.maxy = y; s.minz = s.maxz = z;
    } else {
      if (x < s.minx) s.minx = x;
      if (x > s.maxx) s.maxx = x;
      if (y < s.miny) s.miny = y;
      if (y > s.maxy) s.maxy = y;
      if (z < s.minz) s.minz = z;
      if (z > s.maxz) s.maxz = z;
    }
    s.x[s.n] = x; s.y[s.n] = y; s.z[s.n] = z;
    ++s.n;
  }
  s.refreshed = now;
}

// Render thread only: one snapshot per frame (beginFrame, called once at the start of drawStructure).
// hit() is then a pure bbox/array test - no clock read per block (it is called for every block of every
// chunk build and for every neighbour of every coloured marker). A plain global avoids emutls (rule R5).
inline Snapshot gSnap;
inline void beginFrame() { refresh(gSnap); }

// 渲染线程查询：先过 bbox（绝大多数方块在这里就返回 false），再逐个比对
inline bool hit(int x, int y, int z) {
  const Snapshot &s = gSnap;
  if (s.n == 0) return false;
  if (x < s.minx || x > s.maxx || y < s.miny || y > s.maxy || z < s.minz || z > s.maxz) return false;
  for (int i = 0; i < s.n; ++i)
    if (s.x[i] == x && s.y[i] == y && s.z[i] == z) return true;
  return false;
}

}  // namespace lm::recent
