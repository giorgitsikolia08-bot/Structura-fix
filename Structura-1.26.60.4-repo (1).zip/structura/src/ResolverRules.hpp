#pragma once
// Pure resolver rules (host-testable): signature patterns and the decision whether an entry that carries
// another mod's hook patch is still proven to be the expected function.
//
// Background (2.0.1 runtime report, 1.26.52.3 RC2): TessellatorColor's signature is 12 bytes with 6 exact
// bytes. A recognised hook patch overwrites 4..28 bytes of the entry, and the old rule required 16 exact
// signature bytes after the patch, so as soon as any other mod hooked Tessellator::color the resolver
// reported "0 matches" although build-id and offset were proven, and the whole render path was refused.
// For the tested build the identity is now also accepted when proven by
//   (a) the original bytes read from the library file (whole signature, exact), or
//   (b) a build-specific body fingerprint generated from that exact build (TestedBodies.inc), located after
//       the largest recognised patch and unique in .text.
// Untested builds keep the old rule unchanged (no fixed offset to anchor a short proof).
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string_view>
#include <vector>

namespace lm::rsvrules {

struct Pat {
  std::vector<uint8_t> v, m;  // value, mask (0xFF exact, 0 wildcard)
};

inline Pat parse(const char *s) {
  Pat p;
  std::string_view sv(s ? s : "");
  size_t i = 0;
  auto hex = [](char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; };
  while (i < sv.size()) {
    while (i < sv.size() && sv[i] == ' ') ++i;
    if (i >= sv.size()) break;
    size_t j = i;
    while (j < sv.size() && sv[j] != ' ') ++j;
    const std::string_view t = sv.substr(i, j - i);
    if (t == "?" || t == "??") { p.v.push_back(0); p.m.push_back(0); }
    else if (t.size() == 2 && hex(t[0]) >= 0 && hex(t[1]) >= 0) { p.v.push_back(uint8_t(hex(t[0]) * 16 + hex(t[1]))); p.m.push_back(0xFF); }
    else return Pat{};
    i = j;
  }
  return p;
}

// Signature bytes [from, size) against `d` (caller guarantees d has p.v.size() readable bytes).
inline bool matchBytes(const uint8_t *d, const Pat &p, size_t from) {
  if (p.v.empty() || !d) return false;
  for (size_t i = from; i < p.v.size(); ++i)
    if (p.m[i] && d[i] != p.v[i]) return false;
  return true;
}

inline size_t exactCount(const Pat &p, size_t from) {
  size_t n = 0;
  for (size_t i = from; i < p.m.size(); ++i) n += p.m[i] != 0;
  return n;
}

enum class FileCheck : int { Unavailable = 0, Match, Mismatch };

constexpr size_t kMinTailExact = 16;  // exact signature bytes that must survive the patch (old rule)

// Build-specific fingerprint of a tested-build entry (generated, see scripts/gen_tested_bodies.py).
struct Body {
  const char *name;
  uint16_t at;   // offset from the entry
  uint8_t len;
  uint8_t b[48];
};
inline const Body *findBody(const Body *t, size_t n, const char *name) {
  for (size_t i = 0; t && name && i < n; ++i)
    if (std::strcmp(t[i].name, name) == 0) return &t[i];
  return nullptr;
}

enum class Proof : int { None = 0, Tail, File, Body };

struct HookedFacts {
  size_t patchLen = 0;          // bytes overwritten by a recognised patch, 0 = not a recognised patch
  size_t exactAfterPatch = 0;   // exact signature bytes after the patch
  bool tailMatches = false;     // every signature byte after the patch equals live memory
  FileCheck file = FileCheck::Unavailable;  // original library bytes vs the whole signature
  const Body *body = nullptr;   // fingerprint for this entry (tested build only)
  bool bodyMatches = false;     // live bytes equal the fingerprint
};

// testedBuild: the build-id is in the tested table and the candidate is that table's fixed offset.
inline Proof decideHooked(const HookedFacts &f, bool testedBuild) {
  if (!f.patchLen || !f.tailMatches) return Proof::None;
  if (f.file == FileCheck::Mismatch) return Proof::None;  // the library says it is another function
  if (f.exactAfterPatch >= kMinTailExact) return Proof::Tail;  // unchanged pre-2.0.1 rule
  if (!testedBuild) return Proof::None;
  if (f.file == FileCheck::Match) return Proof::File;
  if (f.body && f.body->at >= f.patchLen && f.bodyMatches) return Proof::Body;
  return Proof::None;
}

inline const char *proofText(Proof p) {
  switch (p) {
    case Proof::Tail: return "exact signature tail after the patch";
    case Proof::File: return "original bytes verified from the library file";
    case Proof::Body: return "tested-build body fingerprint after the patch";
    default: return "not proven";
  }
}

}  // namespace lm::rsvrules
