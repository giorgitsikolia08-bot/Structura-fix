#pragma once
// Bounded cache for Block* state lookups (pure; thread-safe).
//
// stateValue(block, key) reads a state through ~15 pointer-chasing reads (each one a process_vm_readv) and
// the game's findState. A game Block* is an immutable registry object of the current world: its state
// values never change while that world is loaded, so (block, key) -> value is cacheable until the world
// epoch changes (the hologram bumps it on every world/dimension/region change, the same moment the
// Block* -> name cache is dropped). Only definitive answers are stored (a value, or "this block has no such
// state"); a failed memory read is never cached.
//
// Direct-mapped, kSlots entries, one short mutex (the render thread's state compare and the game thread's
// Easy Place may both ask). No allocation after construction.

#include <cstdint>
#include <cstring>
#include <mutex>

namespace lm::svc {

inline uint64_t keyHash(const char *s, size_t n) {
  uint64_t h = 1469598103934665603ull;  // FNV-1a 64
  for (size_t i = 0; i < n; ++i) {
    h ^= uint8_t(s[i]);
    h *= 1099511628211ull;
  }
  return h ^ (uint64_t(n) << 56);
}

struct Stats {
  uint64_t lookups = 0, hits = 0, stores = 0, flushes = 0;
};

template <size_t kSlots = 2048>
class Cache {
  static_assert((kSlots & (kSlots - 1)) == 0, "power of two");

 public:
  // true + *out on a hit for (block, key) in world `epoch`.
  bool get(uintptr_t block, uint64_t key, uint64_t epoch, int64_t *out) {
    std::lock_guard<std::mutex> lk(mu_);
    ++st_.lookups;
    sync(epoch);
    const Slot &s = slots_[index(block, key)];
    if (!s.used || s.block != block || s.key != key) return false;
    ++st_.hits;
    *out = s.value;
    return true;
  }
  void put(uintptr_t block, uint64_t key, uint64_t epoch, int64_t value) {
    std::lock_guard<std::mutex> lk(mu_);
    sync(epoch);
    slots_[index(block, key)] = Slot{block, key, value, 1};
    ++st_.stores;
  }
  Stats stats() {
    std::lock_guard<std::mutex> lk(mu_);
    return st_;
  }

 private:
  struct Slot {
    uintptr_t block;
    uint64_t key;
    int64_t value;
    uint8_t used;
  };
  static size_t index(uintptr_t block, uint64_t key) {
    const uint64_t h = (uint64_t(block) >> 4) * 0x9E3779B97F4A7C15ull ^ key;
    return size_t(h ^ (h >> 29)) & (kSlots - 1);
  }
  void sync(uint64_t epoch) {  // new world: every Block* may be a different object now
    if (epoch == epoch_) return;
    std::memset(static_cast<void *>(slots_), 0, sizeof(slots_));
    epoch_ = epoch;
    ++st_.flushes;
  }
  std::mutex mu_;
  uint64_t epoch_ = 0;
  Slot slots_[kSlots] = {};
  Stats st_;
};

}  // namespace lm::svc
