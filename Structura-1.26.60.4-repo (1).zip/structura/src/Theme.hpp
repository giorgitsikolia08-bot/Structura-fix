#pragma once



#include <cstdint>

namespace lm::theme {

namespace color {

inline constexpr uint32_t Panel = 0xF71B1B1B;          
inline constexpr uint32_t PanelBorder = 0x00202020;
inline constexpr uint32_t Header = 0xFF1B1B1B;         
inline constexpr uint32_t HeaderBorder = 0x00000000;
inline constexpr uint32_t HeaderText = 0xFFF5F5F5;     
inline constexpr uint32_t HeaderPressed = 0xFF2B2B2B;
inline constexpr uint32_t Nav = 0xFF1B1B1B;            
inline constexpr uint32_t Surface = 0xFF242424;        
inline constexpr uint32_t SurfaceRaised = 0xFF2F2F2F;  
inline constexpr uint32_t RowAlt = 0xFF202020;         
inline constexpr uint32_t Divider = 0xFF2E2E2E;
inline constexpr uint32_t Thumb = 0xFF141414;          


inline constexpr uint32_t Control = 0xFF333333;
inline constexpr uint32_t ControlEdge = 0xFF3A3A3A;
inline constexpr uint32_t ControlPressed = 0xFF3D3D3D;
inline constexpr uint32_t ControlDisabled = 0xFF262626;


inline uint32_t Accent = 0xFF0078D4;
inline uint32_t AccentEdge = 0xFF005A9E;
inline uint32_t AccentPressed = 0xFF106EBE;
inline uint32_t AccentSoft = 0x380078D4;  
inline uint32_t AccentText = 0xFF6CB8F6;
inline uint32_t AccentRow = 0xFF2E2E2E;   // AccentSoft 叠在 Nav 上的合成色（applyTheme 里重算）  


inline constexpr uint32_t Success = 0xFF56B56A;
inline constexpr uint32_t SuccessSoft = 0x304FAE6C;
inline constexpr uint32_t Warning = 0xFFFFB900;
inline constexpr uint32_t WarningSoft = 0x30E0A63E;
inline constexpr uint32_t Error = 0xFFE05A5A;
inline constexpr uint32_t ErrorSoft = 0x30E05A5A;
inline constexpr uint32_t Danger = 0xFF8C3434;       
inline constexpr uint32_t DangerEdge = 0xFF5C2121;
inline constexpr uint32_t DangerArmed = 0xFFC04242;  


inline constexpr uint32_t Text = 0xFFF5F5F5;
inline constexpr uint32_t TextSecondary = 0xFFA8A8AC;
inline constexpr uint32_t TextDisabled = 0xFF6E6E72;
inline constexpr uint32_t TextOnAccent = 0xFFFFFFFF;
inline constexpr uint32_t TextOnStatus = 0xFF0F0F0F;  


inline constexpr uint32_t Scrim = 0x9E000000;      
inline constexpr uint32_t ScrollThumb = 0x80A0A0A4;


inline constexpr uint32_t CmpUnknown = 0xFF8A8A8E;


inline constexpr uint32_t Dyes[16] = {
    0xFFF9FFFE, 0xFF9D9D97, 0xFF474F52, 0xFF1D1D21,  
    0xFF835432, 0xFFB02E26, 0xFFF9801D, 0xFFFED83D,  
    0xFF80C71F, 0xFF5E7C16, 0xFF169C9C, 0xFF3AB3DA,  
    0xFF3C44AA, 0xFF8932B8, 0xFFC74EBD, 0xFFF38BAA,  
};
}  


inline constexpr int ThemeCount = 2;
inline void applyTheme(int t) {
  struct A {
    uint32_t accent, edge, pressed, soft, text;
  };
  static constexpr A kThemes[ThemeCount] = {
      {0xFF0078D4, 0xFF005A9E, 0xFF106EBE, 0x380078D4, 0xFF6CB8F6},  
      {0xFF00B7C3, 0xFF00838E, 0xFF00A5B0, 0x3800B7C3, 0xFF7FDCEC},  
  };
  const A &a = kThemes[(t >= 0 && t < ThemeCount) ? t : 0];
  color::Accent = a.accent;
  color::AccentEdge = a.edge;
  color::AccentPressed = a.pressed;
  color::AccentSoft = a.soft;
  color::AccentText = a.text;
  // 选中块：中性灰（#2E2E2E），蓝只留给指示条与开关 —— 与 LHolo 一致
  color::AccentRow = 0xFF2E2E2E;
}


namespace type {
inline constexpr float Title = 16.f;
inline constexpr float Body = 14.f;
inline constexpr float Label = 13.f;
inline constexpr float Small = 12.f;
inline constexpr float Caption = 11.f;
inline constexpr float MinPx = 12.f;      
inline constexpr float ShrinkMin = 0.84f; 
}  


namespace size {
inline constexpr float Row = 40.f;          
inline constexpr float RowCompact = 36.f;   
inline constexpr float Header = 36.f;
inline constexpr float HeaderCompact = 32.f;
inline constexpr float Tab = 32.f;
inline constexpr float TabCompact = 29.f;
inline constexpr float Pad = 10.f;          
inline constexpr float PadCompact = 8.f;
inline constexpr float Gap = 6.f;           
inline constexpr float GapCompact = 5.f;
inline constexpr float Section = 10.f;      
inline constexpr float Radius = 12.f;        
inline constexpr float RadiusPanel = 18.f;
inline constexpr float Edge = 1.f;          
inline constexpr float Border = 1.f;
inline constexpr float Indicator = 3.f;     
inline constexpr float Icon = 14.f;
inline constexpr float NavRail = 52.f;      
inline constexpr float NavMin = 124.f;      
inline constexpr float NavMax = 184.f;
inline constexpr float NavFullFrom = 500.f; 
inline constexpr float Drawer = 200.f;      
inline constexpr float NavIcon = 18.f;
inline constexpr float PanelMinW = 320.f;
inline constexpr float PanelNarrowW = 420.f;  
inline constexpr float MainMinW = 250.f;
inline constexpr float Title = 34.f;        
inline constexpr float TitleCompact = 32.f;
inline constexpr float CardThumbMax = 76.f;
inline constexpr float Popup = 220.f;       
inline constexpr float Margin = 8.f;        
inline constexpr float ScrollBar = 3.f;
inline constexpr float Switch = 34.f;       
inline constexpr float MessageMin = 28.f;   
inline constexpr float Control = 32.f;      
inline constexpr float ControlTall = 34.f;  
inline constexpr float IconSmall = 16.f;    
inline constexpr float IconLead = 12.f;     
inline constexpr float IconTextGap = 10.f;  
inline constexpr float CardNarrowBelow = 400.f;  
inline constexpr float CardColumnMin = 400.f;    
inline constexpr float GridCardMin = 240.f;      
inline constexpr float ToolColumnMax = 0.4f;     
inline constexpr float ToolAreaMin = 340.f;      
inline constexpr float HitMinVisible = 28.f;     
inline constexpr float CardThumbNarrow = 48.f;   
inline constexpr float CardThumbMin = 44.f;
inline constexpr float CardThumbCompact = 36.f;  
inline constexpr float ButtonMinW = 60.f;        
inline constexpr float IconButton = 36.f;        
inline constexpr float ActionMinW = 200.f;       
inline constexpr float SegmentMinW = 160.f;
inline constexpr float SearchMinW = 140.f;
inline constexpr float Field = 38.f;             
inline constexpr float Dialog = 360.f;           
inline constexpr float WideFrom = 360.f;         
inline constexpr float PreviewMin = 64.f, PreviewMax = 180.f;
inline constexpr float ContentMinH = 150.f;      
inline constexpr float TwoColumnsFrom = 290.f;   
inline constexpr float SwatchCell = 40.f;        
inline constexpr float ToastMax = 420.f;
}  



namespace space {
inline constexpr float S1 = 1.f, S2 = 2.f, S3 = 3.f, S4 = 4.f, S6 = 6.f, S8 = 8.f, S10 = 10.f, S12 = 12.f,
                       S14 = 14.f, S16 = 16.f, S20 = 20.f;
}  




namespace style {
enum SizeMode : int { SizeCompact = 0, SizeMedium, SizeLarge, SizeAuto, SizeModeCount };
enum OpacityMode : int { Op25 = 0, Op50, Op75, Op100, OpCustom, OpacityModeCount };
enum LayoutMode : int { LayoutAuto = 0, LayoutCompact, LayoutGrid, LayoutVertical, LayoutHorizontal, LayoutModeCount };
enum LabelMode : int { LabelsIconText = 0, LabelsIcons, LabelsText, LabelModeCount };

enum Ink : int { InkBg = 0, InkBorder, InkText, InkIcon, InkSelected, InkCount };

inline constexpr float SizeScale[3] = {0.8f, 0.9f, 1.1f};      
inline constexpr float SpacingScale[3] = {0.8f, 1.f, 1.15f};   
inline constexpr float AutoScaleMin = 0.8f, AutoScaleMax = 1.1f;
inline constexpr float AutoSmallShortSide = 340.f;  
inline constexpr float AutoTabletShortSide = 560.f; 
inline constexpr float AutoLargeShortSide = 720.f;
inline constexpr float AutoPortraitNarrow = 400.f;  

inline constexpr float TouchMin = 34.f;

inline constexpr int OpacityPreset[4] = {25, 50, 75, 100};
inline constexpr int OpacityMinPct = 25, OpacityMaxPct = 100, OpacityStepPct = 5;

inline constexpr float OpacityFloor[InkCount] = {0.25f, 0.35f, 0.8f, 0.6f, 0.5f};
inline constexpr float OpacityWarnBelow = 0.5f;

inline constexpr int InkStrip = InkCount;
inline constexpr float StripFloor = 0.6f;  

inline constexpr int DefaultSize = SizeMedium;
inline constexpr int DefaultLayout = LayoutAuto;
inline constexpr int DefaultLabels = LabelsIconText;
inline constexpr int DefaultOpacityMode = OpCustom;
inline constexpr int DefaultOpacity[InkCount] = {85, 85, 100, 100, 85};


inline float textFloor(float bg) {
  const float f = 1.f - 0.5f * bg;
  return f > OpacityFloor[InkText] ? f : OpacityFloor[InkText];
}
}  

struct UiStyle {
  int size = style::DefaultSize;      
  int layout = style::DefaultLayout;  
  int labels = style::DefaultLabels;  
  float scale = 0.9f;                 
  float spacing = 1.f;                
  float touchMinDp = style::TouchMin; 
  float op[style::InkCount] = {1.f, 1.f, 1.f, 1.f, 1.f};  
};


inline void resolveOpacity(int mode, const int pct[style::InkCount], float out[style::InkCount]) {
  using namespace style;
  for (int i = 0; i < InkCount; ++i) {
    const int p = (mode >= Op25 && mode <= Op100) ? OpacityPreset[mode] : pct[i];
    const float v = float(p < OpacityMinPct ? OpacityMinPct : p > OpacityMaxPct ? OpacityMaxPct : p) / 100.f;
    out[i] = v < OpacityFloor[i] ? OpacityFloor[i] : v;
  }
  const float tf = textFloor(out[InkBg]);
  if (out[InkText] < tf) out[InkText] = tf;
}


namespace motion {
inline constexpr int TabFade = 160;
inline constexpr float TabSlideDp = 8.f;
inline constexpr int MessageFade = 160;
inline constexpr int LoadingStep = 400;
inline constexpr int ViewMs = 180;    // 页面切换：淡入 + 轻微上滑
inline constexpr int NavBlockMs = 200;  // 侧边栏选中块移动时长
inline constexpr int NavBarDelayMs = 70;  // 蓝条滞后：先让色块走
inline constexpr int NavBarMs = 300;    // 蓝条自己走得更慢  
}  

}  
