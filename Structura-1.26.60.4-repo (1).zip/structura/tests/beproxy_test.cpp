// Host test for BlockActorProxy.hpp (textured stand-ins of block-actor blocks).
//   beproxy_test                 -> unit checks (orientation, boxes, names)
//   beproxy_test <names.txt>     -> also classifies every block name of the file (one per line) and prints
//                                   "name<TAB>block<TAB>fallback<TAB>n" for the ones with a stand-in, for the
//                                   samples cross-check in scripts/host_test.sh
#include <cmath>
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

#include "BlockActorProxy.hpp"

using namespace lm;
static int gFail = 0, gOk = 0;
#define CHECK(c)                                                         \
  do {                                                                   \
    if (c) ++gOk;                                                        \
    else { ++gFail; std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); } \
  } while (0)

static BlockStateValue iv(const char *k, int v) {
  BlockStateValue s;
  s.key = k;
  s.type = 3;  // nbt Int
  s.i = v;
  return s;
}
static BlockStateValue sv(const char *k, const char *v) {
  BlockStateValue s;
  s.key = k;
  s.type = 8;  // nbt String
  s.s = v;
  return s;
}
static bool near(float a, float b) { return std::fabs(a - b) < 1e-5f; }
static bool validBox(const beproxy::Box &b) {
  return b.x0 >= 0 && b.y0 >= 0 && b.z0 >= 0 && b.x1 <= 1 && b.y1 <= 1 && b.z1 <= 1 && b.x1 - b.x0 > 0.01f &&
         b.y1 - b.y0 > 0.01f && b.z1 - b.z0 > 0.01f;
}

int main(int argc, char **argv) {
  using beproxy::classify;
  // chests
  {
    auto p = classify("minecraft:chest", {sv("minecraft:cardinal_direction", "north")});
    CHECK(p.ok && p.block == "oak_planks" && p.n == 1 && near(p.box[0].y1, 14.f / 16) && near(p.box[0].x0, 1.f / 16));
    CHECK(classify("ender_chest", {}).block == "obsidian");
    CHECK(classify("trapped_chest", {}).block == "oak_planks");
    CHECK(classify("waxed_oxidized_copper_chest", {}).block == "oxidized_copper");
    CHECK(classify("copper_chest", {}).block == "copper_block");
    CHECK(classify("exposed_copper_chest", {}).block == "exposed_copper");
  }
  // wall signs: the board sits against the supporting block (opposite the facing)
  {
    auto n = classify("wall_sign", {iv("facing_direction", 2)});  // faces north -> on the south edge
    CHECK(n.ok && n.block == "oak_planks" && near(n.box[0].z1, 1.f) && near(n.box[0].z0, 14.f / 16) &&
          near(n.box[0].x0, 0) && near(n.box[0].x1, 1));
    auto s = classify("spruce_wall_sign", {iv("facing_direction", 3)});
    CHECK(s.block == "spruce_planks" && near(s.box[0].z0, 0) && near(s.box[0].z1, 2.f / 16));
    auto w = classify("darkoak_wall_sign", {iv("facing_direction", 4)});
    CHECK(w.block == "dark_oak_planks" && near(w.box[0].x0, 14.f / 16) && near(w.box[0].x1, 1));
    auto e = classify("pale_oak_wall_sign", {sv("facing", "east")});  // Java-style string state
    CHECK(e.block == "pale_oak_planks" && near(e.box[0].x0, 0) && near(e.box[0].x1, 2.f / 16));
    CHECK(near(n.box[0].y0, 4.5f / 16) && near(n.box[0].y1, 12.5f / 16));
  }
  // standing signs: board axis from ground_sign_direction, plus the post
  {
    auto a = classify("standing_sign", {iv("ground_sign_direction", 0)});
    CHECK(a.ok && a.n == 2 && near(a.box[0].x0, 0) && near(a.box[0].x1, 1) && a.box[0].z1 - a.box[0].z0 < 0.2f);
    auto b = classify("birch_standing_sign", {iv("ground_sign_direction", 4)});
    CHECK(b.block == "birch_planks" && near(b.box[0].z0, 0) && near(b.box[0].z1, 1) && b.box[0].x1 - b.box[0].x0 < 0.2f);
    auto c = classify("crimson_standing_sign", {iv("ground_sign_direction", 12)});
    CHECK(c.block == "crimson_planks" && near(c.box[0].z1, 1));
    auto d = classify("oak_sign", {iv("rotation", 8)});  // Java name
    CHECK(d.ok && near(d.box[0].x1, 1) && d.n == 2);
    CHECK(validBox(a.box[1]) && a.box[1].y1 <= a.box[0].y0 + 1e-6f);
  }
  // hanging signs
  {
    auto h = classify("cherry_hanging_sign", {iv("facing_direction", 4), iv("attached_bit", 0), iv("hanging", 1)});
    CHECK(h.ok && h.block == "cherry_planks" && h.box[0].x1 - h.box[0].x0 < 0.2f);
    auto g = classify("bamboo_hanging_sign", {iv("facing_direction", 2), iv("attached_bit", 1), iv("ground_sign_direction", 4)});
    CHECK(g.block == "bamboo_planks" && g.box[0].x1 - g.box[0].x0 < 0.2f);
    CHECK(classify("dark_oak_hanging_sign", {}).block == "dark_oak_planks");
  }
  // beds, banners, heads, shulkers, misc
  {
    auto b = classify("bed", {iv("direction", 1)});
    CHECK(b.ok && b.block == "red_wool" && near(b.box[0].y1, 9.f / 16));
    CHECK(classify("light_blue_bed", {}).block == "light_blue_wool");
    CHECK(!classify("flower_bed", {}).ok);
    auto wb = classify("wall_banner", {iv("facing_direction", 5)});
    CHECK(wb.ok && wb.block == "white_wool" && near(wb.box[0].x0, 0) && wb.box[0].x1 <= 1.f / 16 + 1e-6f);
    CHECK(classify("standing_banner", {iv("ground_sign_direction", 0)}).n == 2);
    CHECK(classify("red_wall_banner", {sv("facing", "north")}).block == "red_wool");
    auto sk = classify("skeleton_skull", {iv("facing_direction", 1)});
    CHECK(sk.ok && sk.block == "bone_block" && near(sk.box[0].y0, 0) && near(sk.box[0].y1, 0.5f));
    auto wk = classify("wither_skeleton_skull", {iv("facing_direction", 3)});
    CHECK(wk.block == "coal_block" && near(wk.box[0].z0, 0) && near(wk.box[0].y0, 4.f / 16));
    CHECK(classify("zombie_wall_head", {sv("facing", "west")}).box[0].x1 == 1.f);
    CHECK(!classify("cave_vines_head_with_berries", {}).ok);
    CHECK(classify("undyed_shulker_box", {}).block == "purpur_block");
    CHECK(classify("light_gray_shulker_box", {}).block == "light_gray_concrete");
    CHECK(classify("decorated_pot", {}).block == "hardened_clay");
    auto fr = classify("frame", {iv("facing_direction", 1)});
    CHECK(fr.ok && near(fr.box[0].y0, 0) && fr.box[0].y1 <= 1.f / 16 + 1e-6f);
    // ordinary blocks are never proxied
    for (const char *n : {"stone", "oak_planks", "glass", "oak_stairs", "chest_boat", "bedrock", "sea_lantern",
                          "redstone_wire", "oak_door", "head_of_nothing_block"})
      CHECK(!classify(n, {}).ok);
  }
  // every stand-in box is inside the block and not degenerate
  for (const char *n : {"chest", "wall_sign", "standing_sign", "oak_hanging_sign", "bed", "wall_banner",
                        "standing_banner", "skeleton_skull", "creeper_head", "decorated_pot", "flower_pot", "bell",
                        "conduit", "frame", "glow_frame", "white_shulker_box"}) {
    for (int f = 0; f < 6; ++f)
      for (int r = 0; r < 16; ++r) {
        auto p = classify(n, {iv("facing_direction", f), iv("ground_sign_direction", r)});
        CHECK(p.ok && p.n >= 1 && p.n <= 2);
        for (int i = 0; i < p.n; ++i) CHECK(validBox(p.box[i]));
      }
  }

  if (argc > 1) {
    std::ifstream in(argv[1]);
    std::string line;
    while (std::getline(in, line)) {
      if (line.empty()) continue;
      auto p = classify(line, {});
      if (p.ok) std::printf("%s\t%s\t%s\t%d\n", line.c_str(), p.block.c_str(), p.fallback.c_str(), p.n);
    }
  }
  std::fprintf(stderr, "beproxy: %d ok, %d failed\n", gOk, gFail);
  return gFail ? 1 : 0;
}
