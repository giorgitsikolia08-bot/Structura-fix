// Regression test: launcher document picker callback lifetime (App.cpp importFile).
//
// Model of preloader-android 5d108da src/pl/runtime/InputBridge.cpp (RequestDocument,
// DispatchDocumentResult, PLRequestDocument): the request stores the callback together with its userData
// and returns; the result is dispatched LATER (activity result, Java UI thread). The logic below is the
// same as the preloader's; only CallActivityStringMethod is replaced by a flag.
//
//   default run : the fixed client (no userData)          -> must import exactly once, no ASan report
//   --old       : the 1.21.4 client (&local std::function)  -> under ASan with
//                 ASAN_OPTIONS=detect_stack_use_after_return=1 this reports stack-use-after-return
#include <cstdio>
#include <cstring>
#include <functional>
#include <mutex>
#include <string>

namespace pl::input {
struct DocumentResult {
  bool success = false;
  std::string path, displayName, error;
};
using DocumentCallback = std::function<void(const DocumentResult &)>;
}  // namespace pl::input
using PLDocumentResultCallback = void (*)(bool, const char *, const char *, const char *, void *);

namespace model {
std::mutex g_callbackMutex;
pl::input::DocumentCallback g_documentCallback;
bool g_activityOk = true;
bool RequestDocument(std::string mimeType, pl::input::DocumentCallback callback) {
  if (!callback) return false;
  {
    std::lock_guard<std::mutex> lock(g_callbackMutex);
    if (g_documentCallback) return false;
    g_documentCallback = std::move(callback);
  }
  if (mimeType.empty()) mimeType = "*/*";
  if (g_activityOk) return true;  // CallActivityStringMethod("openPreloaderDocumentPicker", mimeType)
  std::lock_guard<std::mutex> lock(g_callbackMutex);
  g_documentCallback = {};
  return false;
}
void DispatchDocumentResult(pl::input::DocumentResult result) {
  pl::input::DocumentCallback callback;
  {
    std::lock_guard<std::mutex> lock(g_callbackMutex);
    callback = std::move(g_documentCallback);
    g_documentCallback = {};
  }
  if (callback) callback(result);
}
bool PLRequestDocument(const char *mimeType, PLDocumentResultCallback callback, void *userData) {
  if (!callback) return false;
  return RequestDocument(mimeType ? mimeType : "*/*", [callback, userData](const pl::input::DocumentResult &r) {
    callback(r.success, r.path.c_str(), r.displayName.c_str(), r.error.c_str(), userData);
  });
}
}  // namespace model

int gImports = 0;
std::string gLastPath;
void importOne(const pl::input::DocumentResult &r) {
  ++gImports;
  gLastPath = r.path;
}

// 1.21.4 App.cpp importFile (launcher branch), verbatim apart from the function pointer.
__attribute__((noinline)) bool oldClient() {
  auto onPicked = [](const pl::input::DocumentResult &r) { importOne(r); };
  std::function<void(const pl::input::DocumentResult &)> cb = onPicked;
  return model::PLRequestDocument(
      "*/*",
      [](bool success, const char *path, const char *displayName, const char *error, void *ud) {
        pl::input::DocumentResult r;
        r.success = success;
        r.path = path ? path : "";
        r.displayName = displayName ? displayName : "";
        r.error = error ? error : "";
        (*static_cast<std::function<void(const pl::input::DocumentResult &)> *>(ud))(r);
      },
      &cb);
}

// 1.21.5 App.cpp importFile (launcher branch).
__attribute__((noinline)) bool newClient() {
  return model::PLRequestDocument(
      "*/*",
      [](bool success, const char *path, const char *displayName, const char *error, void *) {
        pl::input::DocumentResult r;
        r.success = success;
        r.path = path ? path : "";
        r.displayName = displayName ? displayName : "";
        r.error = error ? error : "";
        importOne(r);
      },
      nullptr);
}

__attribute__((noinline)) void clobberStack() {
  volatile char junk[4096];
  for (size_t i = 0; i < sizeof(junk); ++i) junk[i] = char(0xA5);
  (void)junk[7];
}

int main(int argc, char **argv) {
  const bool old = argc > 1 && std::strcmp(argv[1], "--old") == 0;
  int fails = 0, passes = 0;
  auto check = [&](bool c, const char *what) {
    if (c) ++passes;
    else { ++fails; std::fprintf(stderr, "FAIL %s\n", what); }
  };
  const bool requested = old ? oldClient() : newClient();
  check(requested, "request accepted");
  clobberStack();  // the request frame is gone before the user picks a file
  pl::input::DocumentResult res;
  res.success = true;
  res.path = "/data/user/0/x/cache/picked.litematic";
  res.displayName = "picked.litematic";
  model::DispatchDocumentResult(res);
  check(gImports == 1, "imported exactly once");
  check(gLastPath == res.path, "imported the picked path");
  // a second dispatch (no pending request) must not call anything
  model::DispatchDocumentResult(res);
  check(gImports == 1, "no call without a pending request");
  // activity unavailable: request refused, slot released for the next request (and for other mods)
  model::g_activityOk = false;
  check(!newClient(), "refused when the launcher cannot open the picker");
  model::g_activityOk = true;
  check(newClient(), "slot free again after a refused request");
  model::DispatchDocumentResult(res);
  check(gImports == 2, "second request delivered");
  std::printf("document_cb (%s client): %d passed, %d failed\n", old ? "1.21.4" : "1.21.5", passes, fails);
  return fails ? 1 : 0;
}
