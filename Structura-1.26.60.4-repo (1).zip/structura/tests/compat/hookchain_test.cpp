// Compatibility tests for hook-slot handling (host, ASan+UBSan+TSan-free).
// The chain model below mirrors preloader-android 5d108da src/pl/memory/Hook.cpp HookData::rebuildChain:
// elements sorted by (priority, insertion id); each element's slot = next element's detour, the last one's
// slot = the Gloss trampoline ("origin"); hook() inserts + rebuilds, unhook() erases + rebuilds.
#include <atomic>
#include <chrono>
#include <cstdio>
#include <set>
#include <thread>

#include "../../src/HookChain.hpp"

namespace {
int gFails = 0, gPass = 0;
#define CHECK(c)                                                         \
  do {                                                                   \
    if (c) ++gPass;                                                      \
    else { ++gFails; std::fprintf(stderr, "FAIL %s:%d %s\n", __FILE__, __LINE__, #c); } \
  } while (0)

using Fn = int (*)(int);

struct Chain {  // one hooked target
  struct E {
    Fn detour; Fn *slot; int prio; int id;
    bool operator<(const E &o) const { return prio != o.prio ? prio < o.prio : id < o.id; }
  };
  Fn origin = nullptr;
  Fn start = nullptr;
  std::set<E> chain;
  int next = 0;
  static void st(Fn &slot, Fn v) { __atomic_store_n(&slot, v, __ATOMIC_RELEASE); }
  void rebuild() {  // same statement order as rebuildChain()
    Fn *prev = nullptr;
    for (auto &e : chain) {
      // (the preloader uses plain stores; atomic stores here only keep the host test free of formal UB)
      if (!prev) { st(start, e.detour); prev = e.slot; st(*prev, origin); }
      else { st(*prev, e.detour); prev = e.slot; }
    }
    if (prev) st(*prev, origin); else st(start, origin);
  }
  void hook(Fn d, Fn *slot, int prio = 200) { chain.insert({d, slot, prio, next++}); rebuild(); }
  void unhook(Fn d) {
    for (auto it = chain.begin(); it != chain.end(); ++it)
      if (it->detour == d) { chain.erase(it); break; }
    rebuild();
  }
  int call(int v) const { return __atomic_load_n(&start, __ATOMIC_ACQUIRE)(v); }
};

std::atomic<int> gTrampolineCalls{0}, gOtherCalls{0};
int trampoline(int v) { gTrampolineCalls.fetch_add(1); return v + 1000; }  // "the game"

Fn gOurSlot = nullptr;    // Structura's slot
Fn gOtherSlot = nullptr;  // another mod's slot
int ourDetour(int v) { return lm::hookchain::chainNext(gOurSlot)(v) + 1; }
int otherDetour(int v) { gOtherCalls.fetch_add(1); return lm::hookchain::chainNext(gOtherSlot)(v) + 10; }
// Structura's own reads (Hologram getBlockViaChain pattern): "next after us", loaded per call.
int ownReadViaChain(int v) { return lm::hookchain::chainNext(gOurSlot)(v); }

void testInstallWindow() {
  // GlossHook redirects the target before rebuildChain stores the slot: a call in that window must wait,
  // not jump to address 0 (the 2.0 Easy Place detours called oX(...) directly).
  gOurSlot = nullptr;
  std::atomic<bool> started{false};
  int got = 0;
  std::thread caller([&] { started = true; got = ourDetour(5); });
  while (!started) {}
  std::this_thread::sleep_for(std::chrono::milliseconds(20));
  __atomic_store_n(&gOurSlot, &trampoline, __ATOMIC_RELEASE);
  caller.join();
  CHECK(got == 1006);
}

void testSlotRewrite() {
  gOurSlot = gOtherSlot = nullptr;
  gTrampolineCalls = 0; gOtherCalls = 0;
  Chain c;
  c.origin = &trampoline;
  c.hook(&ourDetour, &gOurSlot);
  CHECK(gOurSlot == &trampoline);
  const Fn staleCopy = gOurSlot;  // what 2.0 stored in sGetBlock at install time

  // Another mod hooks the same target later with the same priority: it runs after Structura.
  c.hook(&otherDetour, &gOtherSlot);
  CHECK(gOurSlot == &otherDetour);
  CHECK(c.call(1) == 1 + 1000 + 10 + 1);  // game call: both detours run once, game once
  CHECK(gOtherCalls == 1 && gTrampolineCalls == 1);

  // Own reads must still see the other mod (it may virtualize/override blocks).
  CHECK(ownReadViaChain(1) == 1011);
  CHECK(gOtherCalls == 2);
  // Regression evidence: the cached copy skips the other mod entirely.
  const int before = gOtherCalls;
  CHECK(staleCopy(1) == 1001);
  CHECK(gOtherCalls == before);

  // The other mod unhooks: own reads follow, nothing points at the removed detour.
  c.unhook(&otherDetour);
  CHECK(gOurSlot == &trampoline);
  CHECK(ownReadViaChain(2) == 1002);
  CHECK(gOtherCalls == before);

  // A higher-priority mod (runs first) does not change "next after us".
  c.hook(&otherDetour, &gOtherSlot, 100);
  CHECK(gOtherSlot == &ourDetour);
  CHECK(gOurSlot == &trampoline);
  CHECK(c.call(0) == 1011);
  c.unhook(&otherDetour);
  c.unhook(&ourDetour);
  CHECK(c.start == &trampoline);
}

void testPeekWhenHookFailed() {
  // Code outside a detour (Easy Place placeNow) may run when the hook was never installed: it must get
  // nullptr and fail the placement instead of waiting forever or calling address 0.
  Fn never = nullptr;
  CHECK(lm::hookchain::chainPeek(never) == nullptr);
  const Fn p = lm::hookchain::chainPeek(never);
  const bool placed = p && p(1);
  CHECK(!placed);
}

void testConcurrentRewrite() {
  // Game thread calling while another mod hooks/unhooks repeatedly: every call reaches the game exactly
  // once and never a null slot.
  gOurSlot = gOtherSlot = nullptr;
  gTrampolineCalls = 0;
  Chain c;
  c.origin = &trampoline;
  c.hook(&ourDetour, &gOurSlot);
  std::atomic<bool> stop{false};
  std::atomic<int> calls{0}, bad{0};
  std::thread game([&] {
    while (!stop.load()) {
      const int r = c.call(0);
      if (r != 1001 && r != 1011) bad.fetch_add(1);
      calls.fetch_add(1);
    }
  });
  for (int i = 0; i < 2000; ++i) { c.hook(&otherDetour, &gOtherSlot); c.unhook(&otherDetour); }
  stop = true;
  game.join();
  CHECK(bad == 0);
  CHECK(gTrampolineCalls == calls);
}
}  // namespace

int main() {
  testInstallWindow();
  testSlotRewrite();
  testPeekWhenHookFailed();
  testConcurrentRewrite();
  std::printf("hookchain: %d passed, %d failed\n", gPass, gFails);
  return gFails ? 1 : 0;
}
