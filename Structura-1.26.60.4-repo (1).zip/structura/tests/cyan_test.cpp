// Host test for CyanStyle.hpp (cyan hologram style): alpha range, tint, block-grid edges.
// Edges are checked against a brute-force reference over random shapes: a unit edge of the grid is drawn
// exactly once when 1..3 of the 4 cells around it are occupied (n == 4: interior, n == 0: not ours).
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <map>
#include <random>
#include <set>
#include <tuple>
#include <vector>

#include "CyanStyle.hpp"

using namespace lm;
static int gFail = 0, gOk = 0;
#define CHECK(c)                                                              \
  do {                                                                        \
    if (c) ++gOk;                                                             \
    else { ++gFail; std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); } \
  } while (0)

static void testAlpha() {
  float last = -1.f;
  for (int i = 0; i <= 100; ++i) {
    const float a = cyan::alphaFor(i / 100.f);
    CHECK(a >= 0.5f && a <= 0.9f);
    CHECK(a < 0.99f);  // texFrameSetup picks the translucent "particles_blend" look below 0.99
    CHECK(a >= last);
    last = a;
  }
  CHECK(cyan::alphaFor(-3.f) == cyan::alphaFor(0.f));
  CHECK(cyan::alphaFor(7.f) == cyan::alphaFor(1.f));
  // default slider (1.0) gives a clearly visible hologram, the minimum (0.1) still well above 1.21.8's 0.185
  CHECK(std::fabs(cyan::alphaFor(1.f) - 0.88f) < 1e-4f);
  CHECK(cyan::alphaFor(0.1f) > 0.5f);
}

static void testTint() {
  bool alphaKept = true, noBrighter = true, blueKept = true, monotone = true, cast = true;
  for (uint32_t r = 0; r < 256; r += 15)
    for (uint32_t g = 0; g < 256; g += 15)
      for (uint32_t b = 0; b < 256; b += 15) {
        const uint8_t alpha = uint8_t((r * 7 + g) & 0xFF);
        const uint32_t in = 0x12000000u | (b << 16) | (g << 8) | r;
        const uint32_t o = cyan::tint(in, alpha);
        const uint32_t orr = o & 0xFF, og = (o >> 8) & 0xFF, ob = (o >> 16) & 0xFF;
        alphaKept = alphaKept && (o >> 24) == alpha;
        noBrighter = noBrighter && orr <= r && og <= g && ob <= b;  // multiply: never a white glare
        blueKept = blueKept && ob == b;
        // neutral light factor -> cyan-blue cast b > g > r (for non-black)
        if (r == g && g == b && r >= 30) cast = cast && ob > og && og > orr;
      }
  for (uint32_t v = 1; v < 256; ++v) {  // brighter light factor -> brighter output (detail survives)
    const uint32_t lo = cyan::tint(0xFF000000u | ((v - 1) * 0x010101u), 0xFF), hi = cyan::tint(0xFF000000u | (v * 0x010101u), 0xFF);
    monotone = monotone && (hi & 0xFF) >= (lo & 0xFF) && ((hi >> 8) & 0xFF) >= ((lo >> 8) & 0xFF);
  }
  CHECK(alphaKept);
  CHECK(noBrighter);
  CHECK(blueKept);
  CHECK(cast);
  CHECK(monotone);
  // byte order: r = low byte (Tessellator::color packs a<<24|b<<16|g<<8|r, verified at 0xa76edac)
  const uint32_t white = cyan::tint(0xFFFFFFFFu, 0xE0);
  CHECK((white & 0xFF) == cyan::kMulR && ((white >> 8) & 0xFF) == cyan::kMulG && ((white >> 16) & 0xFF) == cyan::kMulB);
  CHECK((white >> 24) == 0xE0);
  // reference calibration: a lit neutral face (~131 on blue) gives ~ (107,124,131) like the screenshot
  const uint32_t ref = cyan::tint(0xFF838383u, 0xFF);
  CHECK(std::abs(int(ref & 0xFF) - 107) <= 2 && std::abs(int((ref >> 8) & 0xFF) - 124) <= 2 && ((ref >> 16) & 0xFF) == 131);
  // 1.21.8 regression guard: grey must not turn dark teal (red channel kept >= 75%)
  CHECK((cyan::tint(0xFF808080u, 0xFF) & 0xFF) >= 96);
}

using Seg = std::tuple<int, int, int, int, int, int>;  // integer grid endpoints, sorted
static Seg seg(int ax, int ay, int az, int bx, int by, int bz) {
  int a[3] = {ax, ay, az}, b[3] = {bx, by, bz};
  if (std::tie(a[0], a[1], a[2]) > std::tie(b[0], b[1], b[2])) std::swap(a, b);
  return {a[0], a[1], a[2], b[0], b[1], b[2]};
}
using Cells = std::set<std::tuple<int, int, int>>;

static std::multiset<Seg> emitted(const Cells &cells, bool *liftOk) {
  std::multiset<Seg> out;
  auto occ = [&](int x, int y, int z) { return cells.count({x, y, z}) > 0; };
  for (auto [x, y, z] : cells)
    cyan::gridEdgesFor(x, y, z, occ, [&](int a, int px, int py, int pz, int lb, int lc) {
      int e[3] = {px, py, pz};
      e[a] += 1;
      out.insert(seg(px, py, pz, e[0], e[1], e[2]));
      // the lift points toward empty cells only: the cell on the lifted side must be empty
      const int b = (a + 1) % 3, c = (a + 2) % 3;
      if (lb || lc) {
        int q[3] = {px, py, pz};
        q[b] += lb > 0 ? 0 : -1;
        q[c] += lc > 0 ? 0 : -1;
        if (lb == 0 || lc == 0) {
          // flat seam: both cells on the lifted side empty
          for (int s = 0; s < 2; ++s) {
            int r[3] = {px, py, pz};
            if (lb) { r[b] += lb > 0 ? 0 : -1; r[c] += s - 1; }
            else { r[c] += lc > 0 ? 0 : -1; r[b] += s - 1; }
            if (occ(r[0], r[1], r[2])) *liftOk = false;
          }
        } else if (occ(q[0], q[1], q[2])) {
          *liftOk = false;
        }
      }
    });
  return out;
}

// Reference: every unit grid edge near the shape, classified by its 4 surrounding cells.
static std::multiset<Seg> reference(const Cells &cells, int lo, int hi) {
  std::multiset<Seg> out;
  auto occ = [&](int x, int y, int z) { return cells.count({x, y, z}) > 0; };
  for (int axis = 0; axis < 3; ++axis)
    for (int i = lo; i <= hi; ++i)
      for (int j = lo; j <= hi; ++j)
        for (int k = lo; k <= hi; ++k) {
          int n = 0;
          for (int u = 0; u < 2; ++u)
            for (int v = 0; v < 2; ++v) {
              int p[3] = {i, j, k};
              p[(axis + 1) % 3] -= u;
              p[(axis + 2) % 3] -= v;
              n += occ(p[0], p[1], p[2]);
            }
          if (n < 1 || n > 3) continue;
          int e[3] = {i, j, k};
          e[axis] += 1;
          out.insert(seg(i, j, k, e[0], e[1], e[2]));
        }
  return out;
}

static void testEdges() {
  bool lift = true;
  CHECK(emitted(Cells{{0, 0, 0}}, &lift).size() == 12);
  CHECK(emitted(Cells{{0, 0, 0}, {1, 0, 0}}, &lift).size() == 20);  // 2x1x1: the seam is drawn too
  Cells wall;
  for (int x = 0; x < 8; ++x)
    for (int y = 0; y < 8; ++y) wall.insert({x, y, 0});
  CHECK(emitted(wall, &lift).size() == 320);  // 8x8x1: block grid on both faces (2x144) + 32 rim edges
  Cells cube;
  for (int x = 0; x < 3; ++x)
    for (int y = 0; y < 3; ++y)
      for (int z = 0; z < 3; ++z) cube.insert({x, y, z});
  CHECK(emitted(cube, &lift).size() == 108);  // 144 unit edges - 36 interior
  {
    const auto e = emitted(cube, &lift);
    CHECK(std::set<Seg>(e.begin(), e.end()).size() == e.size());  // no duplicates
  }
  std::mt19937 rng(7);
  int matches = 0, shapes = 0;
  for (int t = 0; t < 300; ++t) {
    Cells cells;
    const int dens = 20 + int(rng() % 75);
    for (int x = 0; x < 5; ++x)
      for (int y = 0; y < 5; ++y)
        for (int z = 0; z < 5; ++z)
          if (int(rng() % 100) < dens) cells.insert({x, y, z});
    if (cells.empty()) continue;
    ++shapes;
    if (emitted(cells, &lift) == reference(cells, -1, 6)) ++matches;
    else std::printf("edge mismatch in shape %d (%zu cells)\n", t, cells.size());
  }
  CHECK(shapes > 250 && matches == shapes);
  CHECK(lift);
}

// Chunk split: every edge has one owner, so building per 16^3 chunk (window occupancy) and packing
// relative to the chunk origin gives exactly the global edge set, endpoints round-trip exactly.
static void testChunkPack() {
  std::mt19937 rng(11);
  Cells cells;
  for (int x = 10; x < 40; ++x)
    for (int y = -3; y < 20; ++y)
      for (int z = 12; z < 35; ++z)
        if (rng() % 100 < 45) cells.insert({x, y, z});
  auto occ = [&](int x, int y, int z) { return cells.count({x, y, z}) > 0; };
  auto fdiv = [](int v) { return v >= 0 ? v / 16 : -((-v + 15) / 16); };
  std::multiset<Seg> got;
  bool packOk = true, exact = true;
  for (auto [x, y, z] : cells) {
    const int ox = fdiv(x) * 16, oy = fdiv(y) * 16, oz = fdiv(z) * 16;
    cyan::gridEdgesFor(x, y, z, occ, [&](int a, int px, int py, int pz, int lb, int lc) {
      if (!cyan::packable(px - ox, py - oy, pz - oz)) { packOk = false; return; }
      float A[3], B[3];
      cyan::unpackEdge(cyan::packEdge(a, px - ox, py - oy, pz - oz, lb, lc), ox, oy, oz, A, B);
      const int b = (a + 1) % 3, c = (a + 2) % 3;
      const float want[3] = {float(px), float(py), float(pz)};
      for (int i = 0; i < 3; ++i) {
        const float lifted = i == b ? cyan::kEdgeLift * lb : i == c ? cyan::kEdgeLift * lc : 0.f;
        if (std::fabs(A[i] - (want[i] + lifted)) > 1e-4f) exact = false;
        if (std::fabs((B[i] - A[i]) - (i == a ? 1.f : 0.f)) > 1e-6f) exact = false;
      }
      got.insert(seg(px, py, pz, px + (a == 0), py + (a == 1), pz + (a == 2)));
    });
  }
  CHECK(packOk);
  CHECK(exact);
  CHECK(got == reference(cells, -5, 42));
}

int main() {
  testAlpha();
  testTint();
  testEdges();
  testChunkPack();
  std::printf("cyan: %d passed, %d failed\n", gOk, gFail);
  return gFail ? 1 : 0;
}
