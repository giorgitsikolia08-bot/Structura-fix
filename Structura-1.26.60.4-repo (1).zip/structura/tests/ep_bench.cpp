// HOST benchmark (x86-64 sandbox, NOT Android): Easy Place hot paths, 1.21.8 call pattern vs 1.21.9.
//
// The 1.21.9 side runs the real new code (EpScan.hpp, EpWorld.hpp, SvCache.hpp, LineRing.hpp). The game is
// not available on the host, so the per-call cost of the game-facing primitives is reproduced with the
// same primitives the Android code uses, counted exactly:
//   expectedAt  (1.21.8, per call): monotonic clock (ctx::fresh) + model mutex + shared_ptr copy + layer box
//                                   + variant lookup + gApiMu mutex + cache read
//   worldBlock  (1.21.8, per call): monotonic clock + 2 x process_vm_readv (player->dim->region) + getBlock
//   replaceable (both)            : gRepMu mutex + unordered_map lookup (1.21.9: memo first)
//   stateValue  (1.21.8)          : findState call + 15 x process_vm_readv; 1.21.9: SvCache first
//   trace       (1.21.8)          : ::write per line on the game thread; 1.21.9: ring push (UI thread writes)
// getBlock is an indirect call into a hash grid (the real BlockSource::getBlock is a game function).
// Numbers are host timings for the same workload on both sides; Android timings are NOT measured here.
//   g++ -std=c++20 -O2 -Isrc tests/ep_bench.cpp -pthread -o /tmp/ep_bench && /tmp/ep_bench
#include <fcntl.h>
#include <sys/uio.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include <mutex>
#include <random>
#include <string>
#include <unordered_map>
#include <vector>

#include "EpScan.hpp"
#include "EpWorld.hpp"
#include "LineRing.hpp"
#include "SvCache.hpp"

namespace {

// ---------------- counters ----------------
struct Cnt {
  uint64_t syscalls = 0, expected = 0, worldReads = 0, mutexes = 0, sharedCopies = 0, fileWrites = 0;
  void reset() { *this = Cnt{}; }
};
Cnt gC;

uintptr_t gPtrA = 0, gPtrB = 0;  // a 2-level pointer chain readable through process_vm_readv
bool vmRead(uintptr_t src, void *dst, size_t n) {
  ++gC.syscalls;
  iovec l{dst, n}, r{reinterpret_cast<void *>(src), n};
  return process_vm_readv(getpid(), &l, 1, &r, 1, 0) == ssize_t(n);
}
int64_t monoMs() {
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return int64_t(ts.tv_sec) * 1000 + ts.tv_nsec / 1000000;
}

// ---------------- the world / structure fixture ----------------
constexpr int SX = 48, SY = 24, SZ = 48;
struct Structure {
  std::vector<uint16_t> var;  // per cell: variant (0xFFFF = air/void)
};
struct Model {
  std::mutex mu;
  std::shared_ptr<const Structure> S;
} gModel;
std::mutex gApiMu, gRepMu;
std::vector<uintptr_t> gVarBlock;  // variant -> game block
std::unordered_map<uintptr_t, int8_t> gRep;
constexpr uintptr_t kAir = 0x100000;

struct WorldGrid {
  std::vector<uintptr_t> cell;
  uintptr_t at(int x, int y, int z) const {
    if (x < -20 || x >= SX + 20 || y < -20 || y >= SY + 20 || z < -20 || z >= SZ + 20) return kAir;
    return cell[size_t(((x + 20) * (SY + 40) + (y + 20)) * (SZ + 40) + (z + 20))];
  }
  uintptr_t &ref(int x, int y, int z) { return cell[size_t(((x + 20) * (SY + 40) + (y + 20)) * (SZ + 40) + (z + 20))]; }
} gWorld;
__attribute__((noinline)) uintptr_t getBlockImpl(const WorldGrid *w, int x, int y, int z) { return w->at(x, y, z); }
uintptr_t (*volatile sGetBlock)(const WorldGrid *, int, int, int) = &getBlockImpl;

uint16_t variantAt(const Structure &S, int x, int y, int z) {
  if (x < 0 || x >= SX || y < 0 || y >= SY || z < 0 || z >= SZ) return 0xFFFF;
  return S.var[size_t((x * SY + y) * SZ + z)];
}

// ---------------- 1.21.8 API path (per call) ----------------
int oldExpectedAt(int x, int y, int z, uintptr_t *out) {
  ++gC.expected;
  if (out) *out = 0;
  if (monoMs() < 0) return 0;  // ctx::fresh
  std::shared_ptr<const Structure> S;
  int box[6];
  {
    std::lock_guard<std::mutex> lk(gModel.mu);
    ++gC.mutexes;
    S = gModel.S;
    ++gC.sharedCopies;
    box[0] = 0; box[1] = SX - 1; box[2] = 0; box[3] = SY - 1; box[4] = 0; box[5] = SZ - 1;
  }
  if (x < box[0] || x > box[1] || y < box[2] || y > box[3] || z < box[4] || z > box[5]) return 0;
  const uint16_t v = variantAt(*S, x, y, z);
  if (v == 0xFFFF) return 0;
  if (out) {
    std::lock_guard<std::mutex> lk(gApiMu);
    ++gC.mutexes;
    *out = gVarBlock[v];
  }
  return 1;
}
uintptr_t oldWorldBlock(int x, int y, int z) {
  ++gC.worldReads;
  if (monoMs() < 0) return 0;
  uintptr_t dim = 0, region = 0;
  if (!vmRead(gPtrA, &dim, 8) || !vmRead(dim, &region, 8) || !region) return 0;
  return sGetBlock(reinterpret_cast<const WorldGrid *>(region), x, y, z);
}
int replaceableBlock(uintptr_t b, uintptr_t air) {
  if (air && b == air) return 1;
  std::lock_guard<std::mutex> lk(gRepMu);
  ++gC.mutexes;
  auto it = gRep.find(b);
  return it == gRep.end() ? 0 : it->second;
}
struct OldWorld {
  uintptr_t air;
  OldWorld() { air = oldWorldBlock(0, 32767, 0); }
  int replaceable(int x, int y, int z, uintptr_t *out = nullptr) const {
    const uintptr_t b = oldWorldBlock(x, y, z);
    if (out) *out = b;
    if (!b) return -1;
    return replaceableBlock(b, air);
  }
  int expected(int x, int y, int z, uintptr_t *out) const { return oldExpectedAt(x, y, z, out); }
  void forget() const {}
};

// ---------------- 1.21.9 path: FastWorld (model of Hologram.cpp) + the real StepWorld ----------------
struct FastBackend {
  std::shared_ptr<const Structure> S;
  uintptr_t region = 0, air = 0;
  uint16_t vk[64];
  uintptr_t vb[64];
  FastBackend() {
    // fastBegin: one snapshot + one region chase per step
    monoMs();
    {
      std::lock_guard<std::mutex> lk(gModel.mu);
      ++gC.mutexes;
      S = gModel.S;
      ++gC.sharedCopies;
    }
    uintptr_t dim = 0;
    if (vmRead(gPtrA, &dim, 8)) vmRead(dim, &region, 8);
    std::memset(vk, 0xFF, sizeof(vk));
  }
  int expected(int x, int y, int z, uintptr_t *out) {
    ++gC.expected;
    if (out) *out = 0;
    const uint16_t v = variantAt(*S, x, y, z);
    if (v == 0xFFFF) return 0;
    if (out) {
      const size_t s = v & 63;
      if (vk[s] == v) *out = vb[s];
      else {
        std::lock_guard<std::mutex> lk(gApiMu);
        ++gC.mutexes;
        *out = vb[s] = gVarBlock[v];
        vk[s] = v;
      }
    }
    return 1;
  }
  uintptr_t world(int x, int y, int z) {
    ++gC.worldReads;
    return region ? sGetBlock(reinterpret_cast<const WorldGrid *>(region), x, y, z) : 0;
  }
  int replaceableOf(uintptr_t b) { return replaceableBlock(b, air); }
};
struct NewWorld {
  mutable FastBackend B;
  mutable lm::epw::StepWorld<FastBackend> M{B};
  uintptr_t air = 0;
  NewWorld() {
    air = B.world(0, 32767, 0);
    B.air = air;
  }
  int replaceable(int x, int y, int z, uintptr_t *out = nullptr) const { return M.replaceable(x, y, z, out); }
  int expected(int x, int y, int z, uintptr_t *out) const { return M.expected(x, y, z, out); }
  void forget() const { M.forget(); }
};

// ---------------- workload setup ----------------
std::vector<std::pair<int, int>> gDiscard;  // tiny discard list (like ep::discarded)
bool discarded(int x, int z) {
  for (auto &d : gDiscard)
    if (d.first == x && d.second == z) return true;
  return false;
}
void buildFixture(double builtFraction, uint32_t seed) {
  std::mt19937 rng(seed);
  auto S = std::make_shared<Structure>();
  S->var.resize(size_t(SX) * SY * SZ);
  gVarBlock.assign(64, 0);
  for (int v = 0; v < 64; ++v) gVarBlock[size_t(v)] = 0x200000 + 0x40 * uintptr_t(v);
  gWorld.cell.assign(size_t(SX + 40) * (SY + 40) * (SZ + 40), kAir);
  for (int x = 0; x < SX; ++x)
    for (int y = 0; y < SY; ++y)
      for (int z = 0; z < SZ; ++z) {
        const uint16_t v = (rng() % 100 < 70) ? uint16_t(rng() % 64) : 0xFFFF;  // 70% solid structure
        S->var[size_t((x * SY + y) * SZ + z)] = v;
        if (v != 0xFFFF && (rng() % 10000) < builtFraction * 10000) gWorld.ref(x, y, z) = gVarBlock[v];
      }
  gModel.S = S;
  gRep.clear();
  gRep[kAir] = 1;
  for (auto b : gVarBlock) gRep[b] = 0;
  // pointer chain player->dim->region for process_vm_readv
  static uintptr_t chainB = 0, chainA = 0;
  chainB = reinterpret_cast<uintptr_t>(&gWorld);
  chainA = reinterpret_cast<uintptr_t>(&chainB);
  gPtrB = chainB;
  static uintptr_t holder = 0;
  holder = chainA;
  gPtrA = reinterpret_cast<uintptr_t>(&holder);
  // gPtrA -> holder(= &chainB) ; read(gPtrA) = &chainB ; read(&chainB) = &gWorld
}

struct Result {
  double usPerStep;
  Cnt c;
  int placed;
};

// run-mode step (autoTick runScope != 0): batch k, reach 6.7, eye inside the structure
template <bool kNew>
Result runStep(int steps, int batch, bool bottomUp, uint32_t seed, double built) {
  buildFixture(built, seed);
  gC.reset();
  std::mt19937 rng(seed + 1);
  int placed = 0;
  const float reach = 6.7f, lim = (reach - 0.5f) * (reach - 0.5f);
  const auto t0 = std::chrono::steady_clock::now();
  for (int s = 0; s < steps; ++s) {
    const float ex = 8.f + float(rng() % 32) + 0.3f, ey = 4.f + float(rng() % 16) + 0.6f, ez = 8.f + float(rng() % 32) + 0.4f;
    const int r = int(std::ceil(reach));
    const int b[6] = {std::max(0, int(ex) - r), std::min(SX - 1, int(ex) + r), std::max(0, int(ey) - r),
                      std::min(SY - 1, int(ey) + r), std::max(0, int(ez) - r), std::min(SZ - 1, int(ez) + r)};
    if constexpr (!kNew) {
      OldWorld W;
      for (int i = 0; i < batch; ++i) {
        float best = 1e30f;
        bool found = false;
        int tx = 0, ty = 0, tz = 0;
        for (int y = b[2]; y <= b[3]; ++y) {
          for (int x = b[0]; x <= b[1]; ++x)
            for (int z = b[4]; z <= b[5]; ++z) {
              const float dx = x + 0.5f - ex, dy = y + 0.5f - ey, dz = z + 0.5f - ez;
              const float d2 = dx * dx + dy * dy + dz * dz;
              if (d2 > lim || d2 >= best) continue;
              uintptr_t exp = 0;
              if (!W.expected(x, y, z, &exp) || !exp) continue;
              if (W.replaceable(x, y, z) != 1) continue;
              if (discarded(x, z)) continue;
              best = d2; tx = x; ty = y; tz = z; found = true;
            }
          if (found && bottomUp) break;
        }
        if (!found) break;
        uintptr_t e = 0;
        W.expected(tx, ty, tz, &e);
        gWorld.ref(tx, ty, tz) = e;  // placement
        ++placed;
      }
    } else {
      NewWorld W;
      auto missing = [&](int x, int y, int z) {
        uintptr_t exp = 0;
        if (!W.expected(x, y, z, &exp) || !exp) return false;
        if (W.replaceable(x, y, z) != 1) return false;
        return !discarded(x, z);
      };
      lm::epscan::Cell cells[lm::epscan::kMaxK];
      const int n = lm::epscan::nearest(b, ex, ey, ez, lim, bottomUp, batch, missing, cells);
      for (int i = 0; i < n; ++i) {
        if (i > 0 && !missing(cells[i].x, cells[i].y, cells[i].z)) continue;  // re-verify (fresh after forget)
        uintptr_t e = 0;
        W.expected(cells[i].x, cells[i].y, cells[i].z, &e);
        gWorld.ref(cells[i].x, cells[i].y, cells[i].z) = e;  // placement
        W.forget();
        ++placed;
      }
    }
  }
  const double us = std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count();
  return {us / steps, gC, placed};
}

// aim step (auto mode / tap): crosshair ray of 8 cells, the last one missing; solidNeighbor + choosePlan faces
template <class W>
void aimStep(const W &w, int x0, int y0, int z0) {
  static const int nd[6][3] = {{0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, 0}, {1, 0, 0}};
  for (int i = 0; i < 8; ++i) {
    const int x = x0 + i, y = y0, z = z0;
    uintptr_t exp = 0, wb = 0;
    if (w.expected(x, y, z, &exp)) {
      const int r = w.replaceable(x, y, z, &wb);
      if (r == 1 && wb != exp) {
        bool solid = false;
        for (auto &d : nd) solid = solid || w.replaceable(x + d[0], y + d[1], z + d[2]) == 0;  // solidNeighbor
        for (auto &d : nd) { uintptr_t nb; (void)w.replaceable(x - d[0], y - d[1], z - d[2], &nb); }  // choosePlan
        (void)solid;
        return;
      }
      if (r == 0) return;
    } else if (w.replaceable(x, y, z) == 0) {
      return;
    }
  }
}
template <bool kNew>
Result aimBench(int steps, uint32_t seed) {
  buildFixture(0.5, seed);
  gC.reset();
  std::mt19937 rng(seed);
  const auto t0 = std::chrono::steady_clock::now();
  for (int s = 0; s < steps; ++s) {
    const int x = int(rng() % 30) - 4, y = int(rng() % SY), z = int(rng() % SZ);
    if constexpr (kNew) { NewWorld w; aimStep(w, x, y, z); }
    else { OldWorld w; aimStep(w, x, y, z); }
  }
  const double us = std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count();
  return {us / steps, gC, 0};
}

// choosePlan compares: 24 unique simulated blocks x 3 keys x 2 sides per placement, 40 block types
__attribute__((noinline)) uintptr_t findState(uintptr_t L, uint64_t k) { return L ^ (k * 0x9E37); }
int64_t svUncached(uintptr_t block, const char *key) {
  uintptr_t v = 0;
  for (int i = 0; i < 15; ++i) vmRead(gPtrA, &v, 8);  // the 15 guarded reads of the tree walk
  return int64_t((findState(block, std::strlen(key)) >> 4) & 7);
}
lm::svc::Cache<2048> gSv;
int64_t svCached(uintptr_t block, const char *key) {
  const uint64_t kh = lm::svc::keyHash(key, std::strlen(key));
  int64_t v;
  if (gSv.get(block, kh, 1, &v)) return v;
  v = svUncached(block, key);
  gSv.put(block, kh, 1, v);
  return v;
}
template <bool kNew>
Result planBench(int placements) {
  gC.reset();
  std::mt19937 rng(3);
  static const char *keys[3] = {"weirdo_direction", "upside_down_bit", "minecraft:cardinal_direction"};
  const auto t0 = std::chrono::steady_clock::now();
  for (int p = 0; p < placements; ++p) {
    const uintptr_t type = 0x300000 + 0x1000 * (rng() % 40);
    for (int u = 0; u < 24; ++u) {
      const uintptr_t sim = type + 0x40 * uintptr_t(u % 16), expd = type + 0x40 * 3;
      for (const char *k : keys) {
        if constexpr (kNew) { svCached(sim, k); svCached(expd, k); }
        else { svUncached(sim, k); svUncached(expd, k); }
      }
    }
  }
  const double us = std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count();
  return {us / placements, gC, 0};
}

// trace: 6 lines per placement on the game thread
template <bool kNew>
Result traceBench(int placements, const std::string &path) {
  gC.reset();
  static lm::ring::LineRing<512, 304> ring;
  int fd = ::open(path.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_TRUNC | O_CLOEXEC, 0644);
  double drainUs = 0;
  const auto t0 = std::chrono::steady_clock::now();
  for (int p = 0; p < placements; ++p) {
    for (int l = 0; l < 6; ++l) {
      char line[300];
      const int n = std::snprintf(line, sizeof(line), "[%d] easyplace step %d line %d target 12 64 -40 gen=7", p, p, l);
      if constexpr (kNew) ring.push(line, size_t(n));
      else {
        line[n] = '\n';
        ++gC.fileWrites;
        ++gC.syscalls;
        if (::write(fd, line, size_t(n) + 1) < 0) break;
      }
    }
    if constexpr (kNew) {
      if (p % 40 == 39) {  // UI thread drain every 2 s (~40 placements at 20/s); timed separately
        const auto d0 = std::chrono::steady_clock::now();
        static std::string buf;
        buf.clear();
        ring.drain(buf);
        if (::write(fd, buf.data(), buf.size()) < 0) break;
        drainUs += std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - d0).count();
      }
    }
  }
  const double us = std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count();
  ::close(fd);
  return {(us - drainUs) / placements, gC, int(drainUs / placements * 1000)};  // placed = UI ns/placement
}

template <class F>
Result best3(F f) {  // best of 3 runs (host noise); counters are deterministic
  Result r = f();
  for (int i = 0; i < 2; ++i) {
    Result q = f();
    if (q.usPerStep < r.usPerStep) r = q;
  }
  return r;
}

void row(const char *name, const Result &o, const Result &n, int steps) {
  auto per = [&](uint64_t v) { return double(v) / steps; };
  std::printf("%-34s | %9.2f -> %8.2f us (x%.1f) | syscalls %8.1f -> %6.1f | expected %7.1f -> %6.1f | world %7.1f -> %6.1f | mutex %7.1f -> %6.1f\n",
              name, o.usPerStep, n.usPerStep, n.usPerStep > 0 ? o.usPerStep / n.usPerStep : 0.0, per(o.c.syscalls),
              per(n.c.syscalls), per(o.c.expected), per(n.c.expected), per(o.c.worldReads), per(n.c.worldReads),
              per(o.c.mutexes), per(n.c.mutexes));
}

}  // namespace

int main(int argc, char **argv) {
  const std::string tracePath = argc > 1 ? argv[1] : "/tmp/ep_bench_trace.txt";
  std::printf("HOST benchmark (x86-64 sandbox, 2 cores). Same workload both sides; per step / per placement.\n");
  std::printf("%-34s | %-30s | %-25s | %-25s | %-24s | %s\n", "workload", "time 1.21.8 -> 1.21.9", "syscalls/step",
              "expected/step", "world reads/step", "mutex/step");
  const int steps = 400;
  for (int bu = 0; bu < 2; ++bu)
    for (int batch : {1, 4}) {
      char name[64];
      std::snprintf(name, sizeof(name), "run 95%% built batch %d%s", batch, bu ? " bottomUp" : "");
      const Result o = best3([&] { return runStep<false>(steps, batch, bu, 11, 0.95); });
      const Result n = best3([&] { return runStep<true>(steps, batch, bu, 11, 0.95); });
      row(name, o, n, steps);
      if (o.placed != n.placed) std::printf("  !! placed differs: %d vs %d\n", o.placed, n.placed);
    }
  {
    const Result o = best3([&] { return runStep<false>(steps, 4, false, 12, 1.0); });
    const Result n = best3([&] { return runStep<true>(steps, 4, false, 12, 1.0); });
    row("run nothing missing (batch 4)", o, n, steps);
  }
  {
    const Result o = best3([&] { return aimBench<false>(20000, 5); });
    const Result n = best3([&] { return aimBench<true>(20000, 5); });
    row("aim/tap step (ray+neighbours)", o, n, 20000);
  }
  {
    const Result o = best3([&] { return planBench<false>(300); });
    const Result n = best3([&] { return planBench<true>(300); });
    row("choosePlan compares/placement", o, n, 300);
  }
  {
    const Result o = best3([&] { return traceBench<false>(4000, tracePath); });
    const Result n = best3([&] { return traceBench<true>(4000, tracePath); });
    std::printf("%-34s | %9.2f -> %8.2f us (x%.1f) | game-thread file writes %.1f -> %.1f per placement | UI-thread drain %.3f us/placement\n",
                "trace 6 lines/placement (game thr)", o.usPerStep, n.usPerStep, o.usPerStep / std::max(1e-9, n.usPerStep),
                double(o.c.fileWrites) / 4000, double(n.c.fileWrites) / 4000, n.placed / 1000.0);
  }
  return 0;
}
