// Host tests for the 1.21.9 Easy Place performance helpers (pure headers, no game):
//   EpScan.hpp   - one-pass k-best run scan == the previous "rescan the box for every block of the batch"
//   EpWorld.hpp  - per-step memo: never answers stale world data after forget(), unresolved never memoised
//   SvCache.hpp  - (Block*, key) state cache: exact answers, epoch flush, bounded, thread-safe
//   LineRing.hpp - trace ring: order, drop-oldest accounting, truncation, thread-safe
//   g++ -std=c++20 -O1 -Isrc tests/ep_test.cpp -pthread -o /tmp/ep_test && /tmp/ep_test
#include <atomic>
#include <cstdio>
#include <cstring>
#include <map>
#include <random>
#include <set>
#include <string>
#include <thread>
#include <tuple>
#include <vector>

#include "EpScan.hpp"
#include "EpWorld.hpp"
#include "LineRing.hpp"
#include "SvCache.hpp"

static int gFail = 0, gOk = 0;
#define CHECK(c)                                                              \
  do {                                                                        \
    if (c) ++gOk;                                                             \
    else { ++gFail; std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); } \
  } while (0)

using P3 = std::tuple<int, int, int>;

// ---- EpScan ------------------------------------------------------------------------------------------
// Reference = the 1.21.8 runTarget loop, verbatim logic (scan order, pruning, bottom-up break).
template <class Missing>
static bool oldScan(const int b[6], float ex, float ey, float ez, float lim, bool bottomUp, Missing &&missing, P3 &T,
                    int *queries) {
  float best = 1e30f;
  bool found = false;
  for (int y = b[2]; y <= b[3]; ++y) {
    for (int x = b[0]; x <= b[1]; ++x)
      for (int z = b[4]; z <= b[5]; ++z) {
        const float ddx = x + 0.5f - ex, ddy = y + 0.5f - ey, ddz = z + 0.5f - ez;
        const float d2 = ddx * ddx + ddy * ddy + ddz * ddz;
        if (d2 > lim || d2 >= best) continue;
        ++*queries;
        if (!missing(x, y, z)) continue;
        best = d2;
        T = {x, y, z};
        found = true;
      }
    if (found && bottomUp) break;
  }
  return found;
}

static void testScan() {
  std::mt19937 rng(1234);
  int cases = 0, equal = 0, more = 0, bounded = 0;
  long oldQ = 0, newQ = 0;
  double worst = 0;
  for (int t = 0; t < 3000; ++t) {
    const int sx = 1 + int(rng() % 14), sy = 1 + int(rng() % 14), sz = 1 + int(rng() % 14);
    const int b[6] = {0, sx - 1, 0, sy - 1, 0, sz - 1};
    // eye: integer and half positions make many equal distances (tie rule is exercised)
    const float ex = float(int(rng() % (sx + 4)) - 2) + ((rng() & 1) ? 0.5f : 0.f);
    const float ey = float(int(rng() % (sy + 4)) - 2) + ((rng() & 1) ? 0.5f : 0.f);
    const float ez = float(int(rng() % (sz + 4)) - 2) + ((rng() & 1) ? 0.5f : 0.f);
    const float reach = 3.f + float(rng() % 5);
    const float lim = (reach - 0.5f) * (reach - 0.5f);
    const bool bottomUp = rng() & 1;
    const int k = 1 + int(rng() % 4);
    const int dens = int(rng() % 100);
    std::set<P3> miss;
    for (int x = 0; x < sx; ++x)
      for (int y = 0; y < sy; ++y)
        for (int z = 0; z < sz; ++z)
          if (int(rng() % 100) < dens) miss.insert({x, y, z});
    // old: k iterations, each a full rescan, each placement fills its own cell
    std::set<P3> m1 = miss;
    std::vector<P3> seqOld;
    int q1 = 0;
    for (int i = 0; i < k; ++i) {
      P3 T;
      if (!oldScan(b, ex, ey, ez, lim, bottomUp, [&](int x, int y, int z) { return m1.count({x, y, z}) > 0; }, T, &q1))
        break;
      seqOld.push_back(T);
      m1.erase(T);
    }
    // new: one pass, k best
    int q2 = 0;
    lm::epscan::Cell cells[lm::epscan::kMaxK];
    const int n = lm::epscan::nearest(b, ex, ey, ez, lim, bottomUp, k,
                                      [&](int x, int y, int z) {
                                        ++q2;
                                        return miss.count({x, y, z}) > 0;
                                      },
                                      cells);
    std::vector<P3> seqNew;
    for (int i = 0; i < n; ++i) seqNew.push_back({cells[i].x, cells[i].y, cells[i].z});
    ++cases;
    if (seqOld == seqNew) ++equal;
    else if (gFail < 5) std::printf("scan mismatch case %d k=%d bottomUp=%d\n", t, k, int(bottomUp));
    int inReach = 0;  // cells within the reach limit: the hard bound of one pass (each asked at most once)
    for (int x = 0; x < sx; ++x)
      for (int y = 0; y < sy; ++y)
        for (int z = 0; z < sz; ++z) {
          const float dx = x + 0.5f - ex, dy = y + 0.5f - ey, dz = z + 0.5f - ez;
          inReach += dx * dx + dy * dy + dz * dz <= lim;
        }
    if (q2 <= inReach) ++bounded;
    if (q2 > q1) {
      ++more;
      if (q1 > 0 && double(q2) / q1 > worst) worst = double(q2) / q1;
    }
    oldQ += q1;
    newQ += q2;
  }
  CHECK(equal == cases);
  CHECK(bounded == cases);  // one pass: every cell in reach asked at most once (old: up to k times)
  CHECK(newQ * 10 < oldQ * 7);  // overall at least 30% fewer predicate queries on this random mix
  std::printf("scan: %d/%d cases equal; predicate queries old %ld -> new %ld; new > old in %d cases (worst x%.2f)\n",
              equal, cases, oldQ, newQ, more, worst);
  // k = 1 is exactly the old single scan (same cell, never more queries)
  {
    const int b[6] = {0, 12, 0, 12, 0, 12};
    int q1 = 0, q2 = 0;
    P3 T;
    auto pred = [](int x, int y, int z) { return (x * 7 + y * 3 + z) % 11 == 0; };
    const bool f = oldScan(b, 6.5f, 6.5f, 6.5f, 36.f, false, pred, T, &q1);
    lm::epscan::Cell c[1];
    const int n = lm::epscan::nearest(b, 6.5f, 6.5f, 6.5f, 36.f, false, 1,
                                      [&](int x, int y, int z) { ++q2; return pred(x, y, z); }, c);
    CHECK(f && n == 1 && std::get<0>(T) == c[0].x && std::get<1>(T) == c[0].y && std::get<2>(T) == c[0].z);
    CHECK(q2 <= q1);
  }
  // degenerate inputs
  {
    const int b[6] = {0, 3, 0, 3, 0, 3};
    lm::epscan::Cell c[lm::epscan::kMaxK];
    CHECK(lm::epscan::nearest(b, 0, 0, 0, 100.f, false, 0, [](int, int, int) { return true; }, c) == 0);
    CHECK(lm::epscan::nearest(b, 0, 0, 0, 100.f, false, 99, [](int, int, int) { return true; }, c) == lm::epscan::kMaxK);
    CHECK(lm::epscan::nearest(b, 0, 0, 0, -1.f, false, 4, [](int, int, int) { return true; }, c) == 0);
  }
}

// ---- EpWorld -----------------------------------------------------------------------------------------
struct MockBackend {
  std::map<P3, uintptr_t> cells;     // mutable world
  std::map<P3, uintptr_t> expect;    // structure (0 = unresolved)
  std::set<uintptr_t> replaceableSet{0x1000};  // air
  int eCalls = 0, wCalls = 0, rCalls = 0;
  int expected(int x, int y, int z, uintptr_t *out) {
    ++eCalls;
    auto it = expect.find({x, y, z});
    if (it == expect.end()) { if (out) *out = 0; return 0; }
    if (out) *out = it->second;
    return 1;
  }
  uintptr_t world_(int x, int y, int z) {
    auto it = cells.find({x, y, z});
    return it == cells.end() ? 0x1000 : it->second;
  }
  uintptr_t world(int x, int y, int z) { ++wCalls; return world_(x, y, z); }
  int replaceableOf(uintptr_t b) { ++rCalls; return replaceableSet.count(b) ? 1 : 0; }
};

static void testWorld() {
  std::mt19937 rng(99);
  bool exact = true, freshAfterForget = true;
  for (int t = 0; t < 200; ++t) {
    MockBackend B;
    for (int i = 0; i < 300; ++i) {
      const P3 p{int(rng() % 12), int(rng() % 12), int(rng() % 12)};
      B.expect[p] = (rng() % 5 == 0) ? 0 : 0x2000 + 16 * (rng() % 20);
      if (rng() % 2) B.cells[p] = 0x2000 + 16 * (rng() % 20);
    }
    lm::epw::StepWorld<MockBackend> W(B);
    for (int op = 0; op < 4000; ++op) {
      const int x = int(rng() % 12), y = int(rng() % 12), z = int(rng() % 12);
      const int kind = int(rng() % 10);
      if (kind == 0) {  // world change (placement) followed by forget()
        B.cells[{x, y, z}] = 0x2000 + 16 * (rng() % 20);
        W.forget();
        uintptr_t b = 0;
        W.replaceable(x, y, z, &b);
        freshAfterForget = freshAfterForget && b == B.world_(x, y, z);
      } else if (kind < 5) {
        uintptr_t b = 0;
        const int r = W.replaceable(x, y, z, &b);
        const uintptr_t want = B.world_(x, y, z);
        exact = exact && b == want && r == (want ? (B.replaceableSet.count(want) ? 1 : 0) : -1);
      } else {
        uintptr_t e = 1;
        const int r = W.expected(x, y, z, &e);
        auto it = B.expect.find({x, y, z});
        exact = exact && r == (it != B.expect.end()) && e == (it != B.expect.end() ? it->second : 0);
      }
    }
  }
  CHECK(exact);
  CHECK(freshAfterForget);
  // memo really saves backend calls inside one step; unresolved (0) expected blocks are asked again
  {
    MockBackend B;
    B.expect[{1, 1, 1}] = 0x2010;
    B.expect[{2, 2, 2}] = 0;  // unresolved
    lm::epw::StepWorld<MockBackend> W(B);
    for (int i = 0; i < 10; ++i) {
      uintptr_t e;
      W.expected(1, 1, 1, &e);
      W.expected(2, 2, 2, &e);
      W.replaceable(1, 1, 1);
    }
    CHECK(B.eCalls == 1 + 10);  // resolved: once; unresolved: every time
    CHECK(B.wCalls == 1);
    CHECK(B.rCalls == 1);
    // the 1.21.8-style stale read is impossible after forget()
    B.cells[{1, 1, 1}] = 0x2020;
    W.forget();
    uintptr_t b = 0;
    W.replaceable(1, 1, 1, &b);
    CHECK(b == 0x2020 && B.wCalls == 2);
  }
  // bounded and allocation-free: fixed-size object (fits a game-thread stack frame comfortably)
  CHECK(sizeof(lm::epw::StepWorld<MockBackend>) < 20 * 1024);
}

// ---- SvCache -----------------------------------------------------------------------------------------
static void testSv() {
  lm::svc::Cache<256> C;  // small: many collisions
  std::mt19937 rng(5);
  std::map<std::pair<uintptr_t, uint64_t>, int64_t> truth;
  bool exact = true;
  for (int i = 0; i < 20000; ++i) {
    const uintptr_t b = 0x10000 + 16 * (rng() % 400);
    char key[16];
    std::snprintf(key, sizeof(key), "k%u", unsigned(rng() % 12));
    const uint64_t kh = lm::svc::keyHash(key, std::strlen(key));
    const int64_t v = int64_t((b >> 4) * 31 + kh % 7) % 16 - 1;  // property of (block, key); includes -1
    truth[{b, kh}] = v;
    int64_t got = 0;
    if (C.get(b, kh, 1, &got)) exact = exact && got == v;
    else C.put(b, kh, 1, v);
  }
  CHECK(exact);
  const auto st = C.stats();
  CHECK(st.hits > 0 && st.hits < st.lookups);
  // epoch change drops everything (a new world may reuse Block* addresses)
  {
    lm::svc::Cache<64> E;
    int64_t v = 0;
    E.put(0x10010, 7, 1, 3);
    CHECK(E.get(0x10010, 7, 1, &v) && v == 3);
    CHECK(!E.get(0x10010, 7, 2, &v));
    E.put(0x10010, 7, 2, 4);
    CHECK(E.get(0x10010, 7, 2, &v) && v == 4);
  }
  // distinct keys/lengths hash apart
  CHECK(lm::svc::keyHash("facing_direction", 16) != lm::svc::keyHash("facing_directio", 15));
  CHECK(lm::svc::keyHash("ab", 2) != lm::svc::keyHash("ba", 2));
  // thread safety smoke: two threads (render + game) hammering, answers stay exact
  {
    lm::svc::Cache<128> M;
    std::atomic<bool> bad{false};
    auto run = [&](int seed) {
      std::mt19937 r(seed);
      for (int i = 0; i < 50000; ++i) {
        const uintptr_t b = 0x10000 + 16 * (r() % 300);
        const uint64_t kh = r() % 9;
        const int64_t v = int64_t(b % 13 + kh);
        int64_t g = 0;
        if (M.get(b, kh, 1, &g)) { if (g != v) bad = true; }
        else M.put(b, kh, 1, v);
      }
    };
    std::thread a(run, 1), c(run, 2);
    a.join();
    c.join();
    CHECK(!bad.load());
  }
}

// ---- LineRing ----------------------------------------------------------------------------------------
static void testRing() {
  lm::ring::LineRing<4, 16> R;
  R.push("a", 1);
  R.push("bb", 2);
  std::string out;
  CHECK(R.drain(out) == 0 && out == "a\nbb\n");
  out.clear();
  for (int i = 0; i < 7; ++i) {
    char s[16];
    std::snprintf(s, sizeof(s), "%d", i);
    R.push(s, std::strlen(s));
  }
  CHECK(R.drain(out) == 3 && out == "3\n4\n5\n6\n");  // oldest 3 dropped, counted
  out.clear();
  CHECK(R.drain(out) == 0 && out.empty());
  R.push("0123456789abcdefXYZ", 19);  // truncated to L-1
  CHECK(R.drain(out) == 0 && out == "0123456789abcde\n");
  // producer/consumer smoke: nothing lost except counted drops
  {
    lm::ring::LineRing<64, 32> Q;
    std::atomic<bool> done{false};
    uint64_t got = 0, dropped = 0;
    std::thread prod([&] {
      for (int i = 0; i < 100000; ++i) Q.push("line", 4);
      done = true;
    });
    std::string buf;
    while (!done.load()) {
      buf.clear();
      dropped += Q.drain(buf);
      for (char ch : buf) got += ch == '\n';
    }
    prod.join();
    buf.clear();
    dropped += Q.drain(buf);
    for (char ch : buf) got += ch == '\n';
    CHECK(got + dropped == 100000);
  }
}

int main() {
  testScan();
  testWorld();
  testSv();
  testRing();
  std::printf("ep: %d passed, %d failed\n", gOk, gFail);
  return gFail ? 1 : 0;
}
