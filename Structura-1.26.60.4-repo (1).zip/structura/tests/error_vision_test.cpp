// Host test for ErrorVision.hpp (Error Vision: confirmed incorrect blocks through walls).
// Pure logic only: verdict rules, bounded store, incremental sweep, transformed coordinates, projection.
#include <cmath>
#include <cstdio>
#include <map>
#include <random>
#include <set>
#include <string>
#include <tuple>
#include <vector>

#include "ErrorVision.hpp"
#include "Structure.hpp"

using namespace lm;
static int gFail = 0, gOk = 0;
#define CHECK(c)                                                              \
  do {                                                                        \
    if (c) ++gOk;                                                             \
    else { ++gFail; std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); } \
  } while (0)

static ev::Facts wrongFacts(uint8_t cmp, std::string_view name) {
  ev::Facts f;
  f.cmp = cmp;
  f.expectedKnown = true;
  f.worldRead = true;
  f.namesReady = true;
  f.nameKnown = true;
  f.worldName = name;
  f.statesExact = true;
  return f;
}

static void testVerdict() {
  using ev::Verdict;
  // correct, missing, air ok, unknown comparison -> never highlighted
  for (uint8_t c : {ev::kCmpCorrect, ev::kCmpMissing, ev::kCmpAirOk, ev::kCmpUnknown})
    CHECK(ev::judge(wrongFacts(c, "stone")) == Verdict::None);
  // incorrect block that exists
  CHECK(ev::judge(wrongFacts(ev::kCmpWrong, "dirt")) == Verdict::Incorrect);
  CHECK(ev::judge(wrongFacts(ev::kCmpWrong, "minecraft:dirt")) == Verdict::Incorrect);
  // block where the structure expects air (Extra) or nothing (void): not highlighted
  {
    auto f = wrongFacts(ev::kCmpExtra, "dirt");
    f.expectedAir = true;
    CHECK(ev::judge(f) == Verdict::None);
    auto g = wrongFacts(ev::kCmpWrong, "dirt");
    g.expectedVoid = true;
    CHECK(ev::judge(g) == Verdict::None);
    auto h = wrongFacts(ev::kCmpWrong, "dirt");
    h.expectedAir = true;
    CHECK(ev::judge(h) == Verdict::None);
  }
  // unknown / unreadable data -> Unknown, never Incorrect
  {
    auto a = wrongFacts(ev::kCmpWrong, "dirt");
    a.worldRead = false;
    CHECK(ev::judge(a) == Verdict::Unknown);
    auto b = wrongFacts(ev::kCmpWrong, "dirt");
    b.nameKnown = false;  // compareOne reports Wrong for an unnamed block: Error Vision does not trust it
    CHECK(ev::judge(b) == Verdict::Unknown);
    auto c = wrongFacts(ev::kCmpWrong, "dirt");
    c.namesReady = false;
    CHECK(ev::judge(c) == Verdict::Unknown);
    auto d = wrongFacts(ev::kCmpWrong, "dirt");
    d.expectedKnown = false;  // expected name not a game block (unmapped)
    CHECK(ev::judge(d) == Verdict::Unknown);
  }
  // block states: only when every expected state was applied reliably
  {
    auto a = wrongFacts(ev::kCmpWrongState, "oak_stairs");
    CHECK(ev::judge(a) == Verdict::Incorrect);
    a.statesExact = false;
    CHECK(ev::judge(a) == Verdict::Unknown);
  }
  // fluids and air-like world blocks are "missing", not incorrect
  for (const char *n : {"water", "flowing_water", "lava", "flowing_lava", "air", "structure_void", "light_block_7",
                        "bubble_column"})
    CHECK(ev::judge(wrongFacts(ev::kCmpWrong, n)) == Verdict::None);
  CHECK(!ev::nonPhysical("waterlily") && !ev::nonPhysical("stone") && !ev::nonPhysical("lava_cauldron"));
  CHECK(ev::stillIncorrect(ev::kCmpWrong) && ev::stillIncorrect(ev::kCmpWrongState));
  CHECK(!ev::stillIncorrect(ev::kCmpCorrect) && !ev::stillIncorrect(ev::kCmpMissing) && !ev::stillIncorrect(ev::kCmpExtra));
}

static void testStore() {
  ev::Store s;
  s.bind(&s, 1);
  CHECK(s.size() == 0);
  s.note(5, ev::Verdict::Incorrect);
  s.note(5, ev::Verdict::Incorrect);
  CHECK(s.size() == 1 && s.contains(5));
  s.note(5, ev::Verdict::Unknown);  // unreadable recheck keeps the confirmed result
  CHECK(s.contains(5));
  s.note(5, ev::Verdict::None);  // fixed -> removed
  CHECK(!s.contains(5) && s.size() == 0);
  // invalidation: new owner / generation clears, same keeps
  s.note(7, ev::Verdict::Incorrect);
  CHECK(!s.bind(&s, 1) && s.contains(7));
  CHECK(s.bind(&s, 2) && !s.contains(7) && s.size() == 0);
  int other = 0;
  s.note(9, ev::Verdict::Incorrect);
  CHECK(s.bind(&other, 2) && s.size() == 0);
  // randomized against std::set, including collisions and wrap-around (backward-shift deletion)
  std::mt19937 rng(1234);
  std::set<uint32_t> model;
  s.clear();
  bool exact = true;
  for (int i = 0; i < 300000; ++i) {
    const uint32_t k = rng() % 6000;
    const int op = int(rng() % 3);
    if (op == 0) {
      const bool ok = s.add(k);
      if (ok) model.insert(k);
      else if (model.size() < ev::Store::kMax) exact = false;
    } else if (op == 1) {
      s.erase(k);
      model.erase(k);
    } else {
      if (s.contains(k) != (model.count(k) != 0)) exact = false;
    }
    if (s.size() != model.size()) exact = false;
  }
  CHECK(exact);
  size_t seen = 0;
  bool allIn = true;
  s.forEach([&](uint32_t li) { ++seen; allIn = allIn && model.count(li); });
  CHECK(seen == model.size() && allIn);
  // bounded: never more than kMax entries, `full` reported, frees space when entries go away
  s.clear();
  for (uint32_t k = 0; k < 3 * ev::Store::kMax; ++k) s.add(k * 7919u);
  CHECK(s.size() == ev::Store::kMax && s.full());
  s.erase(0);
  CHECK(!s.full() && s.add(123456789u) && s.size() == ev::Store::kMax);
  // bounded under churn: 10^5 notes never exceed kMax entries
  ev::Store t;
  t.bind(&t, 1);
  for (uint32_t k = 0; k < 100000; ++k) t.note(k, (k % 3) ? ev::Verdict::Incorrect : ev::Verdict::None);
  CHECK(t.size() <= ev::Store::kMax);
}

static void testSweep() {
  for (size_t vol : {size_t(1), size_t(7), size_t(1248), size_t(10000), size_t(99991)})
    for (size_t budget : {size_t(1), size_t(560), size_t(3000)}) {
      ev::Sweep sw;
      std::vector<int> hits(vol, 0);
      const size_t calls = (vol + budget - 1) / budget;
      bool bounded = true, noDup = true;
      for (size_t c = 0; c < calls; ++c) {
        std::set<size_t> thisCall;
        const size_t n = sw.step(vol, budget, [&](size_t k) {
          ++hits[k];
          if (!thisCall.insert(k).second) noDup = false;
        });
        if (n != std::min(budget, vol)) bounded = false;
      }
      bool covered = true;
      for (int h : hits) covered = covered && h >= 1;
      CHECK(bounded && noDup && covered);
    }
  ev::Sweep z;
  CHECK(z.step(0, 100, [](size_t) {}) == 0);
}

// End-to-end model of the comparison feeding Error Vision, for every rotation and mirror:
// world positions are derived through localToWorld, compared through worldToLocal, stored by local index
// and drawn back through localOf + localToWorld - exactly the Hologram.cpp path.
enum Cat { Correct, Wrong, Missing, Fluid, Unreadable, WrongState, StateUnreliable };
static void testTransformed() {
  Structure S;
  S.sx = 5; S.sy = 3; S.sz = 4;
  S.palette = {{"air", "", 0, true, 0}, {"stone", "", 0, false, 0}, {"oak_planks", "", 0, false, 0},
               {"glass", "", 0, false, 0}, {"oak_stairs", "", 0, false, 0}};
  S.idx.resize(S.volume());
  std::mt19937 rng(42);
  for (auto &p : S.idx) {
    const int r = int(rng() % 10);
    p = r == 0 ? kVoid : r <= 2 ? uint16_t(0) : uint16_t(1 + rng() % 4);
  }
  for (int rot = 0; rot < 4; ++rot)
    for (int mir = 0; mir < 2; ++mir) {
      Placement P{100, 64, -50, rot, mir != 0};
      std::map<std::tuple<int, int, int>, std::pair<Cat, bool>> world;  // pos -> (category, expected air)
      std::set<std::tuple<int, int, int>> expectHighlight;
      for (int x = 0; x < S.sx; ++x)
        for (int y = 0; y < S.sy; ++y)
          for (int z = 0; z < S.sz; ++z) {
            const uint16_t p = S.idx[S.index(x, y, z)];
            int wx, wy, wz;
            localToWorld(S, P, x, y, z, wx, wy, wz);
            int bx, by, bz;
            CHECK(worldToLocal(S, P, wx, wy, wz, bx, by, bz) && bx == x && by == y && bz == z);
            if (p == kVoid) continue;
            const Cat c = Cat(rng() % 7);
            world[{wx, wy, wz}] = {c, S.palette[p].air};
            const bool exp = !S.palette[p].air && (c == Wrong || c == WrongState);
            if (exp) expectHighlight.insert({wx, wy, wz});
          }
      // comparison: bounded sweeps over the rotated world box (several frames)
      int dx, dz;
      rotatedSize(S, P.rot, dx, dz);
      const size_t vol = size_t(dx) * S.sy * dz;
      ev::Store store;
      store.bind(&store, uint64_t(rot * 2 + mir + 1));
      ev::Sweep sw;
      for (int frame = 0; frame * 7 < int(vol) + 7; ++frame) {
        sw.step(vol, 7, [&](size_t k) {
          const int wx = P.ox + int(k / (size_t(S.sy) * dz)), wy = P.oy + int((k / dz) % S.sy), wz = P.oz + int(k % dz);
          int lx, ly, lz;
          if (!worldToLocal(S, P, wx, wy, wz, lx, ly, lz)) return;
          const size_t li = S.index(lx, ly, lz);
          const uint16_t p = S.idx[li];
          if (p == kVoid) return;
          const auto it = world.find({wx, wy, wz});
          if (it == world.end()) return;
          const Cat c = it->second.first;
          const bool expAir = S.palette[p].air;
          // compareOne semantics (Hologram.cpp): world air -> Missing; expected air -> AirOk / Extra;
          // unnamed block -> Wrong; same type with a compared state difference -> WrongState
          uint8_t cmp;
          if (c == Missing) cmp = expAir ? ev::kCmpAirOk : ev::kCmpMissing;
          else if (expAir) cmp = ev::kCmpExtra;
          else if (c == Correct) cmp = ev::kCmpCorrect;
          else if (c == WrongState || c == StateUnreliable) cmp = ev::kCmpWrongState;
          else cmp = ev::kCmpWrong;  // Wrong, Fluid (different name), Unreadable (no name)
          ev::Facts f;
          f.cmp = cmp;
          f.expectedAir = expAir;
          f.expectedKnown = true;
          f.worldRead = c != Missing;
          f.namesReady = true;
          f.nameKnown = c != Unreadable;
          f.worldName = c == Fluid ? "water" : "dirt";
          f.statesExact = c != StateUnreliable;
          store.note(uint32_t(li), ev::judge(f));
        });
      }
      std::set<std::tuple<int, int, int>> got;
      store.forEach([&](uint32_t li) {
        int x, y, z, wx, wy, wz;
        ev::localOf(li, S.sy, S.sz, x, y, z);
        localToWorld(S, P, x, y, z, wx, wy, wz);
        got.insert({wx, wy, wz});
      });
      CHECK(got == expectHighlight);
      // missing / empty / fluid / unreadable / extra positions never highlighted
      bool clean = true;
      for (const auto &kv : world) {
        const Cat c = kv.second.first;
        const bool air = kv.second.second;
        if ((air || c == Missing || c == Fluid || c == Unreadable || c == Correct || c == StateUnreliable) &&
            got.count(kv.first))
          clean = false;
      }
      CHECK(clean);
      // cache invalidation: fix every wrong block in the world, one recheck sweep empties the store
      for (auto &kv : world)
        if (kv.second.first == Wrong || kv.second.first == WrongState) kv.second.first = Correct;
      for (const auto &kv : world) {
        int lx, ly, lz;
        worldToLocal(S, P, std::get<0>(kv.first), std::get<1>(kv.first), std::get<2>(kv.first), lx, ly, lz);
        const size_t li = S.index(lx, ly, lz);
        ev::Facts f = wrongFacts(kv.second.second ? ev::kCmpAirOk : ev::kCmpCorrect, "stone");
        f.expectedAir = kv.second.second;
        if (kv.second.first == Correct) store.note(uint32_t(li), ev::judge(f));
      }
      CHECK(store.size() == 0);
    }
}

static void testGeometry() {
  std::mt19937 rng(7);
  std::uniform_real_distribution<float> u(-60.f, 60.f);
  bool ok = true;
  for (int i = 0; i < 20000; ++i) {
    const ev::V3 q{u(rng), u(rng), u(rng)};
    const float d = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z);
    const ev::V3 p = ev::projectToward(q);
    const float dp = std::sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
    if (d > ev::kEyeRadius) {
      // same view ray (same pixel): parallel, same direction, distance r
      const float cx = q.y * p.z - q.z * p.y, cy = q.z * p.x - q.x * p.z, cz = q.x * p.y - q.y * p.x;
      if (std::fabs(cx) + std::fabs(cy) + std::fabs(cz) > 1e-3f * d) ok = false;
      if (q.x * p.x + q.y * p.y + q.z * p.z <= 0) ok = false;
      if (std::fabs(dp - ev::kEyeRadius) > 1e-4f) ok = false;
      if (q.z > 0.5f && (std::fabs(q.x / q.z - p.x / p.z) > 1e-3f || std::fabs(q.y / q.z - p.y / p.z) > 1e-3f)) ok = false;
    }
  }
  CHECK(ok);
  std::vector<ev::Line> lines;
  std::vector<ev::Quad> quads;
  auto L = [&](const ev::Line &l) { lines.push_back(l); };
  auto Q = [&](const ev::Quad &q) { quads.push_back(q); };
  // far block: 12 edges, at most 3 faces, everything at the eye radius
  CHECK(ev::emitBox({10, 2, 5}, {11, 3, 6}, true, L, Q));
  CHECK(lines.size() == 12 && quads.size() >= 1 && quads.size() <= 3);
  bool onSphere = true;
  for (auto &l : lines)
    for (const ev::V3 &v : {l.a, l.b})
      onSphere = onSphere && std::fabs(std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z) - ev::kEyeRadius) < 1e-4f;
  CHECK(onSphere);
  // above-and-beside block: exactly the 3 faces turned to the eye (+x side, top, -z side)
  quads.clear(); lines.clear();
  ev::emitBox({-5, -9, 3}, {-4, -8, 4}, true, L, Q);
  CHECK(quads.size() == 3);
  // near block: subdivided edges/faces
  lines.clear(); quads.clear();
  CHECK(ev::emitBox({0.4f, -1.f, -0.5f}, {1.4f, 0.f, 0.5f}, true, L, Q));
  CHECK(lines.size() == 12 * 8 && quads.size() % 16 == 0 && !quads.empty());
  bool chordsFine = true;  // projected chords stay well away from the eye (no near-plane clipping)
  for (auto &l : lines) {
    const ev::V3 m{(l.a.x + l.b.x) / 2, (l.a.y + l.b.y) / 2, (l.a.z + l.b.z) / 2};
    if (std::sqrt(m.x * m.x + m.y * m.y + m.z * m.z) < 0.8f * ev::kEyeRadius) chordsFine = false;
  }
  CHECK(chordsFine);
  // eye inside the box: nothing
  lines.clear(); quads.clear();
  CHECK(!ev::emitBox({-0.5f, -0.5f, -0.5f}, {0.5f, 0.5f, 0.5f}, true, L, Q) && lines.empty() && quads.empty());
  // lines only
  CHECK(ev::emitBox({3, 0, 0}, {4, 1, 1}, false, L, Q) && quads.empty() && lines.size() == 12);
}

int main() {
  testVerdict();
  testStore();
  testSweep();
  testTransformed();
  testGeometry();
  std::printf("error_vision: %d passed, %d failed\n", gOk, gFail);
  return gFail ? 1 : 0;
}
