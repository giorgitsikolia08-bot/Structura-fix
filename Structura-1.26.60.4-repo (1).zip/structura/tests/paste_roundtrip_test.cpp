// Paste Schematic round trip with the real loader and the real transformed-state table:
//   .mcstructure -> loadStructure -> xf::get(rot, mirror) -> paste::Encoder -> file -> loadStructure
// The re-loaded file (placed unturned at the min corner, as the /structure load command does) must hold,
// at every world position, the original variant's name + the table's transformed states + its version.
#include <cstdio>
#include <fstream>
#include <map>
#include <string>
#include <vector>

#include "Nbt.hpp"
#include "Paste.hpp"
#include "Structure.hpp"
#include "Transformed.hpp"

using namespace lm;
static int gFail = 0, gOk = 0;
#define CHECK(c)                                                              \
  do {                                                                        \
    if (c) ++gOk;                                                             \
    else { ++gFail; std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); } \
  } while (0)

// 3x2x2: stairs (weirdo_direction), chest (cardinal), legacy stone (old version), torch, air, void
static std::string writeSource(const std::string &path) {
  nbt::Writer w;
  const int sx = 3, sy = 2, sz = 2, vol = sx * sy * sz;
  const int32_t idx[vol] = {0, 1, 2, 3, 4, -1, 0, 4, 1, 2, 3, 0};
  w.beginCompound("");
  w.putInt("format_version", 1);
  w.beginList("size", nbt::Int, 3);
  w.listInt(sx); w.listInt(sy); w.listInt(sz);
  w.beginCompound("structure");
  w.beginList("block_indices", nbt::List, 2);
  w.listListBegin(nbt::Int, vol);
  for (int32_t v : idx) w.listInt(v);
  w.listListBegin(nbt::Int, vol);
  for (int k = 0; k < vol; ++k) w.listInt(k == 1 ? 5 : -1);  // the chest cell is waterlogged
  w.beginList("entities", nbt::Compound, 0);
  w.beginCompound("palette");
  w.beginCompound("default");
  w.beginList("block_palette", nbt::Compound, 6);
  w.putString("name", "minecraft:oak_stairs");
  w.beginCompound("states");
  w.putInt("weirdo_direction", 2);
  w.putByte("upside_down_bit", 0);
  w.endCompound();
  w.putInt("version", 18100737);
  w.listCompoundEnd();
  w.putString("name", "minecraft:chest");
  w.beginCompound("states");
  w.putString("minecraft:cardinal_direction", "north");
  w.endCompound();
  w.putInt("version", 18168865);
  w.listCompoundEnd();
  w.putString("name", "minecraft:stone");  // legacy palette entry: the game's upgrader needs its version
  w.beginCompound("states");
  w.putString("stone_type", "granite");
  w.endCompound();
  w.putInt("version", 17694723);
  w.listCompoundEnd();
  w.putString("name", "minecraft:torch");
  w.beginCompound("states");
  w.putString("torch_facing_direction", "east");
  w.endCompound();
  w.putInt("version", 18168865);
  w.listCompoundEnd();
  w.putString("name", "minecraft:air");
  w.beginCompound("states");
  w.endCompound();
  w.putInt("version", 18168865);
  w.listCompoundEnd();
  w.putString("name", "minecraft:water");
  w.beginCompound("states");
  w.putInt("liquid_depth", 0);
  w.endCompound();
  w.putInt("version", 18168865);
  w.listCompoundEnd();
  w.beginCompound("block_position_data");
  w.endCompound();
  w.endCompound();
  w.endCompound();
  w.endCompound();
  w.beginList("structure_world_origin", nbt::Int, 3);
  w.listInt(0); w.listInt(0); w.listInt(0);
  w.endCompound();
  std::ofstream f(path, std::ios::binary | std::ios::trunc);
  f.write(reinterpret_cast<const char *>(w.out.data()), std::streamsize(w.out.size()));
  return path;
}

static std::map<std::string, std::string> plain(const std::vector<BlockStateValue> &st) {
  std::map<std::string, std::string> m;
  for (const auto &sv : st) {
    if (sv.type == nbt::Byte || sv.type == nbt::Int) m[sv.key] = std::to_string(sv.i);
    else if (sv.type == nbt::String) m[sv.key] = sv.s;
  }
  return m;
}

int main() {
  auto S = std::make_shared<Structure>();
  std::string err;
  CHECK(loadStructure(writeSource("/tmp/structura_paste_src.mcstructure"), *S, err));
  CHECK(S->vidx.size() == S->volume());
  bool versions = false;
  for (const auto &v : S->variants) versions = versions || v.version == 17694723;
  CHECK(versions);  // loader keeps the palette version now
  std::shared_ptr<const Structure> SC = S;
  for (int rot = 0; rot < 4; ++rot)
    for (int m = 0; m < 2; ++m)
      for (int mode = 0; mode < 2; ++mode) {
        const Placement P{100, 5, -7, rot, m != 0};
        const auto X = xf::get(SC, rot, m != 0);
        CHECK(X != nullptr);
        if (!X) continue;
        paste::Encoder enc;
        CHECK(enc.begin(SC, P, paste::Mode(mode), &X->states, &X->unsupported, err));
        CHECK(paste::runEncode(enc, 4, [] { return false; }, [] { return false; }, [](float) {}) ==
              paste::Outcome::Done);
        const std::string out = "/tmp/structura_paste_out.mcstructure";
        {
          std::ofstream f(out, std::ios::binary | std::ios::trunc);
          f.write(reinterpret_cast<const char *>(enc.bytes().data()), std::streamsize(enc.bytes().size()));
        }
        Structure R;
        CHECK(loadStructure(out, R, err));
        int dx, dz;
        rotatedSize(*S, rot, dx, dz);
        CHECK(R.sx == dx && R.sy == S->sy && R.sz == dz);
        const Placement P0{P.ox, P.oy, P.oz, 0, false};  // how the game loads it: unturned, min corner
        bool ok = true;
        for (int x = 0; x < S->sx; ++x)
          for (int y = 0; y < S->sy; ++y)
            for (int z = 0; z < S->sz; ++z) {
              int wx, wy, wz;
              localToWorld(*S, P, x, y, z, wx, wy, wz);
              int rx, ry, rz;
              if (!worldToLocal(R, P0, wx, wy, wz, rx, ry, rz)) { ok = false; continue; }
              const size_t li = S->index(x, y, z), ri = R.index(rx, ry, rz);
              const uint16_t p = S->idx[li];
              if (p == kVoid || (S->palette[p].air && mode == 1)) {  // kept world block
                ok = ok && R.idx[ri] == kVoid;
                continue;
              }
              if (S->palette[p].air) { ok = ok && R.idx[ri] != kVoid && R.palette[R.idx[ri]].air; continue; }
              const uint16_t v = S->vidx[li], rv = R.vidx[ri];
              if (rv == kVoid || rv >= R.variants.size()) { ok = false; continue; }
              ok = ok && R.variants[rv].fullName == S->variants[v].fullName &&
                   plain(R.variants[rv].states) == plain(X->states[v]) &&
                   R.variants[rv].version == S->variants[v].version && R.waterAt(ri) == S->waterAt(li);
            }
        CHECK(ok);
        CHECK(enc.stats.inexact == 0);  // every state of this file has a transform rule
      }
  std::printf("paste roundtrip: %d passed, %d failed\n", gOk, gFail);
  return gFail ? 1 : 0;
}
