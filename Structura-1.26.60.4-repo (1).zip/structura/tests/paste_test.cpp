// Host test for Paste.hpp (Creative "Paste Schematic", export side).
// Decodes the produced .mcstructure with the project's own NBT parser and checks every cell against the
// schematic through an independent path (localToWorld), for all 4 rotations x mirror and both modes.
// Also: validation, bounded incremental work, cancellation/staleness, pack files, ids, command text.
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#include "Nbt.hpp"
#include "Paste.hpp"
#include "Structure.hpp"

using namespace lm;
static int gFail = 0, gOk = 0;
#define CHECK(c)                                                              \
  do {                                                                        \
    if (c) ++gOk;                                                             \
    else { ++gFail; std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); } \
  } while (0)

// 0 air, 1 stone, 2 oak_stairs, 3 glass; structure_void cells are kVoid
static std::shared_ptr<Structure> makeStructure(unsigned seed, bool withVariants = true) {
  auto S = std::make_shared<Structure>();
  S->title = "Test House #1";
  S->sx = 3; S->sy = 2; S->sz = 4;
  S->palette = {{"air", "", 0, true, 0}, {"stone", "", 0, false, 0}, {"oak_stairs", "", 0, false, 0},
                {"glass", "", 0, false, 0}};
  // variants: v0 air, v1 stone (versioned), v2/v3 stairs with different directions, v4 glass (no version)
  S->variants.resize(5);
  S->variants[0] = {0, "minecraft:air", {}, 0};
  S->variants[1] = {1, "minecraft:stone", {}, 17959425};
  S->variants[2] = {2, "minecraft:oak_stairs", {{"weirdo_direction", 3, 0, ""}, {"upside_down_bit", 1, 0, ""}}, 18100737};
  S->variants[3] = {2, "minecraft:oak_stairs", {{"weirdo_direction", 3, 1, ""}, {"upside_down_bit", 1, 1, ""}}, 18100737};
  S->variants[4] = {3, "minecraft:glass", {{"note", 8, 0, "x"}, {"rawf", 5, 0, "1.5"}}, 0};
  std::mt19937 rng(seed);
  const size_t vol = S->volume();
  S->idx.resize(vol);
  S->vidx.resize(vol);
  for (size_t i = 0; i < vol; ++i) {
    const unsigned r = rng() % 6;
    if (r == 5) { S->idx[i] = kVoid; S->vidx[i] = kVoid; continue; }
    const uint16_t v = uint16_t(r == 0 ? 0 : r == 1 ? 1 : r == 2 ? 2 : r == 3 ? 3 : 4);
    S->vidx[i] = v;
    S->idx[i] = S->variants[v].palette;
  }
  // a few waterlogged cells (some on air/void to prove they are never written there)
  for (size_t i = 0; i < vol; i += 5) S->water.push_back(uint32_t(i));
  if (!withVariants) { S->vidx.clear(); S->variants.clear(); }
  return S;
}

// "Transformed" states table: a marker value per (variant, rot, mirror) proves the table entry is used.
static paste::Encoder::States fakeTable(const Structure &S, int rot, bool mirror) {
  paste::Encoder::States t(S.variants.size());
  for (size_t v = 0; v < S.variants.size(); ++v) {
    t[v] = S.variants[v].states;
    t[v].push_back({"marker", 3, int32_t(v * 1000 + rot * 10 + (mirror ? 1 : 0)), ""});
  }
  return t;
}

struct Decoded {
  int sx = 0, sy = 0, sz = 0;
  std::vector<int64_t> l1, l2;
  struct E {
    std::string name;
    std::map<std::string, std::string> st;
    int64_t version = 0;
  };
  std::vector<E> pal;
  int ox = 0, oy = 0, oz = 0;
  bool ok = false;
};

static Decoded decode(const std::vector<uint8_t> &b) {
  Decoded d;
  nbt::Tag root;
  std::string err;
  if (!nbt::parse(b.data(), b.size(), root, err)) { std::printf("parse: %s\n", err.c_str()); return d; }
  const nbt::Tag *size = root.get("size");
  const nbt::Tag *st = root.get("structure");
  const nbt::Tag *org = root.get("structure_world_origin");
  if (!size || !st || !org || size->nums.size() != 3 || org->nums.size() != 3) return d;
  d.sx = int(size->nums[0]); d.sy = int(size->nums[1]); d.sz = int(size->nums[2]);
  d.ox = int(org->nums[0]); d.oy = int(org->nums[1]); d.oz = int(org->nums[2]);
  const nbt::Tag *bi = st->get("block_indices");
  if (!bi || bi->items.size() != 2) return d;
  d.l1 = bi->items[0].nums;
  d.l2 = bi->items[1].nums;
  const nbt::Tag *pal = st->get("palette");
  const nbt::Tag *def = pal ? pal->get("default") : nullptr;
  const nbt::Tag *bp = def ? def->get("block_palette") : nullptr;
  if (!bp || !def->get("block_position_data") || !st->get("entities")) return d;
  for (const auto &e : bp->items) {
    Decoded::E x;
    if (const nbt::Tag *n = e.get("name")) x.name = n->s;
    if (const nbt::Tag *v = e.get("version")) x.version = v->i;
    if (const nbt::Tag *ss = e.get("states"))
      for (const auto &f : ss->fields)
        x.st[f.first] = f.second.type == nbt::String ? "s:" + f.second.s
                                                    : std::string(f.second.type == nbt::Byte ? "b:" : "i:") +
                                                          std::to_string(f.second.i);
    d.pal.push_back(std::move(x));
  }
  d.ok = true;
  return d;
}

static std::map<std::string, std::string> expectStates(const std::vector<BlockStateValue> &st, size_t *raw) {
  std::map<std::string, std::string> m;
  for (const auto &sv : st) {
    if (sv.type == nbt::Byte) m[sv.key] = "b:" + std::to_string(sv.i);
    else if (sv.type == nbt::Int) m[sv.key] = "i:" + std::to_string(sv.i);
    else if (sv.type == nbt::String) m[sv.key] = "s:" + sv.s;
    else if (raw) ++*raw;
  }
  return m;
}

static void testTransforms() {
  for (unsigned seed = 1; seed <= 6; ++seed) {
    auto S = makeStructure(seed);
    for (int rot = 0; rot < 4; ++rot)
      for (int mir = 0; mir < 2; ++mir)
        for (int mode = 0; mode < 2; ++mode) {
          const Placement P{-5, -60, 7, rot, mir != 0};
          const auto table = fakeTable(*S, rot, mir != 0);
          paste::Encoder enc;
          std::string err;
          CHECK(enc.begin(S, P, paste::Mode(mode), &table, nullptr, err));
          // bounded incremental work: 7 cells per call, progress never goes backwards
          int steps = 0;
          float last = -1.f;
          bool mono = true;
          while (!enc.step(7)) {
            ++steps;
            mono = mono && enc.progress() >= last;
            last = enc.progress();
            if (steps > 100000) break;
          }
          CHECK(mono);
          CHECK(steps >= int(S->volume() / 7) - 1);
          const Decoded d = decode(enc.bytes());
          CHECK(d.ok);
          int dx, dz;
          rotatedSize(*S, rot, dx, dz);
          CHECK(d.sx == dx && d.sy == S->sy && d.sz == dz);
          CHECK(d.ox == P.ox && d.oy == P.oy && d.oz == P.oz);
          CHECK(d.l1.size() == S->volume() && d.l2.size() == S->volume());
          bool cellsOk = true, airInPalette = false;
          for (const auto &e : d.pal) airInPalette = airInPalette || e.name == "minecraft:air";
          if (mode == 1) CHECK(!airInPalette);  // Non-Air Only never writes air
          size_t visited = 0;
          // independent path: schematic cell -> world (localToWorld) -> output cell
          for (int x = 0; x < S->sx; ++x)
            for (int y = 0; y < S->sy; ++y)
              for (int z = 0; z < S->sz; ++z) {
                int wx, wy, wz;
                localToWorld(*S, P, x, y, z, wx, wy, wz);
                const int X = wx - P.ox, Y = wy - P.oy, Z = wz - P.oz;
                if (X < 0 || Y < 0 || Z < 0 || X >= dx || Y >= S->sy || Z >= dz) { cellsOk = false; continue; }
                const size_t o = (size_t(X) * S->sy + Y) * dz + Z;
                const size_t li = S->index(x, y, z);
                ++visited;
                const int64_t a = d.l1[o], w = d.l2[o];
                const uint16_t p = S->idx[li];
                if (p == kVoid) { cellsOk = cellsOk && a == -1 && w == -1; continue; }
                if (S->palette[p].air) {
                  if (mode == 1) cellsOk = cellsOk && a == -1 && w == -1;
                  else cellsOk = cellsOk && a >= 0 && size_t(a) < d.pal.size() && d.pal[a].name == "minecraft:air";
                  if (mode == 0 && S->waterAt(li))
                    cellsOk = cellsOk && w >= 0 && d.pal[size_t(w)].name == "minecraft:water";
                  continue;
                }
                const uint16_t v = S->vidx[li];
                if (a < 0 || size_t(a) >= d.pal.size()) { cellsOk = false; continue; }
                const auto &e = d.pal[size_t(a)];
                const auto want = expectStates(table[v], nullptr);
                cellsOk = cellsOk && e.name == S->variants[v].fullName && e.st == want &&
                          e.version == (S->variants[v].version ? S->variants[v].version : paste::kDefaultVersion);
                if (S->waterAt(li))
                  cellsOk = cellsOk && w >= 0 && d.pal[size_t(w)].name == "minecraft:water" &&
                            d.pal[size_t(w)].st.count("liquid_depth") == 1;
                else
                  cellsOk = cellsOk && w == -1;
              }
          CHECK(cellsOk);
          CHECK(visited == S->volume());
          CHECK(enc.stats.cells == S->volume());
          CHECK(enc.stats.placed + enc.stats.kept == enc.stats.cells);
          CHECK(enc.stats.rawDropped == 1);  // the float state of glass: left out, counted
          CHECK(enc.stats.inexact == 0);     // a full table was supplied
        }
  }
}

static void testFallbacksAndCounts() {
  // no variant data: written by palette name only, counted
  {
    auto S = makeStructure(3, false);
    paste::Encoder enc;
    std::string err;
    CHECK(enc.begin(S, Placement{0, 0, 0, 1, false}, paste::Mode::ReplaceAll, nullptr, nullptr, err));
    while (!enc.step(1000)) {}
    const Decoded d = decode(enc.bytes());
    CHECK(d.ok);
    size_t solid = 0;
    for (size_t i = 0; i < S->volume(); ++i)
      if (S->idx[i] != kVoid && !S->palette[S->idx[i]].air) ++solid;
    CHECK(enc.stats.noStates == solid);
    bool names = true;
    for (const auto &e : d.pal) names = names && e.name.rfind("minecraft:", 0) == 0 && e.st.size() <= 1;
    CHECK(names);
  }
  // rotated without a table, or a variant with an unsupported reason: counted as inexact
  {
    auto S = makeStructure(4);
    size_t solid = 0, stairs = 0;
    for (size_t i = 0; i < S->volume(); ++i) {
      if (S->idx[i] != kVoid && !S->palette[S->idx[i]].air) ++solid;
      if (S->vidx[i] == 2) ++stairs;
    }
    paste::Encoder enc;
    std::string err;
    CHECK(enc.begin(S, Placement{0, 0, 0, 2, false}, paste::Mode::ReplaceAll, nullptr, nullptr, err));
    while (!enc.step(64)) {}
    CHECK(enc.stats.inexact == solid);
    const auto table = fakeTable(*S, 2, false);
    std::vector<std::string> uns(S->variants.size());
    uns[2] = "weirdo_direction can't be rotated";
    paste::Encoder enc2;
    CHECK(enc2.begin(S, Placement{0, 0, 0, 2, false}, paste::Mode::ReplaceAll, &table, &uns, err));
    while (!enc2.step(64)) {}
    CHECK(enc2.stats.inexact == stairs);
    // unturned without a table: the original states are exact
    paste::Encoder enc3;
    CHECK(enc3.begin(S, Placement{0, 0, 0, 0, false}, paste::Mode::ReplaceAll, nullptr, nullptr, err));
    while (!enc3.step(64)) {}
    CHECK(enc3.stats.inexact == 0);
  }
  // empty / inconsistent structure refused
  {
    paste::Encoder enc;
    std::string err;
    CHECK(!enc.begin(nullptr, Placement{}, paste::Mode::ReplaceAll, nullptr, nullptr, err));
    auto S = makeStructure(1);
    S->idx.pop_back();
    CHECK(!enc.begin(S, Placement{}, paste::Mode::ReplaceAll, nullptr, nullptr, err));
  }
}

static void testCheck() {
  using B = paste::Block;
  auto S = makeStructure(2);
  const Placement P{10, 64, -20, 1, false};
  CHECK(paste::check(nullptr, P, true, true, 1, false) == B::NoStructure);
  CHECK(paste::check(S.get(), P, false, true, 1, false) == B::NotPlaced);
  CHECK(paste::check(S.get(), P, true, true, 1, true) == B::Busy);
  CHECK(paste::check(S.get(), P, true, false, 1, false) == B::NotInWorld);
  CHECK(paste::check(S.get(), P, true, true, -1, false) == B::CreativeUnknown);
  CHECK(paste::check(S.get(), P, true, true, 0, false) == B::NotCreative);
  CHECK(paste::check(S.get(), P, true, true, 1, false) == B::None);
  paste::Limits small;
  small.maxCells = S->volume() - 1;
  CHECK(paste::check(S.get(), P, true, true, 1, false, small) == B::TooLarge);
  CHECK(paste::check(S.get(), Placement{0, -65, 0, 0, false}, true, true, 1, false) == B::OutOfWorld);
  CHECK(paste::check(S.get(), Placement{0, -64, 0, 0, false}, true, true, 1, false) == B::None);
  CHECK(paste::check(S.get(), Placement{0, 319 - S->sy + 1, 0, 0, false}, true, true, 1, false) == B::None);
  CHECK(paste::check(S.get(), Placement{0, 319 - S->sy + 2, 0, 0, false}, true, true, 1, false) == B::OutOfWorld);
  CHECK(paste::check(S.get(), Placement{29999984, 0, 0, 0, false}, true, true, 1, false) == B::OutOfWorld);
  // rotation changes the footprint used for the border check (sx=3, sz=4)
  CHECK(paste::check(S.get(), Placement{29999984 - 2, 0, 0, 0, false}, true, true, 1, false) == B::None);
  CHECK(paste::check(S.get(), Placement{29999984 - 2, 0, 0, 1, false}, true, true, 1, false) == B::OutOfWorld);
  // creative requirement is checked even when everything else is fine
  for (int c : {-1, 0}) CHECK(paste::check(S.get(), P, true, true, c, false) != B::None);
}

static void testRunEncode() {
  auto S = makeStructure(5);
  const Placement P{0, 0, 0, 3, true};
  const auto table = fakeTable(*S, 3, true);
  std::string err;
  // cancelled after the 2nd step: Cancelled, and the encoder never finished
  {
    paste::Encoder enc;
    CHECK(enc.begin(S, P, paste::Mode::ReplaceAll, &table, nullptr, err));
    int calls = 0;
    const auto out = paste::runEncode(enc, 3, [&] { return ++calls >= 2; }, [] { return false; }, [](float) {});
    CHECK(out == paste::Outcome::Cancelled);
    CHECK(!enc.done());
  }
  // schematic/placement replaced mid-way: Stale
  {
    paste::Encoder enc;
    CHECK(enc.begin(S, P, paste::Mode::ReplaceAll, &table, nullptr, err));
    int calls = 0;
    const auto out = paste::runEncode(enc, 3, [] { return false; }, [&] { return ++calls >= 3; }, [](float) {});
    CHECK(out == paste::Outcome::Stale);
  }
  // cancel requested after the last step is still honoured (checked before anything is written)
  {
    paste::Encoder enc;
    CHECK(enc.begin(S, P, paste::Mode::ReplaceAll, &table, nullptr, err));
    const auto out = paste::runEncode(enc, size_t(1) << 20, [&] { return enc.done(); }, [] { return false; },
                                      [](float) {});
    CHECK(out == paste::Outcome::Cancelled);
  }
  // done: progress reported, ends at 1, each step bounded
  {
    paste::Encoder enc;
    CHECK(enc.begin(S, P, paste::Mode::NonAirOnly, &table, nullptr, err));
    std::vector<float> prog;
    const auto out = paste::runEncode(enc, 5, [] { return false; }, [] { return false; },
                                      [&](float f) { prog.push_back(f); });
    CHECK(out == paste::Outcome::Done);
    CHECK(!prog.empty() && prog.back() == 1.f);
    CHECK(prog.size() >= S->volume() / 5);
    bool mono = true;
    for (size_t i = 1; i < prog.size(); ++i) mono = mono && prog[i] >= prog[i - 1];
    CHECK(mono);
  }
}

static std::string slurp(const std::string &p) {
  std::ifstream f(p, std::ios::binary);
  std::stringstream ss;
  ss << f.rdbuf();
  return ss.str();
}
static size_t countTmp(const std::string &dir) {
  size_t n = 0;
  if (DIR *d = opendir(dir.c_str())) {
    while (dirent *e = readdir(d)) {
      const std::string s = e->d_name;
      if (s.size() > 4 && s.compare(s.size() - 4, 4, ".tmp") == 0) ++n;
    }
    closedir(d);
  }
  return n;
}

static void testFiles() {
  char tmpl[] = "/tmp/pastetestXXXXXX";
  const char *base = mkdtemp(tmpl);
  CHECK(base != nullptr);
  if (!base) return;
  const std::string root = std::string(base) + "/games/com.mojang";
  std::string pack, err;
  CHECK(!paste::ensurePack(root, pack, err));  // root missing: refused, nothing created
  CHECK(!paste::isDir(root));
  mkdir((std::string(base) + "/games").c_str(), 0775);
  mkdir(root.c_str(), 0775);
  CHECK(paste::ensurePack(root, pack, err));
  CHECK(pack == root + "/development_behavior_packs/StructuraPaste");
  const std::string man = slurp(pack + "/manifest.json");
  CHECK(man.find("\"format_version\": 2") != std::string::npos);
  CHECK(man.find("\"type\": \"data\"") != std::string::npos);
  // two different v4 uuids
  std::vector<std::string> ids;
  for (size_t k = man.find("\"uuid\": \""); k != std::string::npos; k = man.find("\"uuid\": \"", k + 1))
    ids.push_back(man.substr(k + 9, 36));
  CHECK(ids.size() == 2 && ids[0] != ids[1] && ids[0][14] == '4' && ids[1][14] == '4');
  // an existing manifest is never rewritten (pack stays activated in worlds)
  std::string pack2;
  CHECK(paste::ensurePack(root, pack2, err));
  CHECK(slurp(pack + "/manifest.json") == man);
  // structure file: atomic, exact bytes, never overwritten, no .tmp left
  auto S = makeStructure(6);
  paste::Encoder enc;
  CHECK(enc.begin(S, Placement{1, 2, 3, 0, false}, paste::Mode::ReplaceAll, nullptr, nullptr, err));
  while (!enc.step(100)) {}
  const std::string id = paste::makeId(S->title, std::time_t(1760000000));
  std::string file;
  CHECK(paste::writeStructure(pack, id, enc.bytes(), file, err));
  CHECK(file == pack + "/structures/structura/" + id + ".mcstructure");
  const std::string got = slurp(file);
  CHECK(got.size() == enc.bytes().size() && std::memcmp(got.data(), enc.bytes().data(), got.size()) == 0);
  std::string file2;
  CHECK(!paste::writeStructure(pack, id, std::vector<uint8_t>{1, 2, 3}, file2, err));
  CHECK(slurp(file) == got);
  CHECK(countTmp(pack + "/structures/structura") == 0);
  // unwritable target: failure reported, nothing left behind
  CHECK(!paste::writeStructure(std::string(base) + "/missing_pack", id, enc.bytes(), file2, err));
  CHECK(!err.empty());
  // decoded file round-trips through the parser
  CHECK(decode(std::vector<uint8_t>(got.begin(), got.end())).ok);
  std::string cmd = "rm -rf '" + std::string(base) + "'";
  CHECK(std::system(cmd.c_str()) == 0);
}

static void testIdsAndCommand() {
  const std::string id = paste::makeId("My House (v2)!!", std::time_t(1760000000));
  bool clean = !id.empty() && id[0] == 'p';
  for (char c : id) clean = clean && ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_');
  CHECK(clean);
  CHECK(id.find("my_house_v2") != std::string::npos);
  CHECK(id.size() <= 16 + 1 + 24);
  CHECK(paste::makeId("", std::time_t(1760000000)).find('_') == 9);  // timestamp only
  CHECK(paste::makeId("Casa Ção", 1760000000).find("casa") != std::string::npos);
  CHECK(paste::makeId("a", 1760000000) != paste::makeId("a", 1760000001));
  CHECK(paste::command("p1_x", Placement{-12, -60, 340, 3, true}) ==
        "/structure load structura:p1_x -12 -60 340 0_degrees none false true");
}

int main() {
  testTransforms();
  testFallbacksAndCounts();
  testCheck();
  testRunEncode();
  testFiles();
  testIdsAndCommand();
  std::printf("paste: %d passed, %d failed\n", gOk, gFail);
  return gFail ? 1 : 0;
}
