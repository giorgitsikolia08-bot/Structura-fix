#!/usr/bin/env python3
"""从 bedrock-samples 的 zh_CN.lang 生成 src/BlockNamesZh.inc（方块 id → 中文名）。
覆盖不了的在运行时回退英文（samples 的语言表本身不全，约 80%）。
usage: gen_block_names_zh.py <bedrock-samples.zip> <out.inc>"""
import sys, zipfile

src, out = sys.argv[1], sys.argv[2]
z = zipfile.ZipFile(src)
lang = z.read("resource_pack/texts/zh_CN.lang").decode("utf-8-sig")

exact, alias = {}, {}
for line in lang.splitlines():
    if line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    if not k.startswith(("tile.", "item.")):
        continue
    name = k.split(".", 1)[1]
    if name.endswith(".name"):
        name = name[:-5]
    v = v.strip()
    if not v:
        continue
    exact.setdefault(name, v)
    parts = name.split(".")
    if len(parts) == 2:
        a, b = parts
        for c in (f"{b}_{a}", f"{a}_{b}", b):
            alias.setdefault(c, v)
        fam = {"log": "log", "log2": "log", "leaves": "leaves", "leaves2": "leaves",
               "planks": "planks", "sapling": "sapling", "wood": "wood", "slab": "slab",
               "stairs": "stairs", "wall": "wall", "cobblestone_wall": "wall"}
        if a in fam:
            alias.setdefault(f"{b}_{fam[a]}", v)

merged = dict(alias)
merged.update(exact)
items = sorted(merged.items())
def esc(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')
with open(out, "w", encoding="utf-8") as f:
    f.write("// 自动生成：bedrock-samples zh_CN.lang → 方块中文名（勿手改）\n")
    f.write("// 生成脚本：tools/gen_block_names_zh.py\n")
    f.write("static const ZhName kZhNames[] = {\n")
    for k, v in items:
        f.write('    {"%s", "%s"},\n' % (esc(k), esc(v)))
    f.write("};\n")
print("%s: %d 条" % (out, len(items)))
