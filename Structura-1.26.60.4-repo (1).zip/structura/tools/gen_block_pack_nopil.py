#!/usr/bin/env python3
"""gen_block_pack.py 的无 Pillow 版本（纯标准库）。

本机（Android / Termux 前缀）装不上 Pillow（源码编译失败），而 scripts/build.sh 依赖它。
本脚本与 tools/gen_block_pack.py 行为一致：
  - 读 bedrock-samples 的 resource_pack/{blocks.json,textures/terrain_texture.json}
  - 只保留图标渲染器用得到的字段；收集可达的 textures/blocks|items/*.png
  - 动画贴图取第一帧（h > w 且 h % w == 0 时裁成 w×w）
  - 最大边 > 16 时用 BOX（面积平均）缩到 16
  - 重编码为 PNG（RGBA8），按固定时间戳写入 zip（同样输入 → 同样字节）
差异：PNG 解码/缩放/编码由本文件自带实现（支持 ctype 0/2/3/4/6、bit depth 1/2/4/8、
Adam7 隔行），不依赖 Pillow。

usage: gen_block_pack_nopil.py <bedrock-samples .zip or folder> <out.zip>
"""
import io
import json
import re
import struct
import sys
import zipfile
import zlib

MAX = 16


# ---------------------------------------------------------------- PNG decode
def _unfilter(raw, w, h, bpp, stride):
    out = bytearray(h * stride)
    pos = 0
    prev = bytearray(stride)
    for y in range(h):
        ft = raw[pos]
        pos += 1
        line = bytearray(raw[pos:pos + stride])
        pos += stride
        if ft == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 0xFF
        elif ft == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif ft == 3:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif ft == 4:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        elif ft != 0:
            raise ValueError("bad filter %d" % ft)
        out[y * stride:(y + 1) * stride] = line
        prev = line
    return out


def _to_rgba(lines, w, h, depth, ctype, plte, trns):
    """把解过滤后的行数据展开成 RGBA8 bytes。"""
    px = bytearray(w * h * 4)
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ctype]
    stride = (w * depth * ch + 7) // 8
    tr = None
    if ctype == 2 and trns and len(trns) >= 6:
        tr = struct.unpack(">HHH", trns[:6])
    for y in range(h):
        row = lines[y * stride:(y + 1) * stride]
        for x in range(w):
            if depth == 8:
                base = x * ch
                s = row[base:base + ch]
                if ctype == 0:
                    r = g = b = s[0]
                    a = 0 if (trns and len(trns) >= 2 and s[0] == struct.unpack(">H", trns[:2])[0] % 256) else 255
                elif ctype == 2:
                    r, g, b = s[0], s[1], s[2]
                    a = 0 if (tr and (r, g, b) == tr) else 255
                elif ctype == 3:
                    i = s[0]
                    r, g, b = plte[i * 3], plte[i * 3 + 1], plte[i * 3 + 2]
                    a = trns[i] if trns and i < len(trns) else 255
                elif ctype == 4:
                    r = g = b = s[0]
                    a = s[1]
                else:
                    r, g, b, a = s[0], s[1], s[2], s[3]
            else:  # depth 1/2/4：样本按 MSB 优先打包
                bit = x * depth
                byte = row[bit >> 3]
                shift = 8 - depth - (bit & 7)
                v = (byte >> shift) & ((1 << depth) - 1)
                if ctype == 3:
                    r, g, b = plte[v * 3], plte[v * 3 + 1], plte[v * 3 + 2]
                    a = trns[v] if trns and v < len(trns) else 255
                else:  # 灰度，展开到 0..255
                    r = g = b = v * 255 // ((1 << depth) - 1)
                    a = 255
            o = (y * w + x) * 4
            px[o] = r
            px[o + 1] = g
            px[o + 2] = b
            px[o + 3] = a
    return px


_ADAM7 = ((0, 0, 8, 8), (4, 0, 8, 8), (0, 4, 4, 8), (2, 0, 4, 4),
          (0, 2, 2, 4), (1, 0, 2, 2), (0, 1, 1, 2))


def png_decode(data):
    """→ (w, h, RGBA8 bytearray)"""
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not png")
    pos = 8
    idat = bytearray()
    plte = trns = None
    w = h = depth = ctype = inter = None
    while pos + 8 <= len(data):
        ln = struct.unpack(">I", data[pos:pos + 4])[0]
        typ = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b"IHDR":
            w, h, depth, ctype, _comp, _filt, inter = struct.unpack(">IIBBBBB", body)
        elif typ == b"PLTE":
            plte = body
        elif typ == b"tRNS":
            trns = body
        elif typ == b"IDAT":
            idat += body
        elif typ == b"IEND":
            break
    if w is None:
        raise ValueError("no IHDR")
    if ctype in (3,) and plte is None:
        raise ValueError("palette missing")
    raw = zlib.decompress(bytes(idat))
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ctype]
    bpp = max(1, depth * ch // 8)

    if inter == 0:
        stride = (w * depth * ch + 7) // 8
        lines = _unfilter(raw, w, h, bpp, stride)
        return w, h, _to_rgba(lines, w, h, depth, ctype, plte, trns)

    # Adam7：逐个 pass 解过滤，再把像素撒回整幅
    full = bytearray(w * h * 4)
    off = 0
    for x0, y0, dx, dy in _ADAM7:
        pw = (w - x0 + dx - 1) // dx
        ph = (h - y0 + dy - 1) // dy
        if pw == 0 or ph == 0:
            continue
        stride = (pw * depth * ch + 7) // 8
        need = ph * (stride + 1)
        lines = _unfilter(raw[off:off + need], pw, ph, bpp, stride)
        off += need
        sub = _to_rgba(lines, pw, ph, depth, ctype, plte, trns)
        for yy in range(ph):
            for xx in range(pw):
                si = (yy * pw + xx) * 4
                di = ((y0 + yy * dy) * w + (x0 + xx * dx)) * 4
                full[di:di + 4] = sub[si:si + 4]
    return w, h, full


# ---------------------------------------------------------------- TGA decode
def tga_decode(data):
    """Truevision TGA → (w, h, RGBA8)。支持 type 2/10（24/32bpp）与 type 3/11（灰度）。"""
    (idlen, cmap, imgtype, _cmaptype, _cmaplen, _cmapbits,
     _x0, _y0, w, h, bpp, desc) = struct.unpack("<BBBHHBHHHHBB", data[:18])
    if imgtype not in (2, 3, 10, 11):
        raise ValueError("tga type %d unsupported" % imgtype)
    pos = 18 + idlen + (cmap and imgtype in (1, 9) and cmap or 0)
    npx = w * h
    step = bpp // 8
    px = bytearray(npx * 4)
    out = [0, 0, 0, 0]

    def put(idx, b):
        if imgtype in (3, 11):
            g = b[0]
            px[idx * 4:idx * 4 + 4] = bytes((g, g, g, b[1] if step > 1 else 255))
        else:
            px[idx * 4] = b[2]
            px[idx * 4 + 1] = b[1]
            px[idx * 4 + 2] = b[0]
            px[idx * 4 + 3] = b[3] if step > 3 else 255

    i = 0
    if imgtype in (2, 3):  # 逐像素
        while i < npx:
            put(i, data[pos + i * step:pos + (i + 1) * step])
            i += 1
    else:  # RLE
        while i < npx:
            hdr = data[pos]
            pos += 1
            cnt = (hdr & 0x7F) + 1
            if hdr & 0x80:
                b = data[pos:pos + step]
                pos += step
                for _ in range(cnt):
                    if i >= npx:
                        break
                    put(i, b)
                    i += 1
            else:
                for _ in range(cnt):
                    if i >= npx:
                        break
                    put(i, data[pos:pos + step])
                    pos += step
                    i += 1
    # desc bit5=0 → 原点左下，需要竖直翻转
    if not (desc & 0x20):
        stride = w * 4
        flipped = bytearray(len(px))
        for y in range(h):
            flipped[y * stride:(y + 1) * stride] = px[(h - 1 - y) * stride:(h - y) * stride]
        px = flipped
    return w, h, px


def decode_any(data):
    """按魔数选解码器（原脚本靠 Pillow 自动识别格式）。"""
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return png_decode(data)
    if data[:4] in (b"\x00\x00\x02\x00", b"\x00\x00\x0a\x00") or len(data) >= 18:
        return tga_decode(data)
    raise ValueError("unknown image format")


# ---------------------------------------------------------------- PNG encode
def png_encode(w, h, rgba):
    def chunk(t, b):
        return (struct.pack(">I", len(b)) + t + b
                + struct.pack(">I", zlib.crc32(t + b) & 0xFFFFFFFF))

    raw = bytearray()
    stride = w * 4
    for y in range(h):
        raw.append(0)  # filter None
        raw += rgba[y * stride:(y + 1) * stride]
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
            + chunk(b"IEND", b""))


# ---------------------------------------------------------------- resize (BOX)
def resize_box(w, h, rgba, nw, nh):
    """面积平均缩放（等价 Pillow Image.BOX；RGBA 各通道独立平均）。"""
    if nw == w and nh == h:
        return w, h, rgba
    sx, sy = w / nw, h / nh
    out = bytearray(nw * nh * 4)
    for dy in range(nh):
        y0, y1 = dy * sy, (dy + 1) * sy
        for dx in range(nw):
            x0, x1 = dx * sx, (dx + 1) * sx
            acc = [0.0, 0.0, 0.0, 0.0]
            area = 0.0
            iy0 = int(y0)
            while iy0 < y1:
                cy = min(iy0 + 1, y1) - max(iy0, y0)
                if cy <= 0:
                    iy0 += 1
                    continue
                ix0 = int(x0)
                while ix0 < x1:
                    cx = min(ix0 + 1, x1) - max(ix0, x0)
                    if cx > 0:
                        wt = cx * cy
                        o = (iy0 * w + ix0) * 4
                        acc[0] += rgba[o] * wt
                        acc[1] += rgba[o + 1] * wt
                        acc[2] += rgba[o + 2] * wt
                        acc[3] += rgba[o + 3] * wt
                        area += wt
                    ix0 += 1
                iy0 += 1
            o = (dy * nw + dx) * 4
            if area <= 0:
                continue
            out[o] = min(255, int(acc[0] / area + 0.5))
            out[o + 1] = min(255, int(acc[1] / area + 0.5))
            out[o + 2] = min(255, int(acc[2] / area + 0.5))
            out[o + 3] = min(255, int(acc[3] / area + 0.5))
    return nw, nh, out


def first_frame(w, h, rgba):
    """动画贴图取第一帧；超尺寸用 BOX 缩到 MAX。"""
    if h > w and h % w == 0:
        h = w
        rgba = rgba[:w * h * 4]
    if max(w, h) > MAX:
        s = MAX / max(w, h)
        nw, nh = max(1, round(w * s)), max(1, round(h * s))
        return resize_box(w, h, rgba, nw, nh)
    return w, h, rgba


# ---------------------------------------------------------------- 生成（同 org）
class Src:
    def __init__(self, p):
        self.zip = zipfile.ZipFile(p) if p.endswith(".zip") else None
        self.root = p
        if self.zip:
            names = self.zip.namelist()
            hit = [n for n in names if n.endswith("resource_pack/blocks.json")]
            assert hit, "resource_pack/blocks.json not found"
            self.base = hit[0][: -len("blocks.json")]
            self.names = set(names)
        else:
            import os
            self.base = os.path.join(p, "resource_pack") + "/"
            self.names = None

    def read(self, rel):
        if self.zip:
            n = self.base + rel
            return self.zip.read(n) if n in self.names else None
        try:
            return open(self.base + rel, "rb").read()
        except OSError:
            return None


def loadj(b):
    s = b.decode("utf-8-sig")
    s = re.sub(r"^\s*//[^\n]*", "", s, flags=re.M)
    return json.loads(s)


def main():
    src, out = sys.argv[1], sys.argv[2]
    S = Src(src)
    blocks = loadj(S.read("blocks.json"))
    terrain = loadj(S.read("textures/terrain_texture.json"))["texture_data"]

    FACE_KEYS = ("up", "down", "side", "north", "south", "east", "west")
    mb = {}
    for k, v in blocks.items():
        if not isinstance(v, dict):
            continue
        o = {}
        for key in ("carried_textures", "textures"):
            t = v.get(key)
            if isinstance(t, str):
                o[key] = t
            elif isinstance(t, dict):
                o[key] = {f: t[f] for f in FACE_KEYS if isinstance(t.get(f), str)}
        if o:
            mb[k] = o

    paths = set()

    def slim1(v):
        t = v.get("textures") if isinstance(v, dict) else None
        if t is None:
            return None
        keep = []
        for it in (t if isinstance(t, list) else [t]):
            if isinstance(it, str):
                keep.append(it)
                paths.add(it)
            elif isinstance(it, dict) and isinstance(it.get("path"), str):
                d = {"path": it["path"]}
                for c in ("tint_color", "overlay_color"):
                    if isinstance(it.get(c), str):
                        d[c] = it[c]
                keep.append(d)
                paths.add(it["path"])
        if not keep:
            return None
        return {"textures": keep if isinstance(t, list) else keep[0]}

    mt = {}
    for k, v in terrain.items():
        r = slim1(v)
        if r:
            mt[k] = r

    fallback = {"textures/blocks/" + k for k in blocks} - paths
    paths |= fallback

    n = 0
    missing = 0
    unreadable = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        base = "assets/resource_packs/vanilla/"

        def entry(name):
            return zipfile.ZipInfo(base + name, (2026, 1, 1, 0, 0, 0))

        z.writestr(entry("blocks.json"), json.dumps(mb, separators=(",", ":")), zipfile.ZIP_DEFLATED)
        z.writestr(entry("textures/terrain_texture.json"),
                   json.dumps({"texture_data": mt}, separators=(",", ":")), zipfile.ZIP_DEFLATED)

        for p in sorted(paths):
            if not p.startswith(("textures/blocks/", "textures/items/")):
                continue
            data = None
            for ext in (".png", ".tga"):
                data = S.read(p + ext)
                if data:
                    break
            if not data:
                missing += p not in fallback
                continue
            try:
                w, h, rgba = decode_any(data)
                w, h, rgba = first_frame(w, h, rgba)
                buf = png_encode(w, h, rgba)
            except Exception as e:  # 解不出来的贴图按“缺失”处理（原脚本同样跳过）
                unreadable += 1
                if unreadable <= 5:
                    print("  skip %s: %s" % (p, e), file=sys.stderr)
                missing += 1
                continue
            z.writestr(entry(p + ".png"), buf, zipfile.ZIP_STORED)
            n += 1
    print("%s: %d blocks, %d terrain entries, %d textures, %d referenced but missing"
          % (out, len(mb), len(mt), n, missing))


if __name__ == "__main__":
    main()
