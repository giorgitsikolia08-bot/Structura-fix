// 预览夹具：只用 UiKit 的画布画出代表性控件，把 DrawCommand 流导成 TSV。
// 目的：在没有游戏的情况下核对「圆角/描边/配色」到底被画成了什么。
#include <cstdio>
#include <string>
#include <vector>

#include "Theme.hpp"
#include "UiKit.hpp"

using namespace lm;
using Canvas = ui::kit::Canvas;
using Rect = ui::kit::Rect;

static void dump(Canvas &cv, float W, float H) {
  printf("# canvas %g %g\n", W, H);
  for (size_t i = 0; i < cv.count; ++i) {
    const auto &d = cv.cmds[i];
    printf("%d\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%08X\t%.2f\t%s\t%.2f\n",
           int(d.type), d.x, d.y, d.w, d.h, d.x3, d.y3, d.color, d.size,
           d.text.c_str(), ui::kit::textWidth(d.text, d.size));
  }
}

int main() {
  theme::UiStyle st{};
  theme::applyTheme(0);
  const float dp = 2.6f;
  auto m = ui::kit::makeMetrics(dp, false, &st, dp);
  const float W = 1100, H = 640;   // 与手机 HUD 面板同量级（px）
  Canvas cv;
  cv.begin(m);

  // 面板
  Rect panel{20, 20, W - 40, H - 40};
  cv.frame(panel, theme::color::Panel, theme::color::PanelBorder, m.radiusPanel, m.border);
  // 顶栏：上半圆角 + 下半方
  Rect h{panel.x, panel.y, panel.w, m.header};
  cv.fill(h, theme::color::Header, m.radiusPanel);
  cv.fill({h.x, h.cy(), h.w, h.h * 0.5f}, theme::color::Header);
  cv.fill({h.x, h.b() - m.border, h.w, m.border}, theme::color::HeaderBorder);
  cv.text({h.x + m.s12, h.y, h.r() - h.x - m.px(60), h.h}, "Structura", theme::color::HeaderText, m.fTitle);
  cv.text({h.r() - m.px(60), h.y, m.px(50), h.h}, "1.2.0", theme::color::TextDisabled, m.fCaption, ui::kit::Align::Right);
  // 侧栏卡片 + 选中项
  Rect nav{panel.x + m.s2, h.b(), m.px(120), panel.b() - h.b() - m.s2};
  cv.fill(nav, theme::color::Nav, m.radius);
  for (int i = 0; i < 4; ++i) {
    Rect it{nav.x + m.s6, nav.y + m.s6 + float(i) * (m.row + m.s2), nav.w - 2 * m.s6, m.row};
    if (i == 0) {
      cv.fill(it, theme::color::AccentRow, m.radius);
      cv.fill({it.x, it.y + m.s6, m.indicator, it.h - m.s12}, theme::color::Accent);
    }
    cv.label({it.x + m.s12, it.y, it.w - m.s12, it.h},
             i == 0 ? "Builds" : (i == 1 ? "Guide" : (i == 2 ? "Create" : "Settings")),
             i == 0 ? theme::color::Text : theme::color::Text,
             m.fLabel);
  }
  // 内容区
  Rect body{nav.r() + m.s12, h.b() + m.s10, panel.r() - nav.r() - 2 * m.s12, 0};
  body.h = panel.b() - body.y - m.s10;
  cv.text({body.x, body.y, body.w, m.row}, "Installed structures", theme::color::Text, m.fTitle);
  Rect search{body.x, body.y + m.row + m.s8, body.w * 0.45f, m.ctl};
  cv.frame(search, theme::color::Surface, theme::color::Divider, m.radius, m.border);
  // 卡片
  Rect card{body.x, search.b() + m.s10, body.w, m.px(84)};
  cv.frame(card, theme::color::Surface, theme::color::Divider, m.radius, m.border);
  Rect thumb{card.x + m.s8, card.y + m.s8, card.h - 2 * m.s8, card.h - 2 * m.s8};
  cv.frame(thumb, theme::color::Thumb, theme::color::Divider, m.radius, m.border);
  cv.text({thumb.r() + m.s10, card.y + m.s10, card.w * 0.4f, m.fBody * 1.6f}, "Example",
          theme::color::Text, m.fBody);
  // 按钮
  Rect b1{card.r() - m.px(230), card.cy() - m.ctl * 0.5f, m.px(90), m.ctl};
  Canvas::ButtonOpts o;
  o.style = Canvas::Style::Primary;
  cv.button(b1, "Use", nullptr, o);
  Rect b2{b1.r() + m.s8, b1.y, m.px(90), m.ctl};
  Canvas::ButtonOpts o2;
  cv.button(b2, "More", nullptr, o2);
  // 分段 + 开关
  const char *segs[] = {"All", "Recent", "Favorites"};
  Rect seg{body.x, card.b() + m.s10, m.px(300), m.ctl};
  cv.segmented(seg, segs, 0, nullptr);
  Rect sw{body.x, seg.b() + m.s10, body.w, m.row};
  static bool on = true;
  cv.switchRow(sw, "Hologram", on ? "On" : "Off", on, nullptr);

  // 弹层示例（放在内容区右侧空白处，避免遮挡卡片）
  Rect pop{body.r() - m.px(200), body.y + m.row + m.s10, m.px(200), m.px(120)};
  cv.frame(pop, theme::color::SurfaceRaised, theme::color::PanelBorder, m.radiusPanel, m.border);
  for (int i = 0; i < 3; ++i) {
    Rect it{pop.x + m.border, pop.y + m.s4 + float(i) * m.px(36), pop.w - 2 * m.border, m.px(34)};
    if (i == 1) cv.fill(it, theme::color::AccentRow, m.radius);
    cv.label({it.x + m.s12, it.y, it.w - m.s12, it.h}, i == 0 ? "All" : (i == 1 ? "Recent" : "Favorites"),
             theme::color::Text, m.fBody);
  }

  dump(cv, W, H);
  return 0;
}
