#!/usr/bin/env python3
"""把 preview 导出的 DrawCommand TSV 渲染成 PNG（纯标准库），用于无真机时核对视觉。
usage: preview <tsv> <out.png>"""
import sys, zlib, struct, math

def png_encode(w, h, rgba):
    def chunk(t, b):
        return struct.pack(">I", len(b)) + t + b + struct.pack(">I", zlib.crc32(t + b) & 0xFFFFFFFF)
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw += rgba[y * w * 4:(y + 1) * w * 4]
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))

class Img:
    def __init__(self, w, h, bg=(80, 130, 235, 255)):
        self.w, self.h = w, h
        self.px = bytearray()
        row = bytes(bg) * w
        for _ in range(h):
            self.px += row
    def blend(self, x, y, c, a):
        if a <= 0 or x < 0 or y < 0 or x >= self.w or y >= self.h: return
        o = (y * self.w + x) * 4
        sa = a / 255.0
        for i in range(3):
            self.px[o + i] = int(self.px[o + i] * (1 - sa) + c[i] * sa + 0.5)
        self.px[o + 3] = 255

def col_of(v):
    a = (v >> 24) & 0xFF
    return ((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF), a

def round_rect(im, x, y, w, h, r, c, a, stroke=False, sw=1.0):
    if w <= 0 or h <= 0: return
    r = min(r, w / 2, h / 2)
    x0, y0, x1, y1 = int(x), int(y), int(x + w), int(y + h)
    for py in range(max(0, y0), min(im.h, y1 + 1)):
        for px in range(max(0, x0), min(im.w, x1 + 1)):
            cx = min(max(px + 0.5, x + r), x + w - r)
            cy = min(max(py + 0.5, y + r), y + h - r)
            d = math.hypot(px + 0.5 - cx, py + 0.5 - cy)
            if stroke:
                cover = max(0.0, min(1.0, (r - abs(d - r)) )) if d > r - sw else 1.0
                cov = 1.0 if r - sw < d < r else max(0.0, 1.0 - abs(d - (r - sw / 2)) / (sw / 2))
            else:
                cov = max(0.0, min(1.0, r - d + 0.5)) if d > r else 1.0
            if cov > 0: im.blend(px, py, c, int(a * cov))

def circle(im, cx, cy, r, c, a):
    for py in range(int(cy - r) - 1, int(cy + r) + 2):
        for px in range(int(cx - r) - 1, int(cx + r) + 2):
            d = math.hypot(px + 0.5 - cx, py + 0.5 - cy)
            if d <= r + 0.5:
                im.blend(px, py, c, int(a * max(0.0, min(1.0, r - d + 0.5))))

def line(im, x1, y1, x2, y2, c, a, wdt):
    steps = int(max(abs(x2 - x1), abs(y2 - y1)) * 2) + 1
    for i in range(steps + 1):
        t = i / steps
        x, y = x1 + (x2 - x1) * t, y1 + (y2 - y1) * t
        r = max(0.5, wdt / 2)
        for py in range(int(y - r) - 1, int(y + r) + 2):
            for px in range(int(x - r) - 1, int(x + r) + 2):
                d = math.hypot(px + 0.5 - x, py + 0.5 - y)
                if d <= r + 0.5:
                    im.blend(px, py, c, int(a * max(0.0, min(1.0, r - d + 0.5))))

def tri(im, x1, y1, x2, y2, x3, y3, c, a):
    minx, maxx = int(min(x1, x2, x3)), int(max(x1, x2, x3))
    miny, maxy = int(min(y1, y2, y3)), int(max(y1, y2, y3))
    def s(ax, ay, bx, by, px, py): return (bx - ax) * (py - ay) - (by - ay) * (px - ax)
    for py in range(max(0, miny), min(im.h, maxy + 1)):
        for px in range(max(0, minx), min(im.w, maxx + 1)):
            d1 = s(x1, y1, x2, y2, px + .5, py + .5)
            d2 = s(x2, y2, x3, y3, px + .5, py + .5)
            d3 = s(x3, y3, x1, y1, px + .5, py + .5)
            if (d1 >= 0 and d2 >= 0 and d3 >= 0) or (d1 <= 0 and d2 <= 0 and d3 <= 0):
                im.blend(px, py, c, a)

def text(im, x, y, h, c, a, tw):
    """占位：按给定宽度画一条半透明文字条（判读布局用）"""
    if tw <= 0: return
    th = max(2, int(h * 0.55))
    alpha = int(a * 0.55)
    round_rect(im, x, y + (h - th) / 2, tw, th, min(3, th / 3), c, alpha)

def main():
    src, out = sys.argv[1], sys.argv[2]
    lines = [l.rstrip("\n") for l in open(src, encoding="utf-8") if l.strip()]
    W = H = 0
    cmds = []
    for l in lines:
        if l.startswith("#"):
            _, _, w, h = l.split()
            W, H = int(float(w)), int(float(h))
            continue
        p = l.split("\t")
        t, x, y, w, h, x3, y3, colv, size = (int(p[0]), float(p[1]), float(p[2]), float(p[3]),
                                             float(p[4]), float(p[5]), float(p[6]), int(p[7], 16), float(p[8]))
        txt = p[9] if len(p) > 9 else ""
        tw = float(p[10]) if len(p) > 10 else 0
        cmds.append((t, x, y, w, h, x3, y3, colv, size, txt, tw))
    im = Img(W, H)
    for (t, x, y, w, h, x3, y3, colv, size, txt, tw) in cmds:
        c, a = col_of(colv)
        if t == 3: round_rect(im, x, y, w, h, x3, c, a)
        elif t == 1: round_rect(im, x, y, w, h, x3, c, a, stroke=True, sw=max(1.0, w if w < 4 else 2))
        elif t == 2: line(im, x, y, x + w, y + h, c, a, max(1.0, size))
        elif t == 4: circle(im, x, y, size, c, a)
        elif t == 5: tri(im, x, y, x + w, y + h, x3, y3, c, a)
        elif t == 6: round_rect(im, x, y, w, h, x3, (60, 60, 64), a)
        elif t == 0: text(im, x, y, size, c, a, tw)
    open(out, "wb").write(png_encode(im.w, im.h, im.px))
    print(out, im.w, im.h, len(cmds), "cmds")

main()
