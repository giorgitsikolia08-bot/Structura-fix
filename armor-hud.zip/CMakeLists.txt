cmake_minimum_required(VERSION 3.22)

project(levilauncher_armor_hud LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# ---------------------------------------------------------------------------
# Mod identity. MOD_ID becomes the runtime mod id and the archive root folder.
# Keep it stable after the first release.
# ---------------------------------------------------------------------------
set(MOD_ID "armor_hud" CACHE STRING "LeviLauncher mod id and archive root folder")
set(MOD_NAME "Armor HUD" CACHE STRING "LeviLauncher mod display name")
set(MOD_AUTHOR "ArmorHUD" CACHE STRING "LeviLauncher mod author")
set(MOD_VERSION "1.0.0" CACHE STRING "LeviLauncher mod version")
set(MOD_LIBRARY_NAME "armor_hud" CACHE STRING "Native library name without lib prefix or .so suffix")
set(MOD_MINECRAFT_VERSIONS "[\"1.26.52\"]" CACHE STRING "Raw JSON array for manifest minecraft_versions")
set(MOD_ICON "" CACHE STRING "Optional package-relative icon path, such as icon.png")

# Pinned SDK revision providing the pl/* headers and the preloader target.
#
# Pinned to a commit rather than a tag on purpose. The HUD code uses
# pl::modmenu::getHudSurfaceSize(), submitHudEditorElements(), HudSurfaceSize and
# HudEditorElement, which do not exist in any tagged release: the newest tag,
# 0.2.3, has submitDrawCommands() and nothing else. The commit below is the
# revision this project was compiled and linked against.
set(LEVI_PRELOADER_COMMIT "5d108da350ce3e7f13f51415f81e65344ecd5d14"
    CACHE STRING "preloader-android git commit")

include(FetchContent)

# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------
FetchContent_Declare(
    preloader_android
    GIT_REPOSITORY https://github.com/LiteLDev/preloader-android.git
    GIT_TAG ${LEVI_PRELOADER_COMMIT}
)
FetchContent_Declare(
    nlohmann_json
    GIT_REPOSITORY https://github.com/nlohmann/json.git
    GIT_TAG v3.11.3
)
FetchContent_Declare(
    boost_pfr
    GIT_REPOSITORY https://github.com/boostorg/pfr.git
    GIT_TAG boost-1.88.0
)
FetchContent_Declare(
    magic_enum
    GIT_REPOSITORY https://github.com/Neargye/magic_enum.git
    GIT_TAG v0.9.7
)
FetchContent_Declare(
    fmt
    GIT_REPOSITORY https://github.com/fmtlib/fmt.git
    GIT_TAG 11.2.0
)

set(FMT_DOC OFF CACHE BOOL "Disable fmt docs" FORCE)
set(FMT_TEST OFF CACHE BOOL "Disable fmt tests" FORCE)
set(FMT_INSTALL OFF CACHE BOOL "Disable fmt install rules" FORCE)

FetchContent_MakeAvailable(nlohmann_json boost_pfr magic_enum fmt)

# The preloader repository only configures on Android, so it must not be added
# as a subdirectory during the host build. Populate it to obtain the headers,
# and add_subdirectory below only for the Android build.
FetchContent_GetProperties(preloader_android)
if(NOT preloader_android_POPULATED)
    FetchContent_Populate(preloader_android)
endif()
set(LEVI_PRELOADER_INCLUDE_DIR "${preloader_android_SOURCE_DIR}/include")

set(ARMOR_HUD_SOURCES
    src/main.cpp
    src/mod/ArmorHudMod.cpp
    src/mod/Config.cpp
    src/mc/ProcessMemory.cpp
    src/mc/Rtti.cpp
    src/mc/GameApi.cpp
    src/mc/ItemStack.cpp
    src/mc/ArmorInventory.cpp
    src/hud/ArmorIcons.cpp
    src/hud/HudLayout.cpp
    src/hud/HudRenderer.cpp
)

# ---------------------------------------------------------------------------
# Host build: validate the reflected config type and emit the JSON schema the
# launcher uses to build its settings UI. No Android toolchain required, which
# is what lets CI check the config surface on every push.
# ---------------------------------------------------------------------------
if(NOT ANDROID)
    set(LEVI_GENERATED_CONFIG_DIR "${CMAKE_CURRENT_BINARY_DIR}/generated-config")

    add_executable(levi_config_generator
        src/config_generator.cpp
        src/mod/Config.cpp
    )

    target_include_directories(levi_config_generator
        PRIVATE
            src
            "${LEVI_PRELOADER_INCLUDE_DIR}"
    )

    target_compile_definitions(levi_config_generator PRIVATE PL_CONFIG_NO_RUNTIME)
    target_link_libraries(levi_config_generator PRIVATE
        nlohmann_json::nlohmann_json
        Boost::pfr
        magic_enum::magic_enum
        fmt::fmt
    )

    add_custom_target(levi_generate_config
        COMMAND levi_config_generator "${LEVI_GENERATED_CONFIG_DIR}"
        DEPENDS levi_config_generator
        COMMENT "Generating config.schema.json"
        VERBATIM
    )

    return()
endif()

# ---------------------------------------------------------------------------
# Android build
# ---------------------------------------------------------------------------
if(NOT CMAKE_ANDROID_ARCH_ABI STREQUAL "arm64-v8a" AND
   NOT CMAKE_ANDROID_ARCH_ABI STREQUAL "armeabi-v7a")
    message(FATAL_ERROR "Unsupported Android ABI: ${CMAKE_ANDROID_ARCH_ABI}")
endif()

option(LEVI_LINK_PRELOADER
       "Build and link the preloader target instead of leaving SDK symbols for runtime lookup"
       ON)

if(LEVI_LINK_PRELOADER AND NOT TARGET preloader)
    add_subdirectory("${preloader_android_SOURCE_DIR}" "${CMAKE_BINARY_DIR}/_preloader_android")
endif()

add_library(${MOD_LIBRARY_NAME} SHARED ${ARMOR_HUD_SOURCES})

set_target_properties(${MOD_LIBRARY_NAME} PROPERTIES
    OUTPUT_NAME "${MOD_LIBRARY_NAME}"
)

target_include_directories(${MOD_LIBRARY_NAME}
    PRIVATE
        src
        "${LEVI_PRELOADER_INCLUDE_DIR}"
)

target_compile_options(${MOD_LIBRARY_NAME}
    PRIVATE
        $<$<COMPILE_LANG_AND_ID:CXX,Clang,GNU>:-fvisibility=hidden -fvisibility-inlines-hidden>
        $<$<COMPILE_LANG_AND_ID:CXX,Clang,GNU>:-Wall -Wextra>
)

# 16 KB page alignment, required by Android 15+ on 64-bit devices.
target_link_options(${MOD_LIBRARY_NAME}
    PRIVATE
        "-Wl,-z,max-page-size=16384"
        "-Wl,--gc-sections"
)

find_library(log-lib log REQUIRED)
target_link_libraries(${MOD_LIBRARY_NAME} PRIVATE
    ${log-lib}
    nlohmann_json::nlohmann_json
    Boost::pfr
    magic_enum::magic_enum
    fmt::fmt
)

if(TARGET preloader)
    target_link_libraries(${MOD_LIBRARY_NAME} PRIVATE preloader)
else()
    # Symbols are provided by the preloader LeviLaunchroid has already loaded
    # into the game process and are resolved lazily at dlopen time.
    target_link_options(${MOD_LIBRARY_NAME} PRIVATE
        "-Wl,--unresolved-symbols=ignore-all"
    )
endif()

if(NOT CMAKE_STRIP)
    message(FATAL_ERROR "CMAKE_STRIP is required to strip the generated library.")
endif()

add_custom_command(TARGET ${MOD_LIBRARY_NAME} POST_BUILD
    COMMAND "${CMAKE_STRIP}" --strip-unneeded "$<TARGET_FILE:${MOD_LIBRARY_NAME}>"
    COMMENT "Stripping symbols from $<TARGET_FILE_NAME:${MOD_LIBRARY_NAME}>"
    VERBATIM
)

configure_file(
    "${CMAKE_CURRENT_SOURCE_DIR}/manifest.json.in"
    "${CMAKE_CURRENT_BINARY_DIR}/manifest.json"
    @ONLY
)

# ---------------------------------------------------------------------------
# .levipack packaging.
#
# A .levipack is a plain ZIP archive. LeviLaunchroid's FileHandler accepts two
# layouts and requires exactly one .so entry in the whole archive:
#
#   flat    : manifest.json + libarmor_hud.so
#   nested  : armor_hud/manifest.json + armor_hud/libarmor_hud.so
#
# The nested layout is used here because the launcher derives the mod id from
# the folder name. "entry" in the manifest is relative to that mod directory.
#
# config.json and config.schema.json are deliberately NOT packaged: the mod
# writes both into its own config directory on first load, which is also where
# the launcher looks for them when it builds the settings UI.
# ---------------------------------------------------------------------------
set(LEVI_PACKAGE_STAGE "${CMAKE_CURRENT_BINARY_DIR}/package")
set(LEVI_PACKAGE_MOD_DIR "${LEVI_PACKAGE_STAGE}/${MOD_ID}")
set(LEVI_PACKAGE_FILE
    "${CMAKE_CURRENT_BINARY_DIR}/${MOD_ID}-${MOD_VERSION}-${CMAKE_ANDROID_ARCH_ABI}.levipack")

set(LEVI_PACKAGE_EXTRA_COMMANDS)

if(NOT MOD_ICON STREQUAL "")
    if(IS_ABSOLUTE "${MOD_ICON}")
        message(FATAL_ERROR "MOD_ICON must be a package-relative path")
    endif()
    if(MOD_ICON MATCHES "(^|/)\\.\\.(/|$)")
        message(FATAL_ERROR "MOD_ICON must not contain ..")
    endif()

    set(MOD_ICON_SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/${MOD_ICON}")
    if(NOT EXISTS "${MOD_ICON_SOURCE}")
        message(FATAL_ERROR "MOD_ICON does not exist: ${MOD_ICON_SOURCE}")
    endif()

    get_filename_component(MOD_ICON_DIR "${MOD_ICON}" DIRECTORY)
    if(NOT MOD_ICON_DIR STREQUAL "")
        list(APPEND LEVI_PACKAGE_EXTRA_COMMANDS
            COMMAND "${CMAKE_COMMAND}" -E make_directory "${LEVI_PACKAGE_MOD_DIR}/${MOD_ICON_DIR}")
    endif()
    list(APPEND LEVI_PACKAGE_EXTRA_COMMANDS
        COMMAND "${CMAKE_COMMAND}" -E copy "${MOD_ICON_SOURCE}" "${LEVI_PACKAGE_MOD_DIR}/${MOD_ICON}")
endif()

add_custom_target(levi_package
    COMMAND "${CMAKE_COMMAND}" -E rm -rf "${LEVI_PACKAGE_STAGE}"
    COMMAND "${CMAKE_COMMAND}" -E make_directory "${LEVI_PACKAGE_MOD_DIR}"
    COMMAND "${CMAKE_COMMAND}" -E copy
            "$<TARGET_FILE:${MOD_LIBRARY_NAME}>"
            "${LEVI_PACKAGE_MOD_DIR}/lib${MOD_LIBRARY_NAME}.so"
    COMMAND "${CMAKE_COMMAND}" -E copy
            "${CMAKE_CURRENT_BINARY_DIR}/manifest.json"
            "${LEVI_PACKAGE_MOD_DIR}/manifest.json"
    ${LEVI_PACKAGE_EXTRA_COMMANDS}
    COMMAND "${CMAKE_COMMAND}" -E chdir "${LEVI_PACKAGE_STAGE}"
            "${CMAKE_COMMAND}" -E tar cf "${LEVI_PACKAGE_FILE}" --format=zip "${MOD_ID}"
    WORKING_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}"
    DEPENDS ${MOD_LIBRARY_NAME}
    COMMENT "Packaging ${LEVI_PACKAGE_FILE}"
    VERBATIM
)