# Armor HUD

A native LeviLauncher / LeviLaunchroid mod for Minecraft Bedrock that shows the
four armour slots next to the hotbar, with the real remaining durability of each
piece read straight from the running game.

- **Minecraft:** 1.26.52
- **Platform:** Android, `arm64-v8a` (also builds for `armeabi-v7a`)
- **Pack format:** `.levipack`, `type: preload-native`

No Resource Pack, no Behaviour Pack, no asset files. The HUD is drawn by the
launcher's own overlay, and the armour sprites are generated in code.

---

## What it shows

Four slots, helmet, chestplate, leggings and boots, each with:

- an icon whose shape matches the piece and whose colour comes from the
  material named in the real item identifier;
- the remaining durability and the total as absolute unit values, for example
  `259/363`;
- a red slot background and a `!` marker when remaining durability reaches the
  configured threshold, `30` units by default.

Durability is never shown as a percentage. Both numbers come from the game:
`maximum` is `Item::getMaxDamage()` and `current` is
`maximum - ItemStackBase::getDamageValue()`. The threshold is compared against
that same absolute value, so it keeps meaning the same thing on every material.

The HUD hides itself when nothing is worn and nothing is detected, and it is
built on the game's own tick, so it costs nothing while the game is paused.

---

## Installing

1. Build or download a `.levipack`.
2. In LeviLauncher, open the mod list and use import/pack install.
3. Start the game.

The mod writes `config.json` and `config.schema.json` into its own config
directory on first run. LeviLauncher picks those up and builds a settings screen
from them, so all options below are editable in the launcher without any file
editing.

If the HUD does not appear, check the launcher log: it reports which game
signatures resolved and, once found, the container and slot offsets that were
discovered.

---

## Building

Requirements:

- Android NDK `28.2.13676358` (any recent NDK works)
- CMake 3.22 or newer
- Ninja
- JDK 17 for the launcher tooling

### Linux / macOS

```bash
./scripts/package.sh
```

### Windows (PowerShell 7)

```powershell
./scripts/package.ps1
```

### Manually

```bash
cmake -S . -B build-arm64-v8a -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-28 \
  -DANDROID_STL=c++_shared

cmake --build build-arm64-v8a --target levi_package
```

The artifact appears as
`build-arm64-v8a/armor_hud-1.0.0-arm64-v8a.levipack`.

The archive is a plain ZIP with exactly one `.so`, which is what the launcher's
`FileHandler` requires:

```
armor_hud/manifest.json
armor_hud/libarmor_hud.so
```

To check the config surface without a device or an Android toolchain:

```bash
cmake -S . -B build-config -G Ninja
cmake --build build-config --target levi_generate_config
```

This is what CI runs on every push.

---

## Settings

| Key | Default | Meaning |
| --- | --- | --- |
| `enabled` | `true` | Master switch. |
| `hideWhenEmpty` | `true` | Hide the HUD when no armour is detected. |
| `showDurabilityText` | `true` | Show `current/maximum` in each slot. |
| `lowDurabilityThreshold` | `30` | Warn at or below this many remaining durability units. |
| `followHotbar` | `true` | Anchor above the estimated hotbar instead of fixed anchors. |
| `anchorX`, `anchorY` | `-10000` | Magic anchors used when `followHotbar` is off. |
| `anchorOffsetX`, `anchorOffsetY` | `0` | Pixel offsets from those anchors. Also what the in-game HUD editor writes. |
| `scale` | `1.0` | Multiplier on the automatic resolution scale. |
| `hotbarGap` | `6` | Gap between the HUD and the hotbar, in reference pixels. |
| `cellSize` | `44` | Slot size, in reference pixels at 1920x1080. |
| `iconSize` | `30` | Icon size, same units. |
| `textSize` | `9` | Durability text size, same units. |
| `textOffsetY` | `30` | Text position inside the slot. |
| `textColor` | `0xFFFFFFFF` | Normal text colour. |
| `warningColor` | `0xFFFF5B5B` | Low-durability text colour. |
| `slotBackgroundColor` | `0xB0101010` | Normal slot background. |
| `warningBackgroundColor` | `0xB0300000` | Low-durability slot background. |
| `containerOffset` | `-1` | Manual override for the armour container offset. |
| `slotArrayOffset` | `-1` | Manual override for the slot array offset. |
| `slotStride` | `0` | Manual override for the distance between slots. |
| `maxDamageVtableIndex` | `37` | vtable index of `Item::getMaxDamage()`. |

Geometry is authored against a 1920x1080 reference and scaled from the surface
height, so the HUD keeps its size on phones and tablets without a second set of
magic anchors.

---

## How it finds the armour slots

There are no hard-coded container offsets. On each tick the mod does a bounded
slice of a scan over the player object:

1. Every plausible sub-object is checked, both pointer members and inline
   sub-objects.
2. Each candidate is asked whether any member is a slot array. A begin/end pair
   whose span is exactly four strides is preferred, because it proves the
   stride and the slot count at the same time.
3. Candidates are scored. A slot holding an item with no durability is an
   immediate reject, because nothing but armour can occupy an armour slot.
   Item names are used as confirmation when they can be read: `diamond_helmet`
   in the first slot and `diamond_boots` in the fourth is a near-certain
   identification.
4. The best candidate is kept, then re-validated every tick. If validation keeps
   failing the scan restarts on its own.

That is what makes respawn, dimension change, world change and game restarts a
non-event. If discovery ever fails, `containerOffset`, `slotArrayOffset` and
`slotStride` can be set by hand in the settings screen.

Item identifiers are found by scanning the `Item` object for a pointer to a
namespaced name, or for a copy stored inline. That avoids depending on the
layout of `std::string` or `HashedString`, so armour from add-ons and future
Minecraft versions is coloured automatically.

The mod only reads game memory. It never writes to it.

---

## Version dependence

Four byte signatures are the only version-specific artefacts:

| Name | Use |
| --- | --- |
| `NormalTick` | Supplies the local player each tick. Required. |
| `ClientInstanceUpdate` | Cross-check for the client instance. Optional. |
| `ClientInstanceGetLocalPlayer` | Fallback way to reach the player. Optional. |
| `ItemStackBaseGetDamageValue` | Reads consumed durability. Required. |

They are in `src/mc/GameApi.cpp`. When Minecraft changes the surrounding code
they stop resolving, the mod says so in the log, and only those patterns need
replacing. Everything else is discovered at runtime.

---

## Layout

```
src/
  main.cpp                     PL_REGISTER_MOD entry point
  config_generator.cpp         host-only JSON schema tool
  mod/
    ArmorHudMod.{h,cpp}        lifecycle, hook wiring, tick handler
    Config.{h,cpp}             typed settings and schema metadata
  mc/
    GameApi.{h,cpp}            signatures, hooks, player pointer
    ArmorInventory.{h,cpp}     incremental slot discovery
    ItemStack.{h,cpp}          durability and item identity
    ProcessMemory.{h,cpp}      bounds-checked reads via /proc/self/maps
    Rtti.{h,cpp}               Itanium RTTI, demangling, vtable lookup
  hud/
    HudLayout.{h,cpp}          resolution-independent geometry
    HudRenderer.{h,cpp}        draw commands and change detection
    ArmorIcons.{h,cpp}         procedural sprites
```

---

## Licence

MIT. See `LICENSE`.