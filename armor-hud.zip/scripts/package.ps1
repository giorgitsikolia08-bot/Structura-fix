param(
    [ValidateSet("arm64-v8a", "armeabi-v7a", "all")]
    [string]$Abi = "arm64-v8a",
    [string]$NdkHome = "",
    [string]$AndroidPlatform = "android-28",
    [string]$Generator = "Ninja",
    [string]$BuildRoot = "build"
)

$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Resolve-Path (Join-Path $scriptDir "..")

# The mod writes config.json into its own config directory on first run, so
# there is no config to generate or pass in here. The config target below only
# exists to type-check the config surface during CI.

function Invoke-ConfigValidation {
    $configBuildDir = Join-Path $repoRoot "$BuildRoot-config"

    & cmake -S $repoRoot -B $configBuildDir -G $Generator 2>&1 |
        ForEach-Object { Write-Host $_ }

    & cmake --build $configBuildDir --target levi_generate_config 2>&1 |
        ForEach-Object { Write-Host $_ }

    Write-Host "config schema OK"
}

function Resolve-NdkHome {
    if (-not [string]::IsNullOrWhiteSpace($NdkHome) -and (Test-Path $NdkHome)) {
        return (Resolve-Path $NdkHome).Path
    }

    if (-not [string]::IsNullOrWhiteSpace($env:ANDROID_HOME)) {
        $preferred = Join-Path $env:ANDROID_HOME "ndk/28.2.13676358"
        if (Test-Path $preferred) {
            return (Resolve-Path $preferred).Path
        }

        $ndkRoot = Join-Path $env:ANDROID_HOME "ndk"
        if (Test-Path $ndkRoot) {
            $candidate = Get-ChildItem -Path $ndkRoot -Directory |
                Sort-Object Name -Descending |
                Select-Object -First 1
            if ($candidate) {
                return $candidate.FullName
            }
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($env:ANDROID_NDK_HOME) -and (Test-Path $env:ANDROID_NDK_HOME)) {
        return (Resolve-Path $env:ANDROID_NDK_HOME).Path
    }

    throw "Android NDK not found. Set ANDROID_NDK_HOME, ANDROID_HOME or pass -NdkHome."
}

function Invoke-ModBuild {
    param([string]$TargetAbi)

    $ndkHome = Resolve-NdkHome
    $toolchain = Join-Path $ndkHome "build/cmake/android.toolchain.cmake"
    $buildDir = Join-Path $repoRoot "$BuildRoot-$TargetAbi"

    Write-Host "==> building $TargetAbi with NDK $ndkHome"
    cmake -S $repoRoot -B $buildDir -G $Generator `
        -DCMAKE_TOOLCHAIN_FILE="$toolchain" `
        -DANDROID_ABI="$TargetAbi" `
        -DANDROID_PLATFORM="$AndroidPlatform" `
        -DANDROID_STL="c++_shared" 2>&1 |
        ForEach-Object { Write-Host $_ }

    cmake --build $buildDir --target levi_package 2>&1 |
        ForEach-Object { Write-Host $_ }

    Get-ChildItem -Path $buildDir -Filter *.levipack | ForEach-Object { $_.FullName }
}

Invoke-ConfigValidation

if ($Abi -eq "all") {
    Invoke-ModBuild "arm64-v8a"
    Invoke-ModBuild "armeabi-v7a"
} else {
    Invoke-ModBuild $Abi
}