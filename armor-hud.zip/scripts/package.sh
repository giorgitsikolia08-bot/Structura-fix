#!/usr/bin/env bash
#
# Builds the .levipack for Android.
#
#   ./scripts/package.sh                      # arm64-v8a
#   ./scripts/package.sh --abi all            # arm64-v8a and armeabi-v7a
#   ./scripts/package.sh --ndk /path/to/ndk   # explicit NDK
#
# The mod writes config.json into its own config directory on first run, so
# there is no config to generate or pass in here. The config target below only
# exists to type-check the config surface during CI.

set -euo pipefail

ABI="arm64-v8a"
NDK_HOME_ARG=""
ANDROID_PLATFORM="android-28"
GENERATOR="Ninja"
BUILD_ROOT="build"

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "${script_dir}/.." && pwd)"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --abi) ABI="$2"; shift 2 ;;
        --ndk) NDK_HOME_ARG="$2"; shift 2 ;;
        --platform) ANDROID_PLATFORM="$2"; shift 2 ;;
        --generator) GENERATOR="$2"; shift 2 ;;
        --build-root) BUILD_ROOT="$2"; shift 2 ;;
        -h|--help)
            sed -n '2,12p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
            exit 0 ;;
        *) echo "unknown argument: $1" >&2; exit 2 ;;
    esac
done

# --- locate the NDK ----------------------------------------------------------
resolve_ndk() {
    if [[ -n "${NDK_HOME_ARG}" ]]; then
        echo "${NDK_HOME_ARG}"
        return
    fi
    if [[ -n "${ANDROID_NDK_HOME:-}" ]]; then
        echo "${ANDROID_NDK_HOME}"
        return
    fi
    if [[ -n "${ANDROID_HOME:-}" ]]; then
        local preferred="${ANDROID_HOME}/ndk/28.2.13676358"
        if [[ -d "${preferred}" ]]; then
            echo "${preferred}"
            return
        fi
        local newest
        newest="$(find "${ANDROID_HOME}/ndk" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort -V | tail -n1 || true)"
        if [[ -n "${newest}" ]]; then
            echo "${newest}"
            return
        fi
    fi
    echo "error: no Android NDK found; pass --ndk or set ANDROID_NDK_HOME" >&2
    exit 1
}

# --- validate the config surface on the host ---------------------------------
validate_config() {
    local config_build="${repo_root}/${BUILD_ROOT}-config"
    cmake -S "${repo_root}" -B "${config_build}" -G "${GENERATOR}"
    cmake --build "${config_build}" --target levi_generate_config
    echo "config schema OK"
}

build_abi() {
    local target_abi="$1"
    local ndk_home
    ndk_home="$(resolve_ndk)"
    local toolchain="${ndk_home}/build/cmake/android.toolchain.cmake"
    local build_dir="${repo_root}/${BUILD_ROOT}-${target_abi}"

    echo "==> building ${target_abi} with NDK ${ndk_home}"
    cmake -S "${repo_root}" -B "${build_dir}" -G "${GENERATOR}" \
        -DCMAKE_TOOLCHAIN_FILE="${toolchain}" \
        -DANDROID_ABI="${target_abi}" \
        -DANDROID_PLATFORM="${ANDROID_PLATFORM}" \
        -DANDROID_STL="c++_shared"

    cmake --build "${build_dir}" --target levi_package

    # Surface the artifact path so CI can upload it.
    find "${build_dir}" -maxdepth 1 -name '*.levipack' -print
}

validate_config

case "${ABI}" in
    all)
        build_abi "arm64-v8a"
        build_abi "armeabi-v7a" ;;
    arm64-v8a|armeabi-v7a)
        build_abi "${ABI}" ;;
    *)
        echo "error: unsupported --abi '${ABI}'" >&2
        exit 2 ;;
esac