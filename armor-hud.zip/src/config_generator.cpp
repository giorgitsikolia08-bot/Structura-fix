/**
 * @file config_generator.cpp
 * @brief Host-only tool that emits the mod's JSON schema.
 *
 * This never ships inside the .levipack. It exists so the config surface can
 * be type-checked and rendered on a build machine or in CI without an Android
 * toolchain, which catches config regressions long before a device build.
 *
 * Usage: levi_config_generator <output-directory>
 */

#include <cstdio>
#include <filesystem>
#include <iostream>
#include <string>

#include <pl/Config.hpp>

#include "mod/Config.h"

namespace {

using armor_hud::mod::ArmorHudConfig;

/**
 * @brief Serialises the default config and its schema.
 */
int write(const std::filesystem::path &directory) {
    std::error_code error;
    std::filesystem::create_directories(directory, error);
    if (error) {
        std::cerr << "cannot create " << directory << ": " << error.message()
                  << '\n';
        return 1;
    }

    const ArmorHudConfig defaults{};
    const auto defaultsJson = pl::config::defaultJson(defaults);
    const auto schemaJson = pl::config::schema(defaults);

    const auto configPath = directory / "config.json";
    const auto schemaPath = directory / "config.schema.json";

    if (!pl::config::saveConfig(configPath, nlohmann::ordered_json(defaultsJson))) {
        std::cerr << "cannot write " << configPath << '\n';
        return 1;
    }
    if (!pl::config::saveConfig(schemaPath, nlohmann::ordered_json(schemaJson))) {
        std::cerr << "cannot write " << schemaPath << '\n';
        return 1;
    }

    // Round-trip the defaults through the deserialiser. A field that cannot be
    // read back is a bug that would otherwise only show up at runtime.
    ArmorHudConfig restored{};
    pl::reflection::deserializeTo(restored, nlohmann::ordered_json(defaultsJson));
    if (restored.lowDurabilityThreshold != defaults.lowDurabilityThreshold ||
        restored.maxDamageVtableIndex != defaults.maxDamageVtableIndex ||
        restored.version != defaults.version) {
        std::cerr << "config round-trip mismatch\n";
        return 1;
    }

    std::cout << "wrote " << configPath << "\n"
              << "wrote " << schemaPath << "\n";
    return 0;
}

} // namespace

int main(int argc, char **argv) {
    if (argc != 2) {
        std::cerr << "usage: " << argv[0] << " <output-directory>\n";
        return 2;
    }
    return write(std::filesystem::path(argv[1]));
}