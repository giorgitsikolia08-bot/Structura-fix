#include "hud/ArmorIcons.h"

#include <array>
#include <cstring>
#include <unordered_set>

#include <pl/ModMenu.hpp>

namespace armor_hud::hud::icons {
namespace {

/**
 * @brief One sprite: 16 rows of 16 characters, '#' marking an opaque pixel.
 *
 * The shapes are deliberately simple and readable at the small size a HUD slot
 * allows. Outlines are darker than the fill so the silhouette stays clear over
 * both bright and dark backgrounds.
 */
struct SpriteMask {
    ArmorKind kind;
    const char *rows[kIconSize];
};

const SpriteMask kMasks[] = {
    {ArmorKind::Helmet,
     {
         "................",
         ".....######.....",
         "...##########...",
         "..############..",
         "..###..#######..",
         "..###....#####..",
         "..###......###..",
         "..###......###..",
         "..###......###..",
         "..###......###..",
         "................",
         "................",
         "................",
         "................",
         "................",
         "................",
     }},
    {ArmorKind::Chestplate,
     {
         "................",
         "................",
         "..############..",
         "..############..",
         "..############..",
         "..############..",
         "..###.####.###..",
         "..###.####.###..",
         "..###.####.###..",
         "..###.####.###..",
         "..############..",
         "..############..",
         "..############..",
         "................",
         "................",
         "................",
     }},
    {ArmorKind::Leggings,
     {
         "................",
         "................",
         "..###..####.###.",
         "..###..####.###.",
         "..############..",
         "..############..",
         "..############..",
         "..############..",
         "..###......###..",
         "..###......###..",
         "..###......###..",
         "..############..",
         "..############..",
         "................",
         "................",
         "................",
     }},
    {ArmorKind::Boots,
     {
         "................",
         "................",
         "................",
         "................",
         "................",
         "..############..",
         "..############..",
         "..############..",
         "..############..",
         "..###......###..",
         "..###......###..",
         "..###......###..",
         "..###..########.",
         "..###..########.",
         "..###..########.",
         "................",
     }},
};

/**
 * @brief Base colours per armour material, taken from the item identifier.
 */
struct Material {
    const char *token;
    std::uint32_t rgb;
};

constexpr Material kMaterials[] = {
    {"netherite", 0x4A3F52}, {"diamond", 0x53D8D6}, {"iron", 0xD6D6D6},
    {"gold", 0xEFC53F},       {"golden", 0xEFC53F}, {"chain", 0x8E8E8E},
    {"chainmail", 0x8E8E8E},  {"leather", 0x9A5C33}, {"turtle", 0x4FA22B},
    {"carapace", 0x4FA22B},   {"copper", 0xC87F4A}, {"amethyst", 0xA067C4},
    {"smithing", 0x4A4A4A},
};

// Used when the identifier is unknown or names a material not listed above.
constexpr std::uint32_t kFallbackRgb = 0xA8B0B8;

std::uint32_t materialRgb(std::string_view itemPath) {
    for (const Material &material : kMaterials) {
        if (itemPath.find(material.token) != std::string_view::npos) {
            return material.rgb;
        }
    }
    return kFallbackRgb;
}

void writePixel(std::vector<unsigned char> &pixels, std::size_t index,
                std::uint32_t rgb, std::uint8_t alpha) {
    pixels[index + 0] = static_cast<unsigned char>((rgb >> 16) & 0xFF);
    pixels[index + 1] = static_cast<unsigned char>((rgb >> 8) & 0xFF);
    pixels[index + 2] = static_cast<unsigned char>(rgb & 0xFF);
    pixels[index + 3] = alpha;
}

/**
 * @brief Darkens a colour, used for the outline pass.
 */
std::uint32_t shade(std::uint32_t rgb, float factor) {
    const auto channel = [factor](unsigned value) {
        const auto scaled = static_cast<unsigned>(value * factor);
        return static_cast<std::uint8_t>(scaled > 255 ? 255 : scaled);
    };
    return (static_cast<std::uint32_t>(channel(static_cast<unsigned>((rgb >> 16) & 0xFF))) << 16) |
           (static_cast<std::uint32_t>(channel(static_cast<unsigned>((rgb >> 8) & 0xFF))) << 8) |
           static_cast<std::uint32_t>(channel(static_cast<unsigned>(rgb & 0xFF)));
}

/**
 * @brief Renders a mask into an RGBA image.
 *
 * Each row is drawn twice: a darker pass offset by one pixel up and left, then
 * the fill pass. That produces an outline without needing a second mask.
 */
const SpriteMask *findMask(ArmorKind kind) {
    for (const SpriteMask &mask : kMasks) {
        if (mask.kind == kind) return &mask;
    }
    return nullptr;
}

bool isOpaque(const char *row, int x) {
    return row[x] == '#';
}

RgbaImage render(ArmorKind kind, std::uint32_t rgb) {
    RgbaImage image;
    image.width = kIconSize;
    image.height = kIconSize;
    image.pixels.assign(static_cast<std::size_t>(kIconSize) * kIconSize * 4, 0);

    const SpriteMask *mask = findMask(kind);
    if (mask == nullptr) return image;

    const std::uint32_t fill = rgb;
    const std::uint32_t outline = shade(rgb, 0.55f);
    const std::uint32_t highlight = shade(rgb, 1.25f);

    auto setIfOpaque = [&image](int x, int y, std::uint32_t color) {
        if (x < 0 || y < 0 || x >= image.width || y >= image.height) return;
        const auto index =
            (static_cast<std::size_t>(y) * image.width + static_cast<std::size_t>(x)) * 4;
        writePixel(image.pixels, index, color, 255);
    };

    // Outline pass.
    for (int y = 0; y < kIconSize; ++y) {
        const char *row = mask->rows[y];
        for (int x = 0; x < kIconSize; ++x) {
            if (!isOpaque(row, x)) continue;
            setIfOpaque(x - 1, y, outline);
            setIfOpaque(x + 1, y, outline);
            setIfOpaque(x, y - 1, outline);
            setIfOpaque(x, y + 1, outline);
        }
    }

    // Fill pass, with a lighter band across the upper third for a hint of
    // volume that stays legible at small sizes.
    for (int y = 0; y < kIconSize; ++y) {
        const char *row = mask->rows[y];
        for (int x = 0; x < kIconSize; ++x) {
            if (!isOpaque(row, x)) continue;
            setIfOpaque(x, y, y < kIconSize / 3 ? highlight : fill);
        }
    }

    return image;
}

std::unordered_set<std::string> &registry() {
    static std::unordered_set<std::string> ids;
    return ids;
}

} // namespace

std::string imageId(ArmorKind kind, std::string_view itemPath) {
    static const char *kindNames[] = {"helmet", "chestplate", "leggings", "boots"};
    const std::size_t index = static_cast<std::size_t>(kind);
    const char *kindName = index < 4 ? kindNames[index] : "helmet";

    std::string sanitized(itemPath);
    for (char &ch : sanitized) {
        if (ch == '/' || ch == '\\' || ch == ' ' || ch == '\t') ch = '_';
    }
    if (sanitized.empty()) sanitized = "unknown";

    return std::string("armor_hud/icon/") + kindName + "/" + sanitized;
}

bool ensureRegistered(ArmorKind kind, std::string_view itemPath) {
    const std::string id = imageId(kind, itemPath);
    if (registry().contains(id)) return true;

    const RgbaImage image = render(kind, materialRgb(itemPath));
    if (image.empty()) return false;

    if (!pl::modmenu::registerImage(id, image.pixels, image.width, image.height)) {
        return false;
    }
    registry().insert(id);
    return true;
}

int registeredCount() { return static_cast<int>(registry().size()); }

} // namespace armor_hud::hud::icons