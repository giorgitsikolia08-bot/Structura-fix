#pragma once

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace armor_hud::hud {

/**
 * @brief An RGBA image handed to pl::modmenu::registerImage.
 *        Pixels are row-major, four bytes each, in R, G, B, A order.
 */
struct RgbaImage {
    int width{};
    int height{};
    std::vector<unsigned char> pixels;

    [[nodiscard]] bool empty() const {
        return pixels.empty() ||
               pixels.size() != static_cast<std::size_t>(width) * height * 4;
    }
};

/**
 * @brief Armour family, which selects the sprite shape.
 */
enum class ArmorKind : std::uint8_t {
    Helmet,
    Chestplate,
    Leggings,
    Boots,
};

/**
 * @brief Generates and registers the armour sprites.
 *
 * The sprites are drawn in code rather than shipped as image files so the pack
 * contains no assets that could go missing. The shape comes from the armour
 * family and the colour from the material named in the real item identifier,
 * which means armour added by a future Minecraft version or by an add-on is
 * coloured automatically instead of falling back to a blank tile.
 */
namespace icons {

inline constexpr int kIconSize = 16;

/**
 * @brief Returns the registered image id for an item, for example
 *        "armor_hud/icon/diamond_helmet".
 */
[[nodiscard]] std::string imageId(ArmorKind kind, std::string_view itemPath);

/**
 * @brief Registers the sprite if it has not been registered yet.
 * @return true when the sprite is ready to be referenced by a DrawCommand.
 */
bool ensureRegistered(ArmorKind kind, std::string_view itemPath);

/**
 * @brief Number of sprites registered so far, for logging.
 */
[[nodiscard]] int registeredCount();

} // namespace icons

} // namespace armor_hud::hud