#include "hud/HudLayout.h"

#include <algorithm>

namespace armor_hud::hud {
namespace {

// The layout is authored against this reference and scaled from there.
constexpr float kReferenceWidth = 1920.0f;
constexpr float kReferenceHeight = 1080.0f;

// Estimated dimensions of the Bedrock hotbar band, also in reference pixels.
constexpr float kHotbarHeight = 68.0f;
constexpr float kHotbarMargin = 26.0f;
constexpr float kHotbarWidth = 440.0f;

} // namespace

float resolveAnchor(float value, float extent) {
    if (value <= -19000.0f) return (extent * 0.5f) + (value + 20000.0f);
    if (value <= -9000.0f) return extent + (value + 10000.0f);
    return value;
}

HudMetrics computeMetrics(const mod::ArmorHudConfig &config,
                          pl::modmenu::HudSurfaceSize surface) {
    HudMetrics metrics;

    const float width = surface.width > 1.0f ? surface.width : kReferenceWidth;
    const float height = surface.height > 1.0f ? surface.height : kReferenceHeight;

    // Scale from height so the HUD keeps its size in landscape and portrait,
    // then clamp so it can never be larger than the screen or microscopic.
    const float autoScale = height / kReferenceHeight;
    metrics.scale = std::clamp(autoScale * config.scale, 0.35f, 6.0f);

    metrics.cellWidth = config.cellSize * metrics.scale;
    metrics.cellHeight = config.cellSize * metrics.scale;
    metrics.cellSpacing = 2.0f * metrics.scale;
    metrics.iconSize = config.iconSize * metrics.scale;
    metrics.textSize = config.textSize * metrics.scale;
    metrics.textOffsetY = config.textOffsetY * metrics.scale;

    metrics.containerWidth =
        metrics.cellWidth * 4.0f + metrics.cellSpacing * 3.0f;
    metrics.containerHeight = metrics.cellHeight;

    // Estimated hotbar band.
    metrics.hotbarHeight = kHotbarHeight * metrics.scale;
    metrics.hotbarBottom = height - kHotbarMargin * metrics.scale;
    metrics.hotbarTop = metrics.hotbarBottom - metrics.hotbarHeight;
    metrics.hotbarCentreX = width * 0.5f;

    if (config.followHotbar) {
        // Sit the HUD directly above the hotbar, centred on it.
        metrics.containerX =
            metrics.hotbarCentreX - metrics.containerWidth * 0.5f;
        metrics.containerY =
            metrics.hotbarTop - config.hotbarGap * metrics.scale -
            metrics.containerHeight;
    } else {
        metrics.containerX = resolveAnchor(config.anchorX, width) +
                             config.anchorOffsetX * metrics.scale;
        metrics.containerY = resolveAnchor(config.anchorY, height) +
                             config.anchorOffsetY * metrics.scale;
    }

    // Keep the whole HUD on screen even with extreme config values.
    metrics.containerX =
        std::clamp(metrics.containerX, 0.0f, std::max(0.0f, width - metrics.containerWidth));
    metrics.containerY =
        std::clamp(metrics.containerY, 0.0f, std::max(0.0f, height - metrics.containerHeight));

    return metrics;
}

} // namespace armor_hud::hud