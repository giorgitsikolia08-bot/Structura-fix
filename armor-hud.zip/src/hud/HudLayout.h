#pragma once

#include <cstdint>

#include <pl/ModMenu.hpp>

#include "mod/Config.h"

namespace armor_hud::hud {

/**
 * @brief Resolution-independent geometry for the HUD.
 *
 * All layout values are authored against a 1920x1080 reference and then scaled
 * by surface height, so the HUD keeps the same apparent size on a phone and on
 * a tablet without a second set of magic anchors.
 */
struct HudMetrics {
    float scale{1.0f};

    float containerWidth{};
    float containerHeight{};
    float containerX{};
    float containerY{};

    float cellWidth{};
    float cellHeight{};
    float cellSpacing{};

    float iconSize{};
    float textSize{};
    float textOffsetY{};

    /**
     * @brief Estimated hotbar band, used both for anchoring and to know where
     *        to hide the HUD while a full-screen menu owns the display.
     */
    float hotbarHeight{};
    float hotbarTop{};
    float hotbarBottom{};
    float hotbarCentreX{};
};

/**
 * @brief Computes the HUD geometry for a given overlay surface.
 */
[[nodiscard]] HudMetrics
computeMetrics(const mod::ArmorHudConfig &config,
               pl::modmenu::HudSurfaceSize surface);

/**
 * @brief Resolves one magic-anchor coordinate exactly as the overlay does.
 * @param value raw coordinate, may be negative to anchor to an edge or centre.
 * @param extent surface width or height.
 */
[[nodiscard]] float resolveAnchor(float value, float extent);

} // namespace armor_hud::hud