#include "hud/HudRenderer.h"

#include "hud/ArmorIcons.h"

#include <algorithm>
#include <array>
#include <cstdio>
#include <string>
#include <string_view>

namespace armor_hud::hud {
namespace {

using pl::modmenu::DrawCommand;
using pl::modmenu::DrawCommandType;

constexpr std::array<ArmorKind, mc::ArmorInventory::kSlotCount> kSlotIcons = {
    ArmorKind::Helmet, ArmorKind::Chestplate, ArmorKind::Leggings,
    ArmorKind::Boots};

/**
 * @brief Appends a filled rectangle.
 */
void pushRect(std::vector<DrawCommand> &out, float x, float y, float w, float h,
              std::uint32_t color) {
    DrawCommand command;
    command.type = DrawCommandType::RectFilled;
    command.x = x;
    command.y = y;
    command.w = w;
    command.h = h;
    command.color = color;
    out.push_back(command);
}

/**
 * @brief Appends a centred text run.
 *
 * The overlay centres text when w is exactly -2, so no width measurement is
 * needed on this side.
 */
void pushText(std::vector<DrawCommand> &out, float x, float y, float size,
              std::uint32_t color, std::string text) {
    DrawCommand command;
    command.type = DrawCommandType::Text;
    command.x = x;
    command.y = y;
    command.w = -2.0f;  // centre alignment
    command.h = 0.0f;
    command.size = size;
    command.color = color;
    command.text = std::move(text);
    out.push_back(command);
}

/**
 * @brief Appends a sprite.
 */
void pushImage(std::vector<DrawCommand> &out, float x, float y, float w, float h,
               std::string imageId) {
    DrawCommand command;
    command.type = DrawCommandType::Image;
    command.x = x;
    command.y = y;
    command.w = w;
    command.h = h;
    command.color = 0xFFFFFFFF;
    command.imageId = std::move(imageId);
    out.push_back(command);
}

/**
 * @brief Formats remaining durability and the total as absolute unit values.
 *
 * Deliberately "current/maximum". No percentage is computed, because the
 * warning threshold is expressed in durability units rather than in percent.
 */
std::string formatDurability(const mc::ArmorPiece &piece) {
    char buffer[48];
    const int written = std::snprintf(buffer, sizeof(buffer), "%d/%d",
                                      piece.current, piece.maximum);
    if (written <= 0) return {};
    return std::string(buffer, static_cast<std::size_t>(written));
}

/**
 * @brief Mixes a colour's alpha channel, used to dim empty slots.
 */
std::uint32_t withAlpha(std::uint32_t color, float factor) {
    const auto alpha = static_cast<unsigned>((color >> 24) & 0xFF);
    const auto scaled = static_cast<std::uint8_t>(
        static_cast<float>(alpha) * std::clamp(factor, 0.0f, 1.0f));
    return (color & 0x00FFFFFFu) | (static_cast<std::uint32_t>(scaled) << 24);
}

/**
 * @brief FNV-1a over the bytes that can change what is drawn.
 */
void hashCombine(std::uint64_t &hash, const void *data, std::size_t size) {
    const auto *bytes = static_cast<const unsigned char *>(data);
    for (std::size_t i = 0; i < size; ++i) {
        hash ^= bytes[i];
        hash *= 1099511628211ULL;
    }
}

void hashCombine(std::uint64_t &hash, std::uint64_t value) {
    hashCombine(hash, &value, sizeof(value));
}

void hashCombine(std::uint64_t &hash, std::string_view text) {
    hashCombine(hash, text.data(), text.size());
}

} // namespace

std::uint64_t HudRenderer::stateHash(
    const mc::ArmorPiece (&pieces)[mc::ArmorInventory::kSlotCount],
    const mod::ArmorHudConfig &config, const HudMetrics &metrics) const {
    std::uint64_t hash = 1469598103934665603ULL;
    hashCombine(hash, static_cast<std::uint64_t>(mHasSubmitted));

    for (const mc::ArmorPiece &piece : pieces) {
        hashCombine(hash, static_cast<std::uint64_t>(piece.present));
        hashCombine(hash, static_cast<std::uint64_t>(piece.current));
        hashCombine(hash, static_cast<std::uint64_t>(piece.maximum));
        hashCombine(hash, piece.name);
    }

    hashCombine(hash, static_cast<std::uint64_t>(config.lowDurabilityThreshold));
    hashCombine(hash, static_cast<std::uint64_t>(config.showDurabilityText));
    hashCombine(hash, static_cast<std::uint64_t>(config.textColor));
    hashCombine(hash, static_cast<std::uint64_t>(config.warningColor));
    hashCombine(hash, static_cast<std::uint64_t>(config.slotBackgroundColor));
    hashCombine(hash, static_cast<std::uint64_t>(config.warningBackgroundColor));

    hashCombine(hash, metrics.containerX);
    hashCombine(hash, metrics.containerY);
    hashCombine(hash, metrics.containerWidth);
    hashCombine(hash, metrics.containerHeight);
    hashCombine(hash, metrics.cellWidth);
    hashCombine(hash, metrics.cellHeight);
    hashCombine(hash, metrics.iconSize);
    hashCombine(hash, metrics.textSize);
    hashCombine(hash, metrics.textOffsetY);

    return hash;
}

void HudRenderer::render(
    const mc::ArmorPiece (&pieces)[mc::ArmorInventory::kSlotCount],
    const mc::ArmorInventory &inventory, const mod::ArmorHudConfig &config,
    pl::modmenu::HudSurfaceSize surface) {
    if (!config.enabled) {
        clear();
        return;
    }

    bool anyPresent = false;
    for (const mc::ArmorPiece &piece : pieces) {
        if (piece.present) {
            anyPresent = true;
            break;
        }
    }

    // An unready discovery is treated the same as nothing equipped, so the HUD
    // never shows slots filled from a stale layout.
    if (config.hideWhenEmpty && (!anyPresent || !inventory.ready())) {
        clear();
        return;
    }

    const HudMetrics metrics = computeMetrics(config, surface);
    const std::uint64_t hash = stateHash(pieces, config, metrics);
    if (mHasSubmitted && hash == mLastHash) return;

    mCommands.clear();
    mCommands.reserve(mc::ArmorInventory::kSlotCount * 4);

    for (int index = 0; index < mc::ArmorInventory::kSlotCount; ++index) {
        const mc::ArmorPiece &piece = pieces[index];
        const float cellX = metrics.containerX +
                            static_cast<float>(index) *
                                (metrics.cellWidth + metrics.cellSpacing);

        // A piece is low on durability when its remaining value has reached the
        // configured number of units. Both sides come straight from the game.
        const bool low = piece.present && piece.maximum > 0 &&
                         piece.current <= config.lowDurabilityThreshold;

        const std::uint32_t background =
            low ? config.warningBackgroundColor : config.slotBackgroundColor;
        pushRect(mCommands, cellX, metrics.containerY, metrics.cellWidth,
                 metrics.cellHeight, withAlpha(background, piece.present ? 1.0f : 0.45f));

        if (!piece.present) continue;

        if (icons::ensureRegistered(kSlotIcons[index], piece.name)) {
            const float iconX = cellX + (metrics.cellWidth - metrics.iconSize) * 0.5f;
            const float iconY =
                metrics.containerY + (metrics.cellHeight - metrics.iconSize) * 0.35f;
            pushImage(mCommands, iconX, iconY, metrics.iconSize, metrics.iconSize,
                      icons::imageId(kSlotIcons[index], piece.name));
        }

        if (!config.showDurabilityText) continue;

        std::string text = formatDurability(piece);
        if (low) text += " !";
        pushText(mCommands,
                 cellX + metrics.cellWidth * 0.5f,
                 metrics.containerY + metrics.textOffsetY, metrics.textSize,
                 low ? config.warningColor : config.textColor, std::move(text));
    }

    pl::modmenu::submitDrawCommands(kModuleId, mCommands);
    mLastHash = hash;
    mHasSubmitted = true;
    ++mSubmitCount;
}

void HudRenderer::publishEditorElements(pl::modmenu::HudSurfaceSize surface,
                                       const mod::ArmorHudConfig &config) {
    const HudMetrics metrics = computeMetrics(config, surface);

    pl::modmenu::HudEditorElement element;
    element.elementId = "armor_hud.root";
    element.displayName = "Armor HUD";
    // The editor writes these keys straight into the mod config file.
    element.positionKeyX = "anchorOffsetX";
    element.positionKeyY = "anchorOffsetY";
    element.x = metrics.containerX;
    element.y = metrics.containerY;
    element.width = metrics.containerWidth;
    element.height = metrics.containerHeight;
    element.snapThreshold = 12.0f;
    element.snapFlags = pl::modmenu::HudSnapElements;

    mEditorElements.clear();
    mEditorElements.push_back(element);
    pl::modmenu::submitHudEditorElements(kModuleId, mEditorElements);
}

void HudRenderer::clear() {
    if (!mHasSubmitted) return;
    mCommands.clear();
    pl::modmenu::submitDrawCommands(kModuleId, mCommands);
    mLastHash = 0;
    mHasSubmitted = false;
}

} // namespace armor_hud::hud