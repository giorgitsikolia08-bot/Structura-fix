#pragma once

#include <cstdint>
#include <string_view>
#include <vector>

#include <pl/ModMenu.hpp>

#include "hud/HudLayout.h"
#include "mc/ArmorInventory.h"

namespace armor_hud::hud {

/**
 * @brief Turns the four armour pieces into overlay draw commands.
 *
 * The renderer submits only when the visible state actually changes. The
 * overlay repaints on every game frame, so submitting unconditionally would
 * wake the compositor for nothing and cost battery.
 */
class HudRenderer {
public:
    /**
     * @brief Rebuilds and, if anything changed, submits the draw commands.
     *
     * Safe to call every frame.
     *
     * @param pieces the four armour pieces, index order matches ArmorSlot.
     * @param inventory discovery state, used only for its status.
     * @param config current settings.
     * @param surface current overlay size.
     */
    void render(const mc::ArmorPiece (&pieces)[mc::ArmorInventory::kSlotCount],
                const mc::ArmorInventory &inventory,
                const mod::ArmorHudConfig &config,
                pl::modmenu::HudSurfaceSize surface);

    /**
     * @brief Exposes the whole HUD as one draggable element in the in-game HUD
     *        editor.
     */
    void publishEditorElements(pl::modmenu::HudSurfaceSize surface,
                               const mod::ArmorHudConfig &config);

    /**
     * @brief Submits an empty command list, used when the HUD is hidden so the
     *        overlay can drop the last frame.
     */
    void clear();

    /**
     * @brief Number of times commands were actually submitted.
     */
    [[nodiscard]] std::uint64_t submitCount() const { return mSubmitCount; }

    /**
     * @brief Module id used for the Mod Menu overlay and HUD editor.
     */
    static constexpr std::string_view kModuleId = "armor_hud";

private:
    [[nodiscard]] std::uint64_t stateHash(
        const mc::ArmorPiece (&pieces)[mc::ArmorInventory::kSlotCount],
        const mod::ArmorHudConfig &config, const HudMetrics &metrics) const;

    std::vector<pl::modmenu::DrawCommand> mCommands;
    std::vector<pl::modmenu::HudEditorElement> mEditorElements;

    std::uint64_t mLastHash{0};
    bool mHasSubmitted{false};
    std::uint64_t mSubmitCount{0};
};

} // namespace armor_hud::hud