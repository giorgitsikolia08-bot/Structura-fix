#include <pl/Mod.hpp>

#include "mod/ArmorHudMod.h"

/**
 * @brief Registers the mod with the LeviLaunchroid preloader.
 *
 * The preloader looks up the "PLGetModRegistration" symbol after loading this
 * library, then drives the load/enable/disable/unload phases declared here.
 */
PL_REGISTER_MOD(armor_hud::mod::ArmorHudMod, armor_hud::mod::ArmorHudMod{})