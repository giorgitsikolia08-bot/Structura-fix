#include "mc/ArmorInventory.h"

#include "mc/GameApi.h"
#include "mc/ProcessMemory.h"
#include "mc/Rtti.h"

#include <algorithm>
#include <cstring>

namespace armor_hud::mc {
namespace {

using ProcessMemory = armor_hud::mc::ProcessMemory;

// A Player object on current 1.26.x clients is roughly 0x1400 bytes. Scanning a
// little past that costs nothing and covers growth in newer versions.
constexpr std::uintptr_t kPlayerScanSpan = 0x1800;

// Offsets examined per tick. At 20 ticks per second the whole player is
// covered in about 9 ticks (~0.45 s) after a rescan, which is imperceptible and
// keeps any single tick well under a millisecond.
constexpr std::uintptr_t kOffsetsPerTick = 128;

// Offsets examined inside a candidate container when looking for its slots.
constexpr std::uintptr_t kContainerSlotScanSpan = 0x100;

// ItemStack sizes considered when the slot array is a bare pointer with no
// matching end pointer.
constexpr std::uintptr_t kFallbackStrides[] = {
    0x40, 0x48, 0x50, 0x58, 0x60, 0x68, 0x70, 0x78, 0x80, 0x90, 0xA0, 0xC0};

// Bounds for a stride derived from a begin/end pair.
constexpr std::uintptr_t kMinDerivedStride = 0x20;
constexpr std::uintptr_t kMaxDerivedStride = 0x200;

// Consecutive failed validations before a rescan is triggered.
constexpr int kMaxValidationFailures = 30;

// Ticks to wait before retrying discovery after it came up empty, so a player
// with no armour does not rescan every frame.
constexpr std::uint32_t kRetryTicks = 40;

// A candidate must reach this score to be accepted.
constexpr int kMinimumScore = 20;

constexpr int kScoreIdentifierMatch = 100;
constexpr int kScoreArmorTypeName = 40;
constexpr int kScoreExactSlotCount = 20;
constexpr int kScoreOccupiedSlot = 5;
constexpr int kScoreEmptyContainer = 8;

bool endsWith(std::string_view text, std::string_view suffix) {
    return text.size() >= suffix.size() &&
           text.compare(text.size() - suffix.size(), suffix.size(), suffix) == 0;
}

} // namespace

std::string_view ArmorInventory::expectedItemSuffix(ArmorSlot slot) {
    switch (slot) {
        case ArmorSlot::Helmet:
            return "_helmet";
        case ArmorSlot::Chestplate:
            return "_chestplate";
        case ArmorSlot::Leggings:
            return "_leggings";
        case ArmorSlot::Boots:
            return "_boots";
        default:
            return {};
    }
}

void ArmorInventory::setStatus(const char *status) { mStatus = status; }

void ArmorInventory::invalidate() {
    mLayout = ArmorLayout{};
    mBest = Candidate{};
    mPhase = Phase::Idle;
    mScanOffset = 0;
    mValidationFailures = 0;
    mRetryCountdown = 0;
    setStatus("invalidated");
}

void ArmorInventory::resetScan() {
    mBest = Candidate{};
    mPhase = Phase::ScanningContainers;
    mScanOffset = 0;
    mValidationFailures = 0;
}

int ArmorInventory::scoreSlots(std::uintptr_t slotArray, std::uintptr_t stride,
                              bool exactSlotCount, bool armorishByName,
                              const Overrides &overrides,
                              int *outIdentifierMatches) {
    auto &memory = ProcessMemory::instance();

    int occupied = 0;
    int identifierMatches = 0;
    bool identifierKnown = false;

    for (int index = 0; index < kSlotCount; ++index) {
        const std::uintptr_t stack =
            slotArray + static_cast<std::uintptr_t>(index) * stride;

        // The stack must be aligned and mapped. A wrong stride lands outside
        // the container and is rejected right here.
        if ((stack & (itemstack::kAlignment - 1)) != 0) return -1;
        if (!memory.isReadable(stack, itemstack::kMinimumSpan)) return -1;

        const std::uintptr_t item = readItem(stack);
        if (item == 0) continue;  // empty slot

        // Anything occupying an armour slot must have durability. A different
        // value means this is not the armour container.
        if (itemMaxDamage(item, overrides.maxDamageVtableIndex) <= 0) return -1;

        ++occupied;

        const std::string identifier = readItemIdentifier(item);
        if (identifier.empty()) continue;
        identifierKnown = true;
        if (endsWith(stripNamespace(identifier),
                     expectedItemSuffix(static_cast<ArmorSlot>(index)))) {
            ++identifierMatches;
        }
    }

    if (occupied == 0) {
        // Nothing equipped. Only acceptable with a strong structural signal,
        // otherwise an unrelated empty container would be adopted.
        if (!armorishByName && !exactSlotCount) return -1;
        return kScoreEmptyContainer +
               (armorishByName ? kScoreArmorTypeName : 0) +
               (exactSlotCount ? kScoreExactSlotCount : 0);
    }

    int score = occupied * kScoreOccupiedSlot;
    if (armorishByName) score += kScoreArmorTypeName;
    if (exactSlotCount) score += kScoreExactSlotCount;
    if (outIdentifierMatches != nullptr) *outIdentifierMatches = identifierMatches;
    if (identifierKnown) {
        // All four suffixes matching is a near-certain identification.
        if (identifierMatches == kSlotCount) {
            score += kScoreIdentifierMatch;
        } else {
            // Once identifiers are known, a mismatch is evidence *against* the
            // layout, not merely a missed bonus. A wrong stride can revisit the
            // same item in several slots, which still counts as "occupied", so
            // without this penalty a misaligned array scores exactly like a
            // correct one and the tie is then broken arbitrarily.
            score += (identifierMatches * kScoreIdentifierMatch) /
                     static_cast<int>(kSlotCount);
            if (identifierMatches == 0) return -1;
        }
    }
    return score;
}

void ArmorInventory::considerSlotArray(std::uintptr_t begin,
                                       std::uintptr_t slotArrayOffset,
                                       bool armorishByName,
                                       const Overrides &overrides) {
    auto &memory = ProcessMemory::instance();

    // A candidate replaces the incumbent only when it scores strictly better,
    // or when it scores the same but confirms more of the slot order. Two
    // candidates frequently reach an identical score through different
    // evidence -- a begin/end span can accidentally divide into four strides
    // for an array that is not the armour container -- so the number of
    // suffixes confirmed in order is the deciding signal.
    const auto better = [this](int score, int matches) {
        if (score != mBest.score) return score > mBest.score;
        return matches > mBest.identifierMatches;
    };

    // Strong hypothesis: a begin/end pair whose span is exactly four strides.
    // This proves the stride and the slot count at the same time.
    std::uintptr_t end = 0;
    if (memory.read(mBest.slotArrayBase + slotArrayOffset + sizeof(void *), end) &&
        end > begin) {
        const std::uintptr_t span = end - begin;
        if (span % static_cast<std::uintptr_t>(kSlotCount) == 0) {
            const std::uintptr_t stride = span / static_cast<std::uintptr_t>(kSlotCount);
            if (stride >= kMinDerivedStride && stride <= kMaxDerivedStride &&
                (stride % sizeof(void *)) == 0) {
                int matches = 0;
                const int score = scoreSlots(begin, stride, true, armorishByName,
                                             overrides, &matches);
                if (better(score, matches)) {
                    mBest.slotArrayOffset = slotArrayOffset;
                    mBest.slotStride = stride;
                    mBest.exactSlotCount = true;
                    mBest.identifierMatches = matches;
                    mBest.score = score;
                }
            }
        }
    }

    // Weak hypothesis: a bare slot pointer with no end pointer alongside it.
    for (const std::uintptr_t stride : kFallbackStrides) {
        int matches = 0;
        const int score =
            scoreSlots(begin, stride, false, armorishByName, overrides, &matches);
        if (better(score, matches)) {
            mBest.slotArrayOffset = slotArrayOffset;
            mBest.slotStride = stride;
            mBest.exactSlotCount = false;
            mBest.identifierMatches = matches;
            mBest.score = score;
        }
    }
}

void ArmorInventory::tryContainer(std::uintptr_t container,
                                  const Overrides &overrides) {
    auto &memory = ProcessMemory::instance();

    const std::string typeName = rtti::className(container);
    const bool armorishByName = typeName.find("Armor") != std::string::npos;

    for (std::uintptr_t offset = 0; offset < kContainerSlotScanSpan;
         offset += sizeof(void *)) {
        std::uintptr_t begin = 0;
        if (!memory.read(container + offset, begin)) continue;
        if (begin == 0) continue;
        if ((begin & (itemstack::kAlignment - 1)) != 0) continue;
        if (!memory.isPlausiblePointer(begin)) continue;

        mBest.slotArrayBase = container;
        considerSlotArray(begin, offset, armorishByName, overrides);
    }
}

bool ArmorInventory::scanSlice(std::uintptr_t player,
                               const Overrides &overrides) {
    auto &memory = ProcessMemory::instance();

    // mBest deliberately survives between slices. The scan is deliberately
    // spread over several ticks, so the strongest candidate found early on
    // would otherwise be discarded by the next slice, and a weak match in the
    // first slice would be adopted before the rest of the player was examined.
    const std::uintptr_t sliceEnd =
        std::min(mScanOffset + kOffsetsPerTick, kPlayerScanSpan);

    for (std::uintptr_t offset = mScanOffset; offset < sliceEnd;
         offset += sizeof(void *)) {
        // Each candidate is scored into a scratch Candidate so a later, weaker
        // match cannot erase an earlier, stronger one.
        Candidate previousBest = mBest;

        // Case A: a pointer member that references a sub-object.
        std::uintptr_t pointer = 0;
        if (memory.read(player + offset, pointer) &&
            rtti::hasGameVtable(pointer)) {
            mBest = Candidate{};
            mBest.containerAddress = pointer;
            mBest.containerIsIndirect = true;
            tryContainer(pointer, overrides);
            if (mBest.score < previousBest.score ||
                (mBest.score == previousBest.score &&
                 mBest.identifierMatches <= previousBest.identifierMatches)) {
                mBest = previousBest;
            }
        }

        // Case B: an inline sub-object, so the address itself starts with a
        // vtable pointer.
        previousBest = mBest;
        if (rtti::hasGameVtable(player + offset)) {
            mBest = Candidate{};
            mBest.containerAddress = player + offset;
            tryContainer(player + offset, overrides);
            if (mBest.score < previousBest.score ||
                (mBest.score == previousBest.score &&
                 mBest.identifierMatches <= previousBest.identifierMatches)) {
                mBest = previousBest;
            }
        }
    }

    mScanOffset = sliceEnd;

    // Commit only once the whole player has been scanned. A partial pass can
    // only ever see a subset of the candidates, so a layout adopted mid-scan is
    // adopted on incomplete evidence.
    if (mScanOffset < kPlayerScanSpan) {
        return false;
    }

    if (mBest.score >= kMinimumScore) {
        mLayout.containerIsIndirect = mBest.containerIsIndirect;
        if (mBest.containerIsIndirect) {
            mLayout.containerIndirect = mBest.containerAddress;
            mLayout.containerOffset = 0;
        } else {
            mLayout.containerOffset = mBest.containerAddress - player;
        }
        mLayout.slotArrayOffset = mBest.slotArrayOffset;
        mLayout.slotStride = mBest.slotStride;
        mLayout.exactSlotCount = mBest.exactSlotCount;
        mLayout.valid = true;
        mPhase = Phase::Ready;
        ++mDiscoveries;
        setStatus("ready");
        return true;
    }

    if (mScanOffset >= kPlayerScanSpan) {
        mPhase = Phase::Idle;
        mRetryCountdown = kRetryTicks;
        setStatus("no armour container found yet");
    }
    return false;
}

bool ArmorInventory::tick(std::uintptr_t player, const Overrides &overrides) {
    if (player == 0) {
        invalidate();
        setStatus("no local player");
        return false;
    }

    // Manual overrides short-circuit discovery entirely. This is the escape
    // hatch for a game build where automatic discovery cannot succeed.
    if (overrides.containerOffset > 0 && overrides.slotArrayOffset >= 0 &&
        overrides.slotStride > 0) {
        mLayout.containerOffset =
            static_cast<std::uintptr_t>(overrides.containerOffset);
        mLayout.slotArrayOffset =
            static_cast<std::uintptr_t>(overrides.slotArrayOffset);
        mLayout.slotStride = static_cast<std::uintptr_t>(overrides.slotStride);
        mLayout.exactSlotCount = false;
        mLayout.valid = true;
        setStatus("using configured offsets");
        return true;
    }

    if (mLayout.valid) {
        // Steady state: re-validate every tick. A layout that stops matching
        // repairs itself instead of displaying stale data.
        const std::uintptr_t container = mLayout.containerAddress(player);
        std::uintptr_t slotArray = 0;
        const bool readable =
            rtti::hasGameVtable(container) &&
            ProcessMemory::instance().read(container + mLayout.slotArrayOffset,
                                           slotArray);
        if (readable && slotArray != 0 &&
            scoreSlots(slotArray, mLayout.slotStride, mLayout.exactSlotCount,
                       false, overrides) >= 0) {
            mValidationFailures = 0;
            return true;
        }
        if (++mValidationFailures > kMaxValidationFailures) {
            invalidate();
            setStatus("layout invalidated, rescanning");
        }
        return false;
    }

    if (mPhase == Phase::Idle) {
        if (mRetryCountdown > 0) {
            --mRetryCountdown;
            return false;
        }
        resetScan();
    }

    return scanSlice(player, overrides);
}

void ArmorInventory::read(ArmorPiece (&out)[kSlotCount],
                          const Overrides &overrides) const {
    for (int index = 0; index < kSlotCount; ++index) out[index] = ArmorPiece{};

    if (!mLayout.valid) return;

    const std::uintptr_t player = GameApi::instance().localPlayer();
    if (player == 0) return;

    const std::uintptr_t container = mLayout.containerAddress(player);
    std::uintptr_t slotArray = 0;
    if (!ProcessMemory::instance().read(container + mLayout.slotArrayOffset,
                                        slotArray)) {
        return;
    }
    if (slotArray == 0) return;

    for (int index = 0; index < kSlotCount; ++index) {
        const std::uintptr_t stack =
            slotArray + static_cast<std::uintptr_t>(index) * mLayout.slotStride;
        out[index] = readArmorPiece(stack, overrides.maxDamageVtableIndex);
    }
}

} // namespace armor_hud::mc
