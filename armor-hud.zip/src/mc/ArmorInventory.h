#pragma once

#include <cstdint>
#include <string_view>

#include "mc/ItemStack.h"

namespace armor_hud::mc {

/**
 * @brief Armour slot indices, in the order Bedrock stores them.
 */
enum class ArmorSlot : std::size_t {
    Helmet = 0,
    Chestplate = 1,
    Leggings = 2,
    Boots = 3,
    Count = 4,
};

/**
 * @brief Where the four armour stacks live inside a player object.
 *
 * None of these numbers are hard-coded. They are recovered at runtime by
 * scanning the player object and validating every candidate, so the same build
 * keeps working when a Minecraft update shifts the layout.
 */
struct ArmorLayout {
    bool valid{};
    // Offset from the player object to the armour container, valid only when
    // containerIsIndirect is false. An inline sub-object lives at
    // player + containerOffset.
    std::uintptr_t containerOffset{};
    // True when the container is reached through a pointer member of the
    // player rather than being embedded in it. In that case containerIndirect
    // holds the *absolute* address found during discovery, and containerOffset
    // is meaningless. Both forms occur: a pointer member must never be recorded
    // as an offset, because an absolute heap address added to the player base
    // yields a wild address outside the object.
    bool containerIsIndirect{};
    std::uintptr_t containerIndirect{};
    // Offset from the container to the slot array.
    std::uintptr_t slotArrayOffset{};
    // Distance between two consecutive ItemStack entries.
    std::uintptr_t slotStride{};
    // True when the slot array was found as a begin/end pair, which also
    // proves the container holds exactly four slots.
    bool exactSlotCount{};

    [[nodiscard]] std::uintptr_t containerAddress(std::uintptr_t player) const {
        return containerIsIndirect ? containerIndirect : player + containerOffset;
    }
};

/**
 * @brief Locates and reads the player's four armour slots.
 *
 * Discovery is incremental: each tick performs a bounded slice of the scan so
 * the game never stalls, and the discovered layout is re-validated every tick.
 * If validation keeps failing the scan restarts automatically, which is what
 * lets the mod survive respawn, dimension change, world change and game
 * restarts with no manual step.
 */
class ArmorInventory {
public:
    static constexpr int kSlotCount = static_cast<int>(ArmorSlot::Count);

    /**
     * @brief Overrides that let a user fix a broken discovery without
     *        rebuilding. A value of 0 (or -1) means "detect automatically".
     */
    struct Overrides {
        long long containerOffset{-1};
        long long slotArrayOffset{-1};
        long long slotStride{0};
        std::size_t maxDamageVtableIndex{itemstack::kDefaultMaxDamageVtableIndex};
    };

    /**
     * @brief Runs one bounded slice of work. Safe to call every tick.
     * @param player local player address, or 0 when there is none.
     * @return true when the layout is currently usable.
     */
    bool tick(std::uintptr_t player, const Overrides &overrides);

    /**
     * @brief Reads the four armour pieces. Requires a valid layout.
     */
    void read(ArmorPiece (&out)[kSlotCount], const Overrides &overrides) const;

    [[nodiscard]] bool ready() const { return mLayout.valid; }
    [[nodiscard]] const ArmorLayout &layout() const { return mLayout; }

    /**
     * @brief Forgets the discovered layout so the next tick rescans.
     */
    void invalidate();

    /**
     * @brief Number of successful discoveries, for the launcher log.
     */
    [[nodiscard]] std::uint32_t discoveryCount() const { return mDiscoveries; }

    /**
     * @brief Human-readable description of the current state, for logging.
     */
    [[nodiscard]] const char *lastStatus() const { return mStatus; }

    /**
     * @brief Expected item-name suffix for a slot, used to validate a
     *        discovered container.
     */
    static std::string_view expectedItemSuffix(ArmorSlot slot);

private:
    enum class Phase : std::uint8_t {
        Idle,
        ScanningContainers,
        Ready,
    };

    struct Candidate {
        // Address of the container being examined right now.
        std::uintptr_t containerAddress{};
        // True when containerAddress came from a pointer member of the player
        // rather than from an inline sub-object. Only inline containers can be
        // expressed as player + offset.
        bool containerIsIndirect{};
        // The container address whose member the slot pointer was read from.
        std::uintptr_t slotArrayBase{};
        std::uintptr_t slotArrayOffset{};
        std::uintptr_t slotStride{};
        bool exactSlotCount{};
        // Number of armour suffixes confirmed in order. Used to break score
        // ties: two candidates can reach the same score through different
        // evidence, and the one that actually confirmed the slot order wins.
        int identifierMatches{};
        int score{};
    };

    void setStatus(const char *status);
    void resetScan();
    bool scanSlice(std::uintptr_t player, const Overrides &overrides);
    void tryContainer(std::uintptr_t container, const Overrides &overrides);
    void considerSlotArray(std::uintptr_t begin, std::uintptr_t slotArrayOffset,
                           bool armorishByName, const Overrides &overrides);
    static int scoreSlots(std::uintptr_t slotArray, std::uintptr_t stride,
                          bool exactSlotCount, bool armorishByName,
                          const Overrides &overrides,
                          int *outIdentifierMatches = nullptr);

    ArmorLayout mLayout{};
    Candidate mBest{};
    Phase mPhase{Phase::Idle};

    // Player object scan cursor.
    std::uintptr_t mScanOffset{};
    // Consecutive failed validations before a rescan is triggered.
    int mValidationFailures{};
    // Ticks to wait before retrying a scan that came up empty.
    std::uint32_t mRetryCountdown{};

    std::uint32_t mDiscoveries{0};
    const char *mStatus{"idle"};
};

} // namespace armor_hud::mc
