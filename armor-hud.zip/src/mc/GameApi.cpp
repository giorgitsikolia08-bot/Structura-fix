#include "mc/GameApi.h"

#include "mc/ProcessMemory.h"
#include "mc/Rtti.h"

#include <pl/memory/Signature.hpp>

namespace armor_hud::mc {
namespace {

constexpr const char *kMinecraftLibrary = "libminecraftpe.so";

// ---------------------------------------------------------------------------
// Byte signatures.
//
// Taken from a mod verified against current 1.26.x arm64 clients. '?' matches
// any single byte. These are the only version-dependent artefacts in the mod.
// ---------------------------------------------------------------------------

// void LocalPlayer::tick(...) -- first argument is the local player.
constexpr const char *kNormalTickSignature =
    "E8 0F 19 FC FD 7B 01 A9 FC 6F 02 A9 FA 67 03 A9 F8 5F 04 A9 F6 57 05 A9 "
    "F4 4F 06 A9 FD 43 00 91 FF C3 09 D1 54 D0 3B D5 F3 03 00 AA 88 16 40 F9 "
    "A8 03 1E F8 08 C0 78 39 ? ? ? ? 68 92 4C B9";

// void* ClientInstance::update(ClientInstance*, bool)
constexpr const char *kClientInstanceUpdateSignature =
    "FD 7B BA A9 FC 6F 01 A9 FA 67 02 A9 F8 5F 03 A9 F6 57 04 A9 F4 4F 05 A9 "
    "FD 03 00 91 FF C3 12 D1 59 D0 3B D5 F3 03 00 AA F4 03 01 2A 28 17 40 F9 "
    "A8 83 1F F8 08 00 40 F9 09 35 46 F9 E8 E3 01 91";

// Player* ClientInstance::getLocalPlayer(ClientInstance*)
constexpr const char *kClientInstanceGetLocalPlayerSignature =
    "FF 43 01 D1 FD 7B 03 A9 F3 23 00 F9 FD C3 00 91 53 D0 3B D5 E8 03 00 AA E0 23 "
    "00 91 69 16 40 F9 01 61 08 91 A9 83 1F F8 ? ? ? ? E0 23 00 91 ? ? ? ? ? ? ? ? "
    "E0 23 00 91 21 00 80 52 ? ? ? ? ? ? ? ? E0 03 1F AA 68 16 40 F9 A9 83 5F F8 1F "
    "01 09 EB ? ? ? ? FD 7B 43 A9";

// short ItemStackBase::getDamageValue(ItemStackBase const*)
// Called directly, never hooked.
constexpr const char *kItemStackBaseGetDamageValueSignature =
    "FF 43 01 D1 FD 7B 02 A9 F6 57 03 A9 F4 4F 04 A9 FD 83 00 91 55 D0 3B D5 "
    "A9 16 40 F9 A9 83 1F F8 09 04 40 F9 ? ? ? ? 29 01 40 F9 ? ? ? ? E8 03 00 "
    "AA 00 08 40 F9 F3 03 01 2A ? ? ? ?";

using TickFn = void (*)(void *actor);
using ClientUpdateFn = void *(*)(void *clientInstance, bool value);
using GetLocalPlayerFn = void *(*)(void *clientInstance);
using GetDamageValueFn = short (*)(void *itemStack);

TickFn gTickOriginal = nullptr;
ClientUpdateFn gClientUpdateOriginal = nullptr;

void tickDetour(void *actor) {
    if (gTickOriginal != nullptr) gTickOriginal(actor);
    GameApi::instance().onLocalPlayerTick(reinterpret_cast<std::uintptr_t>(actor));
}

void *clientUpdateDetour(void *clientInstance, bool value) {
    void *result = gClientUpdateOriginal != nullptr
                       ? gClientUpdateOriginal(clientInstance, value)
                       : nullptr;
    GameApi::instance().onClientInstanceUpdate(
        reinterpret_cast<std::uintptr_t>(clientInstance));
    return result;
}

} // namespace

GameApi &GameApi::instance() {
    static GameApi api;
    return api;
}

void GameApi::resolveSignatures() {
    mSlots[0] = SignatureSlot{"NormalTick", 0, false};
    mSlots[1] = SignatureSlot{"ClientInstanceUpdate", 0, false};
    mSlots[2] = SignatureSlot{"ClientInstanceGetLocalPlayer", 0, false};
    mSlots[3] = SignatureSlot{"ItemStackBaseGetDamageValue", 0, false};

    mSlots[0].address = pl::memory::resolveSignature(kNormalTickSignature,
                                                    kMinecraftLibrary);
    mSlots[1].address = pl::memory::resolveSignature(
        kClientInstanceUpdateSignature, kMinecraftLibrary);
    mSlots[2].address = pl::memory::resolveSignature(
        kClientInstanceGetLocalPlayerSignature, kMinecraftLibrary);
    mSlots[3].address = pl::memory::resolveSignature(
        kItemStackBaseGetDamageValueSignature, kMinecraftLibrary);

    for (SignatureSlot &slot : mSlots) {
        slot.resolved = slot.address != 0;
    }

    mClientInstanceGetLocalPlayer = mSlots[2].address;
    mItemStackBaseGetDamageValue = mSlots[3].address;
}

bool GameApi::install() {
    if (mInstalled.load(std::memory_order_acquire)) return true;

    resolveSignatures();

    if (!mSlots[0].resolved) {
        // Without the tick hook there is no player object and no HUD.
        return false;
    }

    mTickHook = pl::memory::HookHandle(reinterpret_cast<void *>(mSlots[0].address),
                                       reinterpret_cast<void *>(&tickDetour),
                                       reinterpret_cast<void **>(&gTickOriginal));
    if (!mTickHook.installed()) return false;

    if (mSlots[1].resolved) {
        mClientHook = pl::memory::HookHandle(
            reinterpret_cast<void *>(mSlots[1].address),
            reinterpret_cast<void *>(&clientUpdateDetour),
            reinterpret_cast<void **>(&gClientUpdateOriginal));
    }

    mInstalled.store(true, std::memory_order_release);
    return true;
}

void GameApi::uninstall() {
    mTickHook.reset();
    mClientHook.reset();
    mLocalPlayer.store(0, std::memory_order_release);
    mClientInstance.store(0, std::memory_order_release);
    mTickCount.store(0, std::memory_order_relaxed);
    mInstalled.store(false, std::memory_order_release);
    mTickCallback = nullptr;
    mTickCallbackContext = nullptr;
    mClientInstanceGetLocalPlayer = 0;
    mItemStackBaseGetDamageValue = 0;
}

std::uintptr_t GameApi::queryLocalPlayerFromClient() const {
    if (mClientInstanceGetLocalPlayer == 0) return 0;
    const std::uintptr_t client = clientInstance();
    if (client == 0) return 0;

    const auto fn = reinterpret_cast<GetLocalPlayerFn>(
        mClientInstanceGetLocalPlayer);
    return reinterpret_cast<std::uintptr_t>(fn(reinterpret_cast<void *>(client)));
}

int GameApi::itemStackDamage(std::uintptr_t itemStack) const {
    if (mItemStackBaseGetDamageValue == 0 || itemStack == 0) return -1;
    if (!ProcessMemory::instance().isReadable(itemStack, 0x30)) return -1;
    const auto fn = reinterpret_cast<GetDamageValueFn>(mItemStackBaseGetDamageValue);
    return static_cast<int>(fn(reinterpret_cast<void *>(itemStack)));
}

const SignatureSlot *GameApi::signatures(std::size_t &count) const {
    count = 4;
    return mSlots;
}

std::string GameApi::describeSignatures() const {
    std::size_t count = 0;
    const SignatureSlot *slots = signatures(count);

    std::string result;
    for (std::size_t i = 0; i < count; ++i) {
        if (i != 0) result += ", ";
        result += slots[i].name;
        result += slots[i].resolved ? "=ok" : "=MISSING";
    }
    return result;
}

void GameApi::setTickCallback(TickCallback callback, void *context) {
    mTickCallback = callback;
    mTickCallbackContext = context;
}

void GameApi::onLocalPlayerTick(std::uintptr_t player) {
    mTickCount.fetch_add(1, std::memory_order_relaxed);
    if (player == 0) return;

    // A tick hook on a stale pointer means the world was torn down. Re-validate
    // cheaply: the object must still carry a Minecraft vtable.
    if (!rtti::hasGameVtable(player)) {
        mLocalPlayer.store(0, std::memory_order_release);
        return;
    }
    mLocalPlayer.store(player, std::memory_order_release);

    // Run after the pointer is refreshed so the callback always sees a player
    // that just proved valid this tick.
    if (mTickCallback != nullptr) mTickCallback(mTickCallbackContext);
}

void GameApi::onClientInstanceUpdate(std::uintptr_t clientInstance) {
    if (clientInstance == 0) return;
    mClientInstance.store(clientInstance, std::memory_order_release);
}

void GameApi::forget() {
    mLocalPlayer.store(0, std::memory_order_release);
    mClientInstance.store(0, std::memory_order_release);
}

} // namespace armor_hud::mc
