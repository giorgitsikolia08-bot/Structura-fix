#pragma once

#include <atomic>
#include <cstdint>
#include <string>

#include <pl/memory/Hook.hpp>

namespace armor_hud::mc {

/**
 * @brief Result of resolving one Minecraft signature.
 */
struct SignatureSlot {
    std::string name;
    std::uintptr_t address{};
    bool resolved{};
};

/**
 * @brief Owns the Minecraft byte signatures and the hooks installed on them.
 *
 * Everything version-specific lives here. The patterns below were taken from a
 * mod that is known to run against current 1.26.x arm64 clients; if a future
 * Minecraft release changes the surrounding code they stop resolving, the mod
 * reports that in the launcher log, and only the pattern needs replacing.
 *
 * Hooks used:
 *   - NormalTick               -> first argument is the local player. This is
 *                                  the primary source of the player object and
 *                                  it is already on the game thread, so no
 *                                  cross-thread coordination is needed.
 *   - ClientInstanceUpdate     -> captures ClientInstance as a cross-check and
 *                                  as a fallback way to reach the player.
 *   - ItemStackBaseGetDamageValue -> read-only call, never hooked.
 */
class GameApi {
public:
    static GameApi &instance();

    /**
     * @brief Resolves signatures and installs hooks. Safe to call once.
     * @return false when the mandatory NormalTick hook could not be installed,
     *         in which case the mod cannot function.
     */
    bool install();

    /**
     * @brief Removes hooks and clears cached state.
     */
    void uninstall();

    [[nodiscard]] bool installed() const { return mInstalled; }

    /**
     * @brief Most recently observed local player, or 0.
     */
    [[nodiscard]] std::uintptr_t localPlayer() const {
        return mLocalPlayer.load(std::memory_order_acquire);
    }

    [[nodiscard]] std::uintptr_t clientInstance() const {
        return mClientInstance.load(std::memory_order_acquire);
    }

    /**
     * @brief Calls the recovered ClientInstance::getLocalPlayer when available.
     * @return 0 when the signature is missing or the call is unavailable.
     */
    [[nodiscard]] std::uintptr_t queryLocalPlayerFromClient() const;

    /**
     * @brief Reads ItemStackBase::getDamage(): durability already consumed.
     *
     * Minecraft stores durability as damage, so remaining durability is
     * maxDamage - damage. Returns a negative value when the value could not be
     * read.
     */
    [[nodiscard]] int itemStackDamage(std::uintptr_t itemStack) const;

    /**
     * @brief Reports which signatures resolved, for the launcher log.
     */
    [[nodiscard]] const SignatureSlot *signatures(std::size_t &count) const;

    /**
     * @brief One-line summary of which signatures resolved, for logging.
     */
    [[nodiscard]] std::string describeSignatures() const;

    /**
     * @brief Invoked on the game thread once per local player tick, after the
     *        player pointer has been refreshed.
     *
     * This is how the HUD stays event-driven: it is only recomputed when the
     * game actually ticks, never on a timer of its own. The callback is stored
     * as a plain function pointer because it is only ever installed and
     * cleared from the mod lifecycle, which runs before any hook fires.
     */
    using TickCallback = void (*)(void *context);

    void setTickCallback(TickCallback callback, void *context = nullptr);

    /**
     * @brief Drops the cached player and client pointers.
     *
     * Called on world/dimension transitions and when leaving gameplay so a
     * stale pointer from a previous world is never dereferenced.
     */
    void forget();

    /**
     * @brief Number of ticks observed since install(). Used to pace scanning.
     */
    [[nodiscard]] std::uint64_t tickCount() const {
        return mTickCount.load(std::memory_order_relaxed);
    }

    /**
     * @brief Hook entry point invoked on the game thread every local player
     *        tick. Public so the detour can forward to it.
     */
    void onLocalPlayerTick(std::uintptr_t player);

    /**
     * @brief Hook entry point for ClientInstance::update.
     */
    void onClientInstanceUpdate(std::uintptr_t clientInstance);

private:
    GameApi() = default;

    void resolveSignatures();

    pl::memory::HookHandle mTickHook;
    pl::memory::HookHandle mClientHook;

    std::atomic<std::uintptr_t> mLocalPlayer{0};
    std::atomic<std::uintptr_t> mClientInstance{0};
    std::atomic<std::uint64_t> mTickCount{0};
    std::atomic<bool> mInstalled{false};

    // Tick callback, installed by the mod lifecycle. A plain function pointer
    // plus context keeps this header free of <functional> and avoids any
    // allocation on the tick path.
    TickCallback mTickCallback{};
    void *mTickCallbackContext{};

    std::uintptr_t mClientInstanceGetLocalPlayer{};
    std::uintptr_t mItemStackBaseGetDamageValue{};
    SignatureSlot mSlots[5]{};
};

} // namespace armor_hud::mc
