#include "mc/ItemStack.h"

#include "mc/GameApi.h"
#include "mc/ProcessMemory.h"
#include "mc/Rtti.h"

#include <pl/memory/Vtable.hpp>

#include <algorithm>
#include <array>
#include <cctype>
#include <cstring>

namespace armor_hud::mc {
namespace {

using ProcessMemory = armor_hud::mc::ProcessMemory;
using GameApi = armor_hud::mc::GameApi;

constexpr const char *kMinecraftLibrary = "libminecraftpe.so";

// libc++ std::string with the default allocator is 24 bytes:
//   long form  : { char* data; size_t size; size_t cap_and_flags; }
//   short form : { char data[22]; uint8_t size_and_flags; uint8_t flags; }

// A namespaced Minecraft identifier is at most 96 characters in practice.
constexpr std::size_t kMaxIdentifierLength = 96;

// The Item object is scanned for its identifier. 0x200 covers the region where
// the name and the runtime id live on current 1.26.x clients.
constexpr std::uintptr_t kIdentifierScanSpan = 0x200;

// Cache keyed on the item pointer. Item objects are stable for the lifetime of
// the item, so an identifier only has to be recovered once per equipped piece.
std::string &identifierCacheSlot(std::uintptr_t item) {
    struct Entry {
        std::uintptr_t key{};
        std::string value;
    };
    static std::array<Entry, 16> cache{};
    static_assert(std::size(cache) > 0);

    const std::size_t index = static_cast<std::size_t>((item >> 4) & 0xF);
    Entry &entry = cache[index];
    if (entry.key != item) {
        entry.key = item;
        entry.value.clear();
    }
    return entry.value;
}

bool isIdentifierChar(char ch) {
    const auto value = static_cast<unsigned char>(ch);
    return std::isalnum(value) != 0 || ch == '_' || ch == '-' || ch == '.' ||
           ch == '/';
}

bool looksLikeIdentifier(const char *text, std::size_t length) {
    // Needs a namespace separator, otherwise unrelated strings match.
    const std::size_t colon = [&]() -> std::size_t {
        for (std::size_t index = 0; index < length; ++index) {
            if (text[index] == ':') return index;
        }
        return std::string::npos;
    }();
    if (colon == std::string::npos || colon == 0) return false;
    if (colon + 1 >= length) return false;

    for (std::size_t index = 0; index < length; ++index) {
        if (!isIdentifierChar(text[index]) && text[index] != ':') return false;
    }
    return true;
}

/**
 * @brief Reads a NUL-terminated, identifier-shaped string out of a buffer.
 * @return the length, or 0 when the buffer does not hold such a string.
 */
std::size_t matchIdentifier(const char *text, std::size_t maxLength) {
    constexpr std::size_t kMinimumIdentifierLength = 5;
    for (std::size_t length = kMinimumIdentifierLength + 1; length <= maxLength;
         ++length) {
        const char ch = text[length - 1];
        if (ch == '\0') {
            // The terminator sits at length-1, so the identifier itself is
            // length-1 characters long. Validating `length` characters would
            // always inspect the NUL and reject every identifier.
            return looksLikeIdentifier(text, length - 1) ? length - 1 : 0;
        }
        if (!isIdentifierChar(ch) && ch != ':') return 0;
    }
    return 0;
}

} // namespace

std::uintptr_t readItem(std::uintptr_t itemStack) {
    if (itemStack == 0) return 0;
    auto &memory = ProcessMemory::instance();

    // Cheap rejection first: a valid stack is aligned and has a readable body.
    if ((itemStack & (itemstack::kAlignment - 1)) != 0) return 0;
    if (!memory.isReadable(itemStack, itemstack::kMinimumSpan)) return 0;

    std::uintptr_t reference = 0;
    if (!memory.read(itemStack + itemstack::kReferenceBlock, reference)) return 0;
    if (reference == 0) return 0;
    if (!memory.isPlausiblePointer(reference)) return 0;

    std::uintptr_t item = 0;
    if (!memory.read(reference + itemstack::kItemInReferenceBlock, item)) return 0;
    if (item == 0) return 0;

    // The Item must be a Minecraft object, otherwise this is not a stack.
    if (!rtti::hasGameVtable(item)) return 0;
    return item;
}

bool isEmpty(std::uintptr_t itemStack) {
    return readItem(itemStack) == 0;
}

int itemMaxDamage(std::uintptr_t item, std::size_t vtableIndex) {
    if (item == 0) return 0;

    // Only call into a slot that really holds a Minecraft function pointer.
    const std::uintptr_t function = rtti::vtableFunction(item, vtableIndex);
    if (function == 0 || !rtti::isGameCodePointer(function)) return 0;

    using MaxDamageFn = std::int16_t (*)(void *item);
    const auto fn = reinterpret_cast<MaxDamageFn>(function);
    const auto value = static_cast<int>(fn(reinterpret_cast<void *>(item)));

    // Bedrock armour never exceeds a few thousand durability. A wild value
    // means the slot index is wrong for this build.
    if (value <= 0 || value > 100000) return 0;
    return value;
}

std::uintptr_t verifyMaxDamageVtableIndex(std::size_t vtableIndex) {
    return pl::memory::resolveVtableFunction("4Item", vtableIndex,
                                             kMinecraftLibrary);
}

std::string readItemIdentifier(std::uintptr_t item) {
    if (item == 0) return {};

    std::string &cached = identifierCacheSlot(item);
    if (!cached.empty()) return cached;

    auto &memory = ProcessMemory::instance();

    // The identifier is found by looking for a pointer to a string that has the
    // shape of a namespaced Minecraft name, and for a copy stored inline in the
    // object. Neither assumption depends on the layout of std::string or of
    // HashedString, so this keeps working when those layouts change.
    char buffer[kMaxIdentifierLength + 2];

    for (std::uintptr_t offset = 0; offset < kIdentifierScanSpan;
         offset += sizeof(void *)) {
        // Case 1: a pointer member that references the identifier.
        std::uintptr_t data = 0;
        if (memory.read(item + offset, data) && data != 0 &&
            memory.isReadable(data, sizeof(buffer))) {
            if (memory.readBytes(data, buffer, sizeof(buffer))) {
                const std::size_t length = matchIdentifier(buffer, kMaxIdentifierLength);
                if (length != 0) {
                    cached.assign(buffer, length);
                    return cached;
                }
            }
        }

        // Case 2: the identifier stored inline in the object.
        if (memory.readBytes(item + offset, buffer, sizeof(buffer))) {
            const std::size_t length = matchIdentifier(buffer, kMaxIdentifierLength);
            if (length != 0) {
                cached.assign(buffer, length);
                return cached;
            }
        }
    }
    return {};
}

std::string_view stripNamespace(std::string_view identifier) {
    const std::size_t colon = identifier.find(':');
    if (colon == std::string_view::npos) return identifier;
    return identifier.substr(colon + 1);
}

ArmorPiece readArmorPiece(std::uintptr_t itemStack,
                          std::size_t maxDamageVtableIndex) {
    ArmorPiece piece;

    const std::uintptr_t item = readItem(itemStack);
    if (item == 0) return piece;

    piece.item = item;
    piece.stack = itemStack;

    const int maximum = itemMaxDamage(item, maxDamageVtableIndex);
    if (maximum <= 0) {
        // An item without durability cannot occupy an armour slot. Treat it as
        // unusable rather than displaying a fabricated number.
        return piece;
    }

    int damage = GameApi::instance().itemStackDamage(itemStack);
    if (damage < 0) {
        damage = 0;
    }
    if (damage > maximum) {
        // Defensive clamp: never display more damage than the item can take.
        damage = maximum;
    }

    piece.present = true;
    piece.maximum = maximum;
    piece.damage = damage;
    piece.current = maximum - damage;
    piece.name = readItemIdentifier(item);
    return piece;
}

} // namespace armor_hud::mc
