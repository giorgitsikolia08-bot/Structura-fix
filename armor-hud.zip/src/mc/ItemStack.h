#pragma once

#include <cstdint>
#include <string>
#include <string_view>

namespace armor_hud::mc {

/**
 * @brief Offsets inside ItemStackBase.
 *
 * Bedrock stores the item as a reference-counted indirection:
 *
 *   ItemStackBase + 0x00  vtable
 *   ItemStackBase + 0x08  pointer to the reference block
 *   reference block + 0x00  Item const*
 *   ItemStackBase + 0x10  user data (CompoundTag*), may be null
 *
 * These values match the layout used by other working LeviLauncher mods on
 * current 1.26.x arm64 clients.
 */
namespace itemstack {
inline constexpr std::uintptr_t kReferenceBlock = 0x08;
inline constexpr std::uintptr_t kItemInReferenceBlock = 0x00;
inline constexpr std::uintptr_t kUserData = 0x10;

// ItemStack objects are 16-byte aligned inside container storage.
inline constexpr std::uintptr_t kAlignment = 0x10;

// Plausible size of the ItemStackBase header. Used to reject pointers that
// clearly do not point at a stack before dereferencing them.
inline constexpr std::uintptr_t kMinimumSpan = 0x28;

/**
 * @brief Default vtable slot of Item::getMaxDamage() on arm64 Bedrock.
 * Overridable through the mod config when a game update shifts the vtable.
 */
inline constexpr std::size_t kDefaultMaxDamageVtableIndex = 37;

} // namespace itemstack

/**
 * @brief Snapshot of a single armour item read out of an ItemStack.
 */
struct ArmorPiece {
    bool present{};
    std::uintptr_t stack{};
    std::uintptr_t item{};
    int current{};  // remaining durability
    int maximum{};  // total durability
    int damage{};   // durability already consumed
    std::string name;  // item path, e.g. "diamond_helmet"
};

/**
 * @brief Reads the Item pointer out of an ItemStack.
 * @return 0 when the stack is empty or unreadable.
 */
[[nodiscard]] std::uintptr_t readItem(std::uintptr_t itemStack);

/**
 * @brief Returns true when the stack holds no item.
 */
[[nodiscard]] bool isEmpty(std::uintptr_t itemStack);

/**
 * @brief Calls Item::getMaxDamage() on an item.
 * @param vtableIndex vtable slot of getMaxDamage.
 * @return total durability, or 0 when the call is not possible.
 */
[[nodiscard]] int itemMaxDamage(
    std::uintptr_t item,
    std::size_t vtableIndex = itemstack::kDefaultMaxDamageVtableIndex);

/**
 * @brief Confirms the getMaxDamage vtable slot against the loaded game binary
 *        using RTTI, so a shifted vtable is reported instead of crashing.
 * @return the resolved function address, or 0 when it could not be confirmed.
 */
[[nodiscard]] std::uintptr_t verifyMaxDamageVtableIndex(std::size_t vtableIndex);

/**
 * @brief Reads the item's namespaced identifier, e.g. "minecraft:diamond_helmet".
 *
 * Item does not store its id at a stable offset, so the identifier is located
 * by scanning the object for a libc++ std::string that looks like a namespaced
 * Minecraft name. This keeps icon selection working for armour added by future
 * Minecraft versions or add-ons without any table to update.
 *
 * @return empty string when no identifier could be located.
 */
[[nodiscard]] std::string readItemIdentifier(std::uintptr_t item);

/**
 * @brief Reads a single armour slot and converts durability to
 *        current/maximum.
 *
 * Minecraft stores durability as consumed damage, so the remaining durability
 * is `maximum - damage`. No percentage is computed or returned.
 */
[[nodiscard]] ArmorPiece readArmorPiece(std::uintptr_t itemStack,
                                        std::size_t maxDamageVtableIndex);

/**
 * @brief Extracts the item path (the part after "minecraft:") from a
 *        namespaced identifier.
 */
[[nodiscard]] std::string_view stripNamespace(std::string_view identifier);

} // namespace armor_hud::mc
