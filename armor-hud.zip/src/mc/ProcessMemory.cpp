#include "mc/ProcessMemory.h"

#include <dlfcn.h>
#include <elf.h>
#include <link.h>
#include <time.h>

#include <algorithm>
#include <cstdio>
#include <cstring>

namespace armor_hud::mc {
namespace {

// A maps snapshot older than this is refreshed before a validation failure is
// trusted. Short enough that freshly mapped memory is picked up almost
// immediately, long enough that scanning stays cheap.
constexpr long long kSnapshotStaleMs = 750;
constexpr long long kSnapshotRetryMs = 60;

// Must be as wide as an address. A 32-bit accumulator silently truncates every
// address in a 64-bit process, because /proc/self/maps addresses are far above
// 2 GiB: "7f82960000" would parse as 0xffffffff82960000 and every range lookup
// would then fail.
std::uintptr_t parseHex(const char *text, const char *end) {
    std::uintptr_t value = 0;
    for (const char *cursor = text; cursor < end; ++cursor) {
        const char ch = *cursor;
        std::uintptr_t digit = 0;
        if (ch >= '0' && ch <= '9') {
            digit = static_cast<std::uintptr_t>(ch - '0');
        } else if (ch >= 'a' && ch <= 'f') {
            digit = static_cast<std::uintptr_t>(ch - 'a' + 10);
        } else if (ch >= 'A' && ch <= 'F') {
            digit = static_cast<std::uintptr_t>(ch - 'A' + 10);
        } else {
            return value;
        }
        value = (value << 4) | digit;
    }
    return value;
}

int findPhdrCallback(dl_phdr_info *info, std::size_t, void *data) {
    auto *out = static_cast<std::pair<ModuleRange, const std::string_view *> *>(data);
    if (out->second->empty()) return 0;

    const char *name = info->dlpi_name;
    if (name == nullptr || name[0] == '\0') return 0;

    // Match on the trailing path component so both "libminecraftpe.so" and
    // "/data/app/.../lib/arm64/libminecraftpe.so" are accepted.
    const std::string_view full(name);
    const std::size_t slash = full.find_last_of('/');
    const std::string_view base =
        slash == std::string_view::npos ? full : full.substr(slash + 1);
    if (base != *out->second) return 0;

    ModuleRange range;
    for (int i = 0; i < info->dlpi_phnum; ++i) {
        // Deduced with auto on purpose: the element type is ElfW(Phdr) on
        // bionic and dl_phdr on older glibc, so naming it would break one of
        // the two targets.
        const auto &phdr = info->dlpi_phdr[i];
        if (phdr.p_type != PT_LOAD) continue;

        const std::uintptr_t begin = info->dlpi_addr + phdr.p_vaddr;
        const std::uintptr_t end = begin + phdr.p_memsz;
        if (range.begin == 0 || begin < range.begin) range.begin = begin;
        if (end > range.end) range.end = end;

        if ((phdr.p_flags & PF_X) != 0) {
            if (range.textBegin == 0 || begin < range.textBegin) {
                range.textBegin = begin;
            }
            if (end > range.textEnd) range.textEnd = end;
        }
    }

    if (range.end <= range.begin) return 0;
    if (range.textEnd <= range.textBegin) {
        range.textBegin = range.begin;
        range.textEnd = range.end;
    }

    out->first = range;
    return 1;
}

} // namespace

std::int64_t monotonicMillis() {
    struct timespec ts {};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<std::int64_t>(ts.tv_sec) * 1000 +
           static_cast<std::int64_t>(ts.tv_nsec) / 1000000;
}

ProcessMemory &ProcessMemory::instance() {
    static ProcessMemory memory;
    return memory;
}

void ProcessMemory::refresh() {
    std::vector<MapRange> ranges;
    ranges.reserve(256);

    std::FILE *maps = std::fopen("/proc/self/maps", "re");
    if (maps != nullptr) {
        char line[512];
        while (std::fgets(line, sizeof(line), maps) != nullptr) {
            const char *cursor = line;
            const char *dash = std::strchr(cursor, '-');
            if (dash == nullptr) continue;
            const char *space = std::strchr(dash, ' ');
            if (space == nullptr) continue;

            MapRange range;
            range.begin =
                static_cast<std::uintptr_t>(parseHex(cursor, dash));
            range.end = static_cast<std::uintptr_t>(parseHex(dash + 1, space));

            const char *perms = space + 1;
            if (std::strlen(perms) >= 4) {
                range.readable = perms[0] == 'r';
                range.writable = perms[1] == 'w';
                range.executable = perms[2] == 'x';
            }
            if (range.end > range.begin) ranges.push_back(range);
        }
        std::fclose(maps);
    }

    std::sort(ranges.begin(), ranges.end(),
              [](const MapRange &a, const MapRange &b) { return a.begin < b.begin; });

    mRanges = std::move(ranges);
    mSnapshotMs = monotonicMillis();
}

void ProcessMemory::refreshIfStale() const {
    const std::int64_t now = monotonicMillis();
    if (mSnapshotMs < 0 || now - mSnapshotMs > kSnapshotStaleMs) {
        const_cast<ProcessMemory *>(this)->refresh();
    }
}

bool ProcessMemory::isReadable(std::uintptr_t address, std::size_t size) const {
    if (address == 0 || size == 0) return false;
    if (mSnapshotMs < 0) const_cast<ProcessMemory *>(this)->refresh();
    if (mRanges.empty()) return false;

    auto check = [this, address, size]() -> bool {
        if (mRanges.empty()) return false;
        const std::uintptr_t last = address + size - 1;

        // First range whose end is strictly greater than address.
        auto it = std::upper_bound(
            mRanges.begin(), mRanges.end(), address,
            [](std::uintptr_t value, const MapRange &range) {
                return value < range.end;
            });
        if (it == mRanges.end() || it->begin > address) return false;
        if (!it->readable) return false;
        return last < it->end;
    };

    if (check()) return true;

    // The snapshot may predate the mapping. Retry once after a refresh, using a
    // tighter throttle so a burst of failures cannot hammer /proc.
    const std::int64_t now = monotonicMillis();
    if (mSnapshotMs < 0 || now - mSnapshotMs > kSnapshotRetryMs) {
        const_cast<ProcessMemory *>(this)->refresh();
        return check();
    }
    return false;
}

bool ProcessMemory::isWritable(std::uintptr_t address, std::size_t size) const {
    if (address == 0 || size == 0) return false;
    refreshIfStale();
    if (mRanges.empty()) return false;
    const std::uintptr_t last = address + size - 1;

    auto it = std::upper_bound(
        mRanges.begin(), mRanges.end(), address,
        [](std::uintptr_t value, const MapRange &range) {
            return value < range.end;
        });
    if (it == mRanges.end() || it->begin > address) return false;
    if (!it->writable) return false;
    return last < it->end;
}

bool ProcessMemory::readBytes(std::uintptr_t address, void *out,
                              std::size_t size) const {
    if (out == nullptr || size == 0) return false;
    if (!isReadable(address, size)) return false;
    std::memcpy(out, reinterpret_cast<const void *>(address), size);
    return true;
}

bool ProcessMemory::isMappedLibrary(std::uintptr_t address) const {
    const ModuleRange &module = minecraftModule();
    if (module.valid()) return module.contains(address);
    return false;
}

bool ProcessMemory::isPlausiblePointer(std::uintptr_t address) const {
    if (address == 0) return false;
    if ((address & 0x7) != 0) return false;
    // Android user-space addresses live well below 2^48; anything at or above
    // that is a sentinel, a computed value, or uninitialised memory.
    if (address >= (static_cast<std::uintptr_t>(1) << 48)) return false;
    if (address < 0x10000) return false;
    return isReadable(address, sizeof(void *));
}

ModuleRange ProcessMemory::findModule(std::string_view soname) {
    if (soname.empty()) return ModuleRange{};
    std::pair<ModuleRange, const std::string_view *> result{ModuleRange{}, &soname};
    dl_iterate_phdr(&findPhdrCallback, &result);
    return result.first;
}

const ModuleRange &ProcessMemory::minecraftModule() {
    // The game library is not loaded when the process starts, so a result is
    // re-resolved whenever the cached one is missing or has gone stale. This
    // also covers the library being unloaded on exit.
    static ModuleRange cached = findModule("libminecraftpe.so");
    static std::int64_t cachedMs = 0;

    const std::int64_t now = monotonicMillis();
    if (!cached.valid() || now - cachedMs > kSnapshotStaleMs) {
        const ModuleRange refreshed = findModule("libminecraftpe.so");
        if (refreshed.valid()) {
            cached = refreshed;
            cachedMs = now;
        } else {
            cachedMs = now;
        }
    }
    return cached;
}

} // namespace armor_hud::mc
