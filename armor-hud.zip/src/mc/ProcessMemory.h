#pragma once

#include <cstddef>
#include <cstdint>
#include <string_view>
#include <vector>

namespace armor_hud::mc {

/**
 * @brief A single readable/writable mapping of the current process.
 */
struct MapRange {
    std::uintptr_t begin{};
    std::uintptr_t end{};
    bool readable{};
    bool writable{};
    bool executable{};

    [[nodiscard]] std::size_t size() const { return end - begin; }
};

/**
 * @brief Load address range of a loaded shared library.
 */
struct ModuleRange {
    std::uintptr_t begin{};
    std::uintptr_t end{};
    // Range covering only executable PT_LOAD segments.
    std::uintptr_t textBegin{};
    std::uintptr_t textEnd{};

    [[nodiscard]] bool contains(std::uintptr_t address) const {
        return address >= begin && address < end;
    }
    [[nodiscard]] bool inText(std::uintptr_t address) const {
        return address >= textBegin && address < textEnd;
    }
    [[nodiscard]] bool valid() const { return end > begin; }
};

/**
 * @brief Process memory reader used by every reverse-engineering helper.
 *
 * Minecraft objects are discovered by scanning, so every dereference has to be
 * fault-safe. Instead of installing a SIGSEGV handler (which is unsafe when the
 * game runs its own threads), this class keeps a snapshot of
 * /proc/self/maps and validates each address before touching it. The snapshot
 * is refreshed on a short interval and immediately after a failed check, so
 * newly mapped memory becomes visible without a permanent polling cost.
 */
class ProcessMemory {
public:
    static ProcessMemory &instance();

    /**
     * @brief Reads a trivially copyable value, returning false when the whole
     *        range is not currently mapped readable.
     */
    template <typename T>
    bool read(std::uintptr_t address, T &out) const {
        if (address == 0) return false;
        if (!isReadable(address, sizeof(T))) return false;
        T value{};
        __builtin_memcpy(&value, reinterpret_cast<const void *>(address), sizeof(T));
        out = value;
        return true;
    }

    /**
     * @brief Reads a byte range, returning false unless fully readable.
     */
    bool readBytes(std::uintptr_t address, void *out, std::size_t size) const;

    /**
     * @brief Returns true when the whole range is mapped readable.
     */
    [[nodiscard]] bool isReadable(std::uintptr_t address, std::size_t size) const;

    /**
     * @brief Returns true when the whole range is mapped writable.
     */
    [[nodiscard]] bool isWritable(std::uintptr_t address, std::size_t size) const;

    /**
     * @brief Returns true when the address is inside a loaded library.
     */
    [[nodiscard]] bool isMappedLibrary(std::uintptr_t address) const;

    /**
     * @brief Returns true when the address is a plausible heap object pointer:
     *        aligned and mapped.
     */
    [[nodiscard]] bool isPlausiblePointer(std::uintptr_t address) const;

    /**
     * @brief Force-refreshes the maps snapshot. Used after world/dimension
     *        changes, when large amounts of memory may have been remapped.
     */
    void refresh();

    /**
     * @brief Locates a loaded library by its soname (for example
     *        "libminecraftpe.so").
     */
    [[nodiscard]] static ModuleRange findModule(std::string_view soname);

    /**
     * @brief The Minecraft client library range. Invalid until the game
     *        process has mapped it.
     */
    [[nodiscard]] static const ModuleRange &minecraftModule();

private:
    ProcessMemory() = default;

    void refreshIfStale() const;

    mutable std::vector<MapRange> mRanges;
    mutable long long mSnapshotMs = -1;
};

/**
 * @brief Monotonic milliseconds, used for throttling map snapshots and the
 *        HUD state poller.
 */
[[nodiscard]] std::int64_t monotonicMillis();

} // namespace armor_hud::mc
