#include "mc/Rtti.h"

#include "mc/ProcessMemory.h"

#include <algorithm>
#include <cctype>
#include <cstring>

namespace armor_hud::mc::rtti {
namespace {

using ProcessMemory = armor_hud::mc::ProcessMemory;

constexpr std::size_t kPointerSize = sizeof(void *);

// An Itanium name component is a decimal length followed by that many
// characters. Anything longer than this is a builtin or a vendor extension we
// do not try to interpret.
constexpr std::size_t kMaxComponentLength = 96;

bool readCString(std::uintptr_t address, char *out, std::size_t capacity) {
    if (address == 0 || out == nullptr || capacity == 0) return false;
    std::size_t written = 0;
    // Names are short; read in small chunks and stop at the terminator so a
    // non-terminated region cannot make us scan gigabytes.
    for (std::size_t offset = 0; offset < capacity - 1; offset += 16) {
        char chunk[16];
        const std::size_t want = std::min(sizeof(chunk), capacity - 1 - offset);
        if (!ProcessMemory::instance().readBytes(address + offset, chunk, want)) {
            return false;
        }
        for (std::size_t index = 0; index < want; ++index) {
            if (chunk[index] == '\0') {
                out[written] = '\0';
                return true;
            }
            out[written++] = chunk[index];
        }
    }
    out[capacity - 1] = '\0';
    return false;
}

struct MangledParser {
    std::string_view text;
    std::size_t cursor{};
    std::vector<std::string> components;

    [[nodiscard]] bool atEnd() const { return cursor >= text.size(); }

    [[nodiscard]] char peek() const {
        return atEnd() ? '\0' : text[cursor];
    }

    bool parseComponent() {
        if (atEnd()) return false;
        const char ch = peek();

        // Substitution: S_ is the first component, S0_ the second, and so on.
        if (ch == 'S') {
            ++cursor;
            if (atEnd()) return false;
            const char marker = peek();
            ++cursor;
            std::size_t base = 0;
            if (marker == '_') {
                base = 0;
            } else if (std::isdigit(static_cast<unsigned char>(marker))) {
                base = static_cast<std::size_t>(marker - '0') + 1;
            } else {
                return false;
            }
            const std::size_t index = base < components.size() ? base : 0;
            components.push_back(index < components.size() ? components[index]
                                                            : std::string("?"));
            return true;
        }

        if (ch == 'N') {
            ++cursor;
            while (!atEnd() && peek() != 'E') {
                if (!parseComponent()) return false;
            }
            if (atEnd()) return false;
            ++cursor; // consume 'E'
            return true;
        }

        if (ch < '0' || ch > '9') return false;

        std::size_t length = 0;
        while (!atEnd() && peek() >= '0' && peek() <= '9') {
            length = length * 10 + static_cast<std::size_t>(peek() - '0');
            ++cursor;
            if (length > kMaxComponentLength) return false;
        }
        if (length == 0 || cursor + length > text.size()) return false;
        components.emplace_back(text.substr(cursor, length));
        cursor += length;
        return true;
    }
};

} // namespace

std::uintptr_t addressPoint(std::uintptr_t object) {
    if (!ProcessMemory::instance().isPlausiblePointer(object)) return 0;
    std::uintptr_t vptr = 0;
    if (!ProcessMemory::instance().read(object, vptr)) return 0;
    return vptr;
}

std::uintptr_t typeInfo(std::uintptr_t object) {
    const std::uintptr_t point = addressPoint(object);
    if (point == 0) return 0;
    std::uintptr_t info = 0;
    // The type_info pointer sits immediately before the address point.
    if (!ProcessMemory::instance().read(point - kPointerSize, info)) return 0;
    if (info == 0) return 0;
    if (!ProcessMemory::instance().isPlausiblePointer(info)) return 0;
    return info;
}

bool hasGameVtable(std::uintptr_t object) {
    const std::uintptr_t point = addressPoint(object);
    if (point == 0) return false;
    return ProcessMemory::instance().isMappedLibrary(point);
}

std::string mangledName(std::uintptr_t object) {
    const std::uintptr_t info = typeInfo(object);
    if (info == 0) return {};

    std::uintptr_t nameAddress = 0;
    if (!ProcessMemory::instance().read(info + kPointerSize, nameAddress)) return {};
    if (nameAddress == 0) return {};

    char buffer[kMaxRttiName];
    if (!readCString(nameAddress, buffer, sizeof(buffer))) return {};
    return std::string(buffer);
}

std::string demangle(std::string_view mangled) {
    if (mangled.empty()) return {};

    MangledParser parser{mangled, 0, {}};
    if (!parser.parseComponent()) return std::string(mangled);

    std::string result;
    for (std::size_t index = 0; index < parser.components.size(); ++index) {
        if (index != 0) result += "::";
        result += parser.components[index];
    }
    return result;
}

std::string className(std::uintptr_t object) {
    const std::string raw = mangledName(object);
    if (raw.empty()) return {};
    return demangle(raw);
}

bool classNameContains(std::uintptr_t object, std::string_view needle) {
    if (needle.empty()) return false;
    const std::string name = className(object);
    if (name.empty()) return false;
    return name.find(needle) != std::string::npos;
}

std::uintptr_t vtableFunction(std::uintptr_t object, std::size_t index) {
    const std::uintptr_t point = addressPoint(object);
    if (point == 0) return 0;
    std::uintptr_t function = 0;
    if (!ProcessMemory::instance().read(point + index * kPointerSize, function)) {
        return 0;
    }
    return function;
}

bool isGameCodePointer(std::uintptr_t address) {
    if (address == 0) return false;
    const ModuleRange &module = ProcessMemory::minecraftModule();
    if (!module.valid()) return false;
    return module.inText(address);
}

} // namespace armor_hud::mc::rtti
