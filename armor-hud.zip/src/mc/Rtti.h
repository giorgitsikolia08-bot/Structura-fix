#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace armor_hud::mc {

/**
 * @brief Maximum length of a demangled class name, including terminator.
 */
inline constexpr std::size_t kMaxRttiName = 128;

/**
 * @brief Itanium C++ ABI accessors.
 *
 * Minecraft Bedrock is compiled with RTTI enabled, so any C++ object reachable
 * from a hook can be identified by its dynamic type. This is what lets the mod
 * *verify* what it discovered instead of trusting a hard-coded offset:
 *
 *   object -> vptr (address point)
 *          -> [address point - 8]  = std::type_info*
 *          -> [std::type_info* + 8] = NUL-terminated mangled name
 *
 * Every read goes through ProcessMemory, so a stale or bogus pointer yields an
 * empty name rather than a crash.
 */
namespace rtti {

/**
 * @brief Returns the primary vtable address point of @p object, or 0.
 *
 * The address point is the address stored in the object's first word, i.e. the
 * location right after offset-to-top and the type_info pointer.
 */
[[nodiscard]] std::uintptr_t addressPoint(std::uintptr_t object);

/**
 * @brief Returns true when @p object points at a vtable owned by the Minecraft
 *        client library. Vtables live in the library's read-only data, so this
 *        deliberately checks the whole module range, not the executable range.
 */
[[nodiscard]] bool hasGameVtable(std::uintptr_t object);

/**
 * @brief Reads the type_info pointer of @p object, or 0.
 */
[[nodiscard]] std::uintptr_t typeInfo(std::uintptr_t object);

/**
 * @brief Returns the raw mangled type name of @p object, or an empty string.
 */
[[nodiscard]] std::string mangledName(std::uintptr_t object);

/**
 * @brief Demangles a subset of the Itanium ABI used by Bedrock.
 *
 * Handles nested names ("N4mce9ActorE" -> "mce::Actor") and substitution
 * components ("S_", "S0_", ...). Unsupported constructs are returned with the
 * remaining components joined by "::", which is still enough for
 * substring matching.
 */
[[nodiscard]] std::string demangle(std::string_view mangled);

/**
 * @brief Returns the demangled dynamic type name of @p object, e.g.
 *        "ArmorInventory" or "mce::Actor". Empty when RTTI is unavailable.
 */
[[nodiscard]] std::string className(std::uintptr_t object);

/**
 * @brief Returns true when the dynamic type name of @p object contains
 *        @p needle. An object without RTTI information never matches, so
 *        callers must treat `false` as "not this type", not "not an object".
 */
[[nodiscard]] bool classNameContains(std::uintptr_t object, std::string_view needle);

/**
 * @brief Returns the function pointer stored in the primary vtable slot
 *        @p index of @p object, or 0 when the slot cannot be read.
 *
 * The index is relative to the vtable address point, matching the convention
 * used by the LeviLauncher SDK's own resolveVtableFunction().
 */
[[nodiscard]] std::uintptr_t vtableFunction(std::uintptr_t object, std::size_t index);

/**
 * @brief Returns true when @p address is an executable address inside the
 *        Minecraft client library. Used to validate recovered function
 *        pointers and vtable targets.
 */
[[nodiscard]] bool isGameCodePointer(std::uintptr_t address);

} // namespace rtti

} // namespace armor_hud::mc
