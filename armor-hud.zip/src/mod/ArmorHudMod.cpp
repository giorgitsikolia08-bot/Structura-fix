#include "mod/ArmorHudMod.h"

#include <pl/ModMenu.hpp>

#include <string>
#include <string_view>

namespace armor_hud::mod {
namespace {

constexpr std::string_view kModuleId = hud::HudRenderer::kModuleId;

pl::log::Logger &logger() {
    static pl::log::Logger &instance =
        pl::log::Logger::getOrCreate("Armor HUD");
    return instance;
}

} // namespace

bool ArmorHudMod::load(pl::mod::ModContext &context) {
    (void)context;

    config::load(mConfig);

    auto &api = mc::GameApi::instance();
    logger().info("Armor HUD loaded, game API: {}", api.describeSignatures());

    if (!api.install()) {
        logger().error(
            "Armor HUD could not resolve the game functions it needs. The HUD "
            "will stay hidden. Check that this build matches the installed "
            "Minecraft version.");
        // Loading still succeeds so the user can read the message and open the
        // settings screen instead of having the mod vanish.
        return true;
    }

    return true;
}

bool ArmorHudMod::enable(pl::mod::ModContext &context) {
    (void)context;

    config::load(mConfig);
    registerModule();
    mEnabled = true;

    auto &api = mc::GameApi::instance();
    if (api.installed()) {
        mInventory.invalidate();
        api.setTickCallback(
            [](void *context) {
                static_cast<ArmorHudMod *>(context)->onTick();
            },
            this);
    } else {
        logger().warn("Armor HUD is enabled but has no game hook; HUD stays hidden.");
    }
    return true;
}

bool ArmorHudMod::disable(pl::mod::ModContext &context) {
    (void)context;

    mEnabled = false;
    mc::GameApi::instance().setTickCallback(nullptr);
    mRenderer.clear();
    mInventory.invalidate();
    return true;
}

bool ArmorHudMod::unload(pl::mod::ModContext &context) {
    (void)context;

    disable(context);
    unregisterModule();
    mc::GameApi::instance().uninstall();
    logger().info("Armor HUD unloaded");
    return true;
}

void ArmorHudMod::registerModule() {
    if (mModuleRegistered) return;

    pl::modmenu::ModuleBuilder builder(std::string(kModuleId), "Armor HUD");
    builder.description("Shows the four armour slots with remaining durability.");
    const auto *current = ll::mod::NativeMod::current();
    builder.modId(current != nullptr ? current->getId() : std::string());
    builder.defaultEnabled(true);

    builder.config("enabled", "Enabled", pl::modmenu::ConfigType::Toggle, "true");
    builder.config("showDurabilityText", "Show durability text",
                   pl::modmenu::ConfigType::Toggle, "true");
    builder.config("hideWhenEmpty", "Hide when nothing is worn",
                   pl::modmenu::ConfigType::Toggle, "true");
    builder.config("lowDurabilityThreshold", "Warning threshold",
                   pl::modmenu::ConfigType::SliderInt, "30", "0", "1000");

    builder.onConfigChanged([this](std::string_view moduleId, std::string_view key,
                                   std::string_view value) {
        (void)moduleId;
        onConfigChangedFromMenu(key, value);
    });

    mModuleRegistered = builder.registerModule();
    if (!mModuleRegistered) {
        logger().warn("Armor HUD could not register its Mod Menu module.");
    }
}

void ArmorHudMod::unregisterModule() {
    if (!mModuleRegistered) return;
    pl::modmenu::unregisterModule(kModuleId);
    mModuleRegistered = false;
}

void ArmorHudMod::onConfigChangedFromMenu(std::string_view key, std::string_view value) {
    (void)key;
    (void)value;
    // Settings edited in the launcher are picked up by the next config load.
    // The tick handler re-reads the file so an edit applies without a restart.
}

void ArmorHudMod::onTick() {
    if (!mEnabled) return;

    const mc::ArmorInventory::Overrides overrides = mConfig.overrides();

    // The tick callback only tells us a tick happened. The local player
    // pointer is the one the game just passed to the hooked function.
    mInventory.tick(mc::GameApi::instance().localPlayer(), overrides);

    // Log the first successful discovery, and any rescan afterwards, so the
    // user can confirm the offsets were found without spamming the log.
    if (mInventory.discoveryCount() != static_cast<std::uint32_t>(mLastLoggedDiscovery)) {
        mLastLoggedDiscovery = static_cast<std::int64_t>(mInventory.discoveryCount());
        logger().info(
            "Armour slots located: container +0x{:X}, slots +0x{:X}, stride 0x{:X} "
            "({} from RTTI/exact-count confirmation)",
            mInventory.layout().containerOffset, mInventory.layout().slotArrayOffset,
            mInventory.layout().slotStride,
            mInventory.layout().exactSlotCount ? "exact" : "assumed");
    }

    mc::ArmorPiece pieces[mc::ArmorInventory::kSlotCount];
    mInventory.read(pieces, overrides);

    mRenderer.render(pieces, mInventory, mConfig, pl::modmenu::getHudSurfaceSize());
}

} // namespace armor_hud::mod