#pragma once

#include <cstdint>

#include <pl/Mod.hpp>

#include "hud/HudRenderer.h"
#include "mc/ArmorInventory.h"
#include "mc/GameApi.h"
#include "mod/Config.h"

namespace armor_hud::mod {

/**
 * @brief The Armor HUD mod.
 *
 * Lifecycle:
 *   load()    resolve game functions and install hooks
 *   enable()  register the Mod Menu module and start rendering
 *   disable() hide the HUD and unregister the module
 *   unload()  remove hooks and release everything
 *
 * Reads happen on the game's own tick thread, which is where the client code
 * that owns the player object runs, so no lock is required. Nothing is written
 * to game memory at any point.
 */
class ArmorHudMod {
public:
    bool load(pl::mod::ModContext &context);
    bool enable(pl::mod::ModContext &context);
    bool disable(pl::mod::ModContext &context);
    bool unload(pl::mod::ModContext &context);

private:
    void registerModule();
    void unregisterModule();
    void onTick();
    void onConfigChangedFromMenu(std::string_view key, std::string_view value);

    mc::ArmorInventory mInventory;
    hud::HudRenderer mRenderer;
    ArmorHudConfig mConfig;

    // Rendering is driven from the tick hook rather than from a timer, so the
    // HUD costs nothing while the game is paused or in the background.
    bool mEnabled{false};
    bool mModuleRegistered{false};
    std::int64_t mLastLoggedDiscovery{0};
};

} // namespace armor_hud::mod