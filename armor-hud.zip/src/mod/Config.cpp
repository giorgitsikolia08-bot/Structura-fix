#include "mod/Config.h"

#include <algorithm>

namespace armor_hud::mod {

mc::ArmorInventory::Overrides ArmorHudConfig::overrides() const {
    mc::ArmorInventory::Overrides result;
    result.containerOffset = containerOffset;
    result.slotArrayOffset = slotArrayOffset;
    result.slotStride = slotStride;
    result.maxDamageVtableIndex =
        maxDamageVtableIndex > 0
            ? static_cast<std::size_t>(maxDamageVtableIndex)
            : mc::itemstack::kDefaultMaxDamageVtableIndex;
    return result;
}

namespace config {
namespace {

/**
 * @brief Clamps every field into a range the renderer can handle. Called after
 *        loading so a hand-edited config.json cannot produce a broken HUD.
 */
void sanitize(ArmorHudConfig &value) {
    value.lowDurabilityThreshold =
        std::clamp(value.lowDurabilityThreshold, 0, 1000);
    value.scale = std::clamp(value.scale, 0.25f, 4.0f);
    value.cellSize = std::clamp(value.cellSize, 16.0f, 128.0f);
    value.iconSize = std::clamp(value.iconSize, 8.0f, 96.0f);
    value.textSize = std::clamp(value.textSize, 4.0f, 32.0f);
    value.textOffsetY = std::clamp(value.textOffsetY, 0.0f, 128.0f);
    value.hotbarGap = std::clamp(value.hotbarGap, 0.0f, 400.0f);

    // An icon larger than its slot would overlap the neighbouring slot.
    value.iconSize = std::min(value.iconSize, value.cellSize * 0.9f);

    if (value.maxDamageVtableIndex < 0 || value.maxDamageVtableIndex > 512) {
        value.maxDamageVtableIndex =
            static_cast<int>(mc::itemstack::kDefaultMaxDamageVtableIndex);
    }
}

} // namespace

#ifndef PL_CONFIG_NO_RUNTIME
namespace {

/**
 * @brief Single shared config file. Constructed lazily on first use so that
 *        defaultConfigPath() is evaluated after the mod runtime exists.
 */
pl::config::ConfigFile<ArmorHudConfig> &file() {
    static pl::config::ConfigFile<ArmorHudConfig> instance;
    return instance;
}

} // namespace
#endif

bool load(ArmorHudConfig &out) {
#ifdef PL_CONFIG_NO_RUNTIME
    // Host build: no mod runtime exists, so the config surface is validated by
    // the config generator target instead.
    out = ArmorHudConfig{};
    sanitize(out);
    return false;
#else
    auto &config = file();
    const bool loaded = config.load();
    out = config.value();
    sanitize(out);
    return loaded;
#endif
}

bool save(const ArmorHudConfig &value) {
#ifdef PL_CONFIG_NO_RUNTIME
    (void)value;
    return false;
#else
    auto &config = file();
    config.value() = value;
    return config.save();
#endif
}

} // namespace config

} // namespace armor_hud::mod