#pragma once

#include <cstdint>
#include <string>
#include <string_view>

#include <pl/Config.hpp>

#include "mc/ArmorInventory.h"

namespace armor_hud::mod {

/**
 * @brief User-facing settings.
 *
 * Every durability-related field here is an absolute value reported by the
 * game. No percentage is stored, derived or compared anywhere in this mod.
 */
struct ArmorHudConfig {
    // Bumped whenever the field layout changes. pl::config rewrites the file
    // when this does not match, so new fields appear with their defaults.
    int version{1};

    bool enabled{true};

    /**
     * @brief Hide the whole HUD when no armour is equipped. When false the
     *        four empty slots stay on screen.
     */
    bool hideWhenEmpty{true};

    /**
     * @brief Warn when remaining durability is at or below this many units.
     */
    int lowDurabilityThreshold{30};

    /**
     * @brief Show remaining/maximum as text inside each slot.
     */
    bool showDurabilityText{true};

    /**
     * @brief Anchor the HUD to the estimated hotbar band instead of the fixed
     *        anchors below, so it stays visually attached across resolutions.
     */
    bool followHotbar{true};

    // Magic-anchor values used when followHotbar is false. -20000 is screen
    // centre, -10000 is the right or bottom edge, and values in (-10000, 0) are
    // offsets from that edge. The overlay resolves these before drawing.
    float anchorX{-10000.0f};
    float anchorY{-10000.0f};
    float anchorOffsetX{0.0f};
    float anchorOffsetY{0.0f};

    // Multiplier on top of the automatic resolution scale.
    float scale{1.0f};

    // Gap between the bottom of the HUD and the estimated hotbar band.
    float hotbarGap{6.0f};

    // Slot geometry in reference pixels at 1920x1080.
    float cellSize{44.0f};
    float iconSize{30.0f};
    float textSize{9.0f};
    float textOffsetY{30.0f};

    // ARGB colours.
    std::uint32_t textColor{0xFFFFFFFF};
    std::uint32_t warningColor{0xFFFF5B5B};
    std::uint32_t slotBackgroundColor{0xB0101010};
    std::uint32_t warningBackgroundColor{0xB0300000};

    /**
     * @brief Discovery overrides. -1 or 0 means automatic detection. These let
     *        a user repair a broken layout from the settings screen without
     *        waiting for a new build.
     */
    long long containerOffset{-1};
    long long slotArrayOffset{-1};
    long long slotStride{0};
    int maxDamageVtableIndex{37};

    [[nodiscard]] mc::ArmorInventory::Overrides overrides() const;
};

namespace config {

/**
 * @brief Loads config.json, writing it on first run.
 * @return false when the file could not be read, in which case defaults are
 *         used and the caller should retry later.
 */
bool load(ArmorHudConfig &out);

/**
 * @brief Writes the current config back to disk.
 */
bool save(const ArmorHudConfig &value);

} // namespace config

} // namespace armor_hud::mod

namespace pl::config {

/**
 * @brief Schema metadata so the launcher renders labelled sliders with sane
 *        bounds instead of raw numeric fields.
 */
template <> struct Schema<armor_hud::mod::ArmorHudConfig> {
    static constexpr std::string_view title = "Armor HUD";
    static constexpr std::string_view description =
        "Shows the four armour slots with remaining durability.";

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "lowDurabilityThreshold")
            return {"Warning threshold",
                    "Warn at or below this remaining durability.", 0.0, 1000.0};
        if (name == "scale")
            return {"Scale", "Multiplier on the automatic resolution scale.",
                    0.5, 3.0};
        if (name == "cellSize")
            return {"Slot size", "Slot size in reference pixels.", 24.0, 96.0};
        if (name == "iconSize")
            return {"Icon size", "Icon size in reference pixels.", 16.0, 64.0};
        if (name == "textSize")
            return {"Text size", "Durability text size in reference pixels.",
                    6.0, 24.0};
        if (name == "textOffsetY")
            return {"Text offset", "Vertical text offset inside the slot.",
                    0.0, 96.0};
        if (name == "hotbarGap")
            return {"Hotbar gap", "Gap between the HUD and the hotbar.",
                    0.0, 200.0};
        if (name == "maxDamageVtableIndex")
            return {"getMaxDamage slot", "vtable index of Item::getMaxDamage().",
                    0.0, 128.0};
        if (name == "anchorOffsetX")
            return {"Anchor X offset", "Pixels from the X anchor.",
                    -4000.0, 4000.0};
        if (name == "anchorOffsetY")
            return {"Anchor Y offset", "Pixels from the Y anchor.",
                    -4000.0, 4000.0};
        return {};
    }
};

} // namespace pl::config